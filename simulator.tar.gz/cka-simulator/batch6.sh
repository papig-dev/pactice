#!/usr/bin/env bash
# Batch 6: etcd, Cluster Upgrade, PSA & HPA (Q101–Q120) — sourced by run.sh

BATCH_TITLE="Batch 6 — etcd, Cluster Upgrade, PSA & HPA (Q101–Q120)"
Q_TITLES=(""
  "etcd Backup (command file)"
  "etcd Restore (command file)"
  "kubeadm Upgrade Plan (command file)"
  "kubeadm Upgrade Apply (command file)"
  "Upgrade Worker Node (command file)"
  "Pod Security Admission: enforce restricted"
  "Pod Security Admission: warn baseline"
  "PSA: Label Namespace + Verify Rejection"
  "Create HPA (CPU-based)"
  "HPA with Custom Min/Max Replicas"
  "HPA ScaleDown Stabilization Window"
  "Downward API: Pod Name as Env Var"
  "Downward API: CPU Request as Env Var"
  "Downward API: Pod Labels as Volume File"
  "PriorityClass: Create + Assign to Pod"
  "PriorityClass: Preemption Verification"
  "Static Pod via kubeadm manifest path"
  "kubelet: Fix container-runtime-endpoint"
  "Node Condition: Drain NotReady Node"
  "Cluster Info + Component Status Check"
)

_ns() { kubectl create namespace "$1" --dry-run=client -o yaml | kubectl apply -f - 2>/dev/null; }
_cp() {
  kubectl get nodes --no-headers | grep -i 'control-plane\|master' | awk 'NR==1{print $1}'
}
_worker() {
  kubectl get nodes --no-headers | grep -v 'control-plane\|master' | awk 'NR==1{print $1}'
}

# ─── Q101 ─────────────────────────────────────────────────────────────────────
setup_q101() {
  rm -f /tmp/etcd-backup-cmd.sh 2>/dev/null
  echo "Write the etcd backup command to /tmp/etcd-backup-cmd.sh"
}
show_q101() { cat <<'EOF'
  TASK — etcd Backup (Command File)
  ──────────────────────────────────────────────────────────────
  Write the correct etcd snapshot save command to:
    /tmp/etcd-backup-cmd.sh

  Requirements:
    - Save snapshot to: /tmp/etcd-snapshot.db
    - Endpoint:  https://127.0.0.1:2379
    - cacert:    /etc/kubernetes/pki/etcd/ca.crt
    - cert:      /etc/kubernetes/pki/etcd/server.crt
    - key:       /etc/kubernetes/pki/etcd/server.key
    - Use ETCDCTL_API=3

  Example format:
    ETCDCTL_API=3 etcdctl snapshot save /tmp/etcd-snapshot.db \
      --endpoints=... --cacert=... --cert=... --key=...

  ── 한국어 ─────────────────────────────────────────────
  etcd 스냅샷 백업 커맨드를 /tmp/etcd-backup-cmd.sh 에 작성하세요.
    저장 경로: /tmp/etcd-snapshot.db
    엔드포인트: https://127.0.0.1:2379
    인증서 경로: /etc/kubernetes/pki/etcd/ 사용
    ETCDCTL_API=3 환경변수 필수
EOF
}
validate_q101() {
  [[ -f /tmp/etcd-backup-cmd.sh ]] || { echo -e "  ${RED}✗ /tmp/etcd-backup-cmd.sh not found${NC}"; return 1; }
  local content; content=$(cat /tmp/etcd-backup-cmd.sh)
  local ok=true
  [[ "$content" != *"ETCDCTL_API=3"* ]]             && { echo -e "  ${RED}✗ ETCDCTL_API=3 missing${NC}"; ok=false; }
  [[ "$content" != *"snapshot save"* ]]              && { echo -e "  ${RED}✗ 'snapshot save' missing${NC}"; ok=false; }
  [[ "$content" != *"/tmp/etcd-snapshot.db"* ]]      && { echo -e "  ${RED}✗ snapshot path '/tmp/etcd-snapshot.db' missing${NC}"; ok=false; }
  [[ "$content" != *"127.0.0.1:2379"* ]]             && { echo -e "  ${RED}✗ endpoint 127.0.0.1:2379 missing${NC}"; ok=false; }
  [[ "$content" != *"etcd/ca.crt"* ]]                && { echo -e "  ${RED}✗ cacert path missing${NC}"; ok=false; }
  [[ "$content" != *"etcd/server.crt"* ]]            && { echo -e "  ${RED}✗ cert path missing${NC}"; ok=false; }
  [[ "$content" != *"etcd/server.key"* ]]            && { echo -e "  ${RED}✗ key path missing${NC}"; ok=false; }
  [[ "$ok" == "true" ]] && echo -e "  ${GREEN}✓ etcd backup command is correct.${NC}"
  [[ "$ok" == "true" ]]
}
hint_q101() {
  local cp; cp=$(_cp)
  cat <<EOF
  # kind 환경: control plane 컨테이너에 직접 접속해서 실행
  docker exec -it $cp bash
    # 안에서:
    apt-get update && apt-get install -y etcd-client
    ETCDCTL_API=3 etcdctl snapshot save /tmp/etcd-snapshot.db \\
      --endpoints=https://127.0.0.1:2379 \\
      --cacert=/etc/kubernetes/pki/etcd/ca.crt \\
      --cert=/etc/kubernetes/pki/etcd/server.crt \\
      --key=/etc/kubernetes/pki/etcd/server.key

  # 또는 이 문제(command file 방식):
  cat > /tmp/etcd-backup-cmd.sh <<'SCRIPT'
  ETCDCTL_API=3 etcdctl snapshot save /tmp/etcd-snapshot.db \\
    --endpoints=https://127.0.0.1:2379 \\
    --cacert=/etc/kubernetes/pki/etcd/ca.crt \\
    --cert=/etc/kubernetes/pki/etcd/server.crt \\
    --key=/etc/kubernetes/pki/etcd/server.key
  SCRIPT

  # 실제 CKA 시험: etcdctl 이미 설치돼 있음, ssh로 control plane 접속 후 바로 실행
EOF
}

# ─── Q102 ─────────────────────────────────────────────────────────────────────
setup_q102() {
  rm -f /tmp/etcd-restore-cmd.sh 2>/dev/null
  echo "Write the etcd restore command to /tmp/etcd-restore-cmd.sh"
}
show_q102() { cat <<'EOF'
  TASK — etcd Restore (Command File)
  ──────────────────────────────────────────────────────────────
  Write the correct etcd snapshot restore command to:
    /tmp/etcd-restore-cmd.sh

  Requirements:
    - Restore from: /tmp/etcd-snapshot.db
    - Restore to data dir: /var/lib/etcd-restore
    - Use ETCDCTL_API=3
    - After restore, update the etcd static pod manifest:
        /etc/kubernetes/manifests/etcd.yaml
      to point --data-dir to /var/lib/etcd-restore

  Include both commands in the file.

  ── 한국어 ─────────────────────────────────────────────
  etcd 스냅샷 복원 커맨드를 /tmp/etcd-restore-cmd.sh 에 작성하세요.
    소스: /tmp/etcd-snapshot.db
    복원 디렉토리: /var/lib/etcd-restore
    복원 후 /etc/kubernetes/manifests/etcd.yaml 의 --data-dir 수정 단계도 포함
EOF
}
validate_q102() {
  [[ -f /tmp/etcd-restore-cmd.sh ]] || { echo -e "  ${RED}✗ /tmp/etcd-restore-cmd.sh not found${NC}"; return 1; }
  local content; content=$(cat /tmp/etcd-restore-cmd.sh)
  local ok=true
  [[ "$content" != *"ETCDCTL_API=3"* ]]              && { echo -e "  ${RED}✗ ETCDCTL_API=3 missing${NC}"; ok=false; }
  [[ "$content" != *"snapshot restore"* ]]           && { echo -e "  ${RED}✗ 'snapshot restore' missing${NC}"; ok=false; }
  [[ "$content" != *"/tmp/etcd-snapshot.db"* ]]      && { echo -e "  ${RED}✗ snapshot source path missing${NC}"; ok=false; }
  [[ "$content" != *"etcd-restore"* ]]               && { echo -e "  ${RED}✗ restore data-dir path missing${NC}"; ok=false; }
  [[ "$content" != *"etcd.yaml"* ]]                  && { echo -e "  ${RED}✗ etcd manifest update step missing${NC}"; ok=false; }
  [[ "$ok" == "true" ]] && echo -e "  ${GREEN}✓ etcd restore command is correct.${NC}"
  [[ "$ok" == "true" ]]
}
hint_q102() { cat <<'EOF'
  cat > /tmp/etcd-restore-cmd.sh <<'SCRIPT'
  # Step 1: Restore snapshot
  ETCDCTL_API=3 etcdctl snapshot restore /tmp/etcd-snapshot.db \
    --data-dir=/var/lib/etcd-restore

  # Step 2: Update etcd static pod manifest
  # Edit /etc/kubernetes/manifests/etcd.yaml
  # Change: --data-dir=/var/lib/etcd  →  --data-dir=/var/lib/etcd-restore
  # Change hostPath for etcd-data volume to /var/lib/etcd-restore
  SCRIPT
EOF
}

# ─── Q103 ─────────────────────────────────────────────────────────────────────
setup_q103() {
  rm -f /tmp/upgrade-plan-cmd.sh 2>/dev/null
  echo "Write kubeadm upgrade plan commands to /tmp/upgrade-plan-cmd.sh"
}
show_q103() { cat <<'EOF'
  TASK — kubeadm Upgrade: Plan (Command File)
  ──────────────────────────────────────────────────────────────
  Current cluster version: v1.33.x
  Target version:          v1.34.x

  Write the upgrade preparation commands to:
    /tmp/upgrade-plan-cmd.sh

  Steps required:
    1. Update apt package list
    2. Install kubeadm v1.34.* (apt-get)
    3. Run: kubeadm upgrade plan

  ── 한국어 ─────────────────────────────────────────────
  업그레이드 계획 커맨드를 /tmp/upgrade-plan-cmd.sh 에 작성하세요.
    현재: v1.33.x → 대상: v1.34.x
    1) apt 패키지 목록 업데이트
    2) kubeadm=1.34.* 설치
    3) kubeadm upgrade plan 실행
EOF
}
validate_q103() {
  [[ -f /tmp/upgrade-plan-cmd.sh ]] || { echo -e "  ${RED}✗ /tmp/upgrade-plan-cmd.sh not found${NC}"; return 1; }
  local content; content=$(cat /tmp/upgrade-plan-cmd.sh)
  local ok=true
  [[ "$content" != *"apt"* && "$content" != *"apt-get"* ]] && { echo -e "  ${RED}✗ apt update step missing${NC}"; ok=false; }
  [[ "$content" != *"kubeadm"*"1.34"* ]]  && { echo -e "  ${RED}✗ kubeadm v1.34 install missing${NC}"; ok=false; }
  [[ "$content" != *"upgrade plan"* ]]    && { echo -e "  ${RED}✗ 'kubeadm upgrade plan' missing${NC}"; ok=false; }
  [[ "$ok" == "true" ]] && echo -e "  ${GREEN}✓ Upgrade plan commands correct.${NC}"
  [[ "$ok" == "true" ]]
}
hint_q103() { cat <<'EOF'
  cat > /tmp/upgrade-plan-cmd.sh <<'SCRIPT'
  apt-get update
  apt-get install -y kubeadm=1.34.*
  kubeadm upgrade plan
  SCRIPT
EOF
}

# ─── Q104 ─────────────────────────────────────────────────────────────────────
setup_q104() {
  rm -f /tmp/upgrade-apply-cmd.sh 2>/dev/null
  echo "Write kubeadm upgrade apply commands to /tmp/upgrade-apply-cmd.sh"
}
show_q104() { cat <<'EOF'
  TASK — kubeadm Upgrade: Apply Control Plane (Command File)
  ──────────────────────────────────────────────────────────────
  Write the full control plane upgrade commands to:
    /tmp/upgrade-apply-cmd.sh

  Steps required (in order):
    1. kubeadm upgrade apply v1.34.0
    2. Drain control plane node (ignore daemonsets)
    3. Install kubelet=1.34.* and kubectl=1.34.* via apt-get
    4. systemctl daemon-reload
    5. systemctl restart kubelet
    6. Uncordon control plane node

  ── 한국어 ─────────────────────────────────────────────
  컨트롤 플레인 업그레이드 커맨드를 /tmp/upgrade-apply-cmd.sh 에 작성하세요.
    1) kubeadm upgrade apply v1.34.0
    2) 컨트롤 플레인 노드 drain
    3) kubelet=1.34.* / kubectl=1.34.* 설치
    4) systemctl daemon-reload
    5) systemctl restart kubelet
    6) 컨트롤 플레인 노드 uncordon
EOF
}
validate_q104() {
  [[ -f /tmp/upgrade-apply-cmd.sh ]] || { echo -e "  ${RED}✗ /tmp/upgrade-apply-cmd.sh not found${NC}"; return 1; }
  local content; content=$(cat /tmp/upgrade-apply-cmd.sh)
  local ok=true
  [[ "$content" != *"upgrade apply"*"1.34"* ]]       && { echo -e "  ${RED}✗ 'kubeadm upgrade apply v1.34' missing${NC}"; ok=false; }
  [[ "$content" != *"drain"* ]]                      && { echo -e "  ${RED}✗ drain step missing${NC}"; ok=false; }
  [[ "$content" != *"kubelet"*"1.34"* ]]             && { echo -e "  ${RED}✗ kubelet v1.34 install missing${NC}"; ok=false; }
  [[ "$content" != *"daemon-reload"* ]]              && { echo -e "  ${RED}✗ systemctl daemon-reload missing${NC}"; ok=false; }
  [[ "$content" != *"restart kubelet"* ]]            && { echo -e "  ${RED}✗ systemctl restart kubelet missing${NC}"; ok=false; }
  [[ "$content" != *"uncordon"* ]]                   && { echo -e "  ${RED}✗ uncordon step missing${NC}"; ok=false; }
  [[ "$ok" == "true" ]] && echo -e "  ${GREEN}✓ Control plane upgrade commands correct.${NC}"
  [[ "$ok" == "true" ]]
}
hint_q104() { cat <<'EOF'
  cat > /tmp/upgrade-apply-cmd.sh <<'SCRIPT'
  kubeadm upgrade apply v1.34.0 -y
  kubectl drain <control-plane-node> --ignore-daemonsets
  apt-get install -y kubelet=1.34.* kubectl=1.34.*
  systemctl daemon-reload
  systemctl restart kubelet
  kubectl uncordon <control-plane-node>
  SCRIPT
EOF
}

# ─── Q105 ─────────────────────────────────────────────────────────────────────
setup_q105() {
  rm -f /tmp/upgrade-worker-cmd.sh 2>/dev/null
  echo "Write worker node upgrade commands to /tmp/upgrade-worker-cmd.sh"
}
show_q105() { cat <<'EOF'
  TASK — kubeadm Upgrade: Worker Node (Command File)
  ──────────────────────────────────────────────────────────────
  Write worker node upgrade commands to:
    /tmp/upgrade-worker-cmd.sh

  Steps required (run ON THE WORKER NODE):
    1. apt-get install kubeadm=1.34.*
    2. kubeadm upgrade node
    3. apt-get install kubelet=1.34.* kubectl=1.34.*
    4. systemctl daemon-reload
    5. systemctl restart kubelet

  And from the CONTROL PLANE:
    - Drain worker before upgrade
    - Uncordon worker after upgrade

  ── 한국어 ─────────────────────────────────────────────
  워커 노드 업그레이드 커맨드를 /tmp/upgrade-worker-cmd.sh 에 작성하세요.
    컨트롤 플레인에서: 업그레이드 전 drain, 후 uncordon
    워커 노드에서: kubeadm=1.34.* 설치 → kubeadm upgrade node → kubelet 업그레이드
EOF
}
validate_q105() {
  [[ -f /tmp/upgrade-worker-cmd.sh ]] || { echo -e "  ${RED}✗ /tmp/upgrade-worker-cmd.sh not found${NC}"; return 1; }
  local content; content=$(cat /tmp/upgrade-worker-cmd.sh)
  local ok=true
  [[ "$content" != *"upgrade node"* ]]               && { echo -e "  ${RED}✗ 'kubeadm upgrade node' missing${NC}"; ok=false; }
  [[ "$content" != *"kubelet"*"1.34"* ]]             && { echo -e "  ${RED}✗ kubelet v1.34 install missing${NC}"; ok=false; }
  [[ "$content" != *"daemon-reload"* ]]              && { echo -e "  ${RED}✗ daemon-reload missing${NC}"; ok=false; }
  [[ "$content" != *"drain"* ]]                      && { echo -e "  ${RED}✗ drain step missing${NC}"; ok=false; }
  [[ "$content" != *"uncordon"* ]]                   && { echo -e "  ${RED}✗ uncordon step missing${NC}"; ok=false; }
  [[ "$ok" == "true" ]] && echo -e "  ${GREEN}✓ Worker node upgrade commands correct.${NC}"
  [[ "$ok" == "true" ]]
}
hint_q105() { cat <<'EOF'
  cat > /tmp/upgrade-worker-cmd.sh <<'SCRIPT'
  # From control plane:
  kubectl drain <worker-node> --ignore-daemonsets --delete-emptydir-data

  # On worker node:
  apt-get install -y kubeadm=1.34.*
  kubeadm upgrade node
  apt-get install -y kubelet=1.34.* kubectl=1.34.*
  systemctl daemon-reload
  systemctl restart kubelet

  # From control plane:
  kubectl uncordon <worker-node>
  SCRIPT
EOF
}

# ─── Q106 ─────────────────────────────────────────────────────────────────────
setup_q106() {
  kubectl delete namespace psa-restricted 2>/dev/null
  kubectl create namespace psa-restricted 2>/dev/null
  echo "Namespace 'psa-restricted' created. Apply PSA enforce=restricted label."
}
show_q106() { cat <<'EOF'
  TASK — Pod Security Admission: enforce restricted
  ──────────────────────────────────────────────────────────────
  Apply Pod Security Admission label to namespace 'psa-restricted':
    Mode:    enforce
    Level:   restricted
    Version: latest

  Label format:
    pod-security.kubernetes.io/enforce=restricted
    pod-security.kubernetes.io/enforce-version=latest

  Verify:
    kubectl get namespace psa-restricted --show-labels

  ── 한국어 ─────────────────────────────────────────────
  네임스페이스 'psa-restricted' 에 PSA 라벨을 적용하세요:
    모드: enforce / 레벨: restricted / 버전: latest
  미준수 파드는 자동으로 거부됩니다.
EOF
}
validate_q106() {
  local enforce; enforce=$(kubectl get namespace psa-restricted \
    -o jsonpath='{.metadata.labels.pod-security\.kubernetes\.io/enforce}' 2>/dev/null)
  [[ "$enforce" != "restricted" ]] && { echo -e "  ${RED}✗ enforce label=$enforce (want restricted)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Namespace 'psa-restricted' has enforce=restricted label.${NC}"
}
hint_q106() { cat <<'EOF'
  kubectl label namespace psa-restricted \
    pod-security.kubernetes.io/enforce=restricted \
    pod-security.kubernetes.io/enforce-version=latest
EOF
}

# ─── Q107 ─────────────────────────────────────────────────────────────────────
setup_q107() {
  kubectl delete namespace psa-warn 2>/dev/null
  kubectl create namespace psa-warn 2>/dev/null
  echo "Namespace 'psa-warn' created. Apply PSA warn=baseline label."
}
show_q107() { cat <<'EOF'
  TASK — Pod Security Admission: warn baseline
  ──────────────────────────────────────────────────────────────
  Apply PSA warn label to namespace 'psa-warn':
    Mode:    warn
    Level:   baseline
    Version: latest

  Labels:
    pod-security.kubernetes.io/warn=baseline
    pod-security.kubernetes.io/warn-version=latest

  Verify:
    kubectl get namespace psa-warn --show-labels

  ── 한국어 ─────────────────────────────────────────────
  네임스페이스 'psa-warn' 에 PSA warn 라벨을 적용하세요:
    모드: warn / 레벨: baseline / 버전: latest
  미준수 파드는 거부되지 않고 경고만 표시됩니다.
EOF
}
validate_q107() {
  local warn; warn=$(kubectl get namespace psa-warn \
    -o jsonpath='{.metadata.labels.pod-security\.kubernetes\.io/warn}' 2>/dev/null)
  [[ "$warn" != "baseline" ]] && { echo -e "  ${RED}✗ warn label=$warn (want baseline)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Namespace 'psa-warn' has warn=baseline label.${NC}"
}
hint_q107() { cat <<'EOF'
  kubectl label namespace psa-warn \
    pod-security.kubernetes.io/warn=baseline \
    pod-security.kubernetes.io/warn-version=latest
EOF
}

# ─── Q108 ─────────────────────────────────────────────────────────────────────
setup_q108() {
  kubectl delete namespace psa-test 2>/dev/null
  kubectl create namespace psa-test 2>/dev/null
  kubectl label namespace psa-test \
    pod-security.kubernetes.io/enforce=restricted \
    pod-security.kubernetes.io/enforce-version=latest 2>/dev/null
  echo "Namespace 'psa-test' has enforce=restricted. Try creating a privileged pod — it should be rejected."
}
show_q108() { cat <<'EOF'
  TASK — PSA: Verify Restricted Policy Blocks Privileged Pod
  ──────────────────────────────────────────────────────────────
  Namespace 'psa-test' has enforce=restricted.

  Step 1: Try to create a privileged pod (it should be REJECTED):
    kubectl run bad-pod --image=nginx:1.27 -n psa-test \
      --overrides='{"spec":{"containers":[{"name":"c","image":"nginx:1.27","securityContext":{"privileged":true}}]}}'

  Step 2: Save the error message to /tmp/psa-rejection.txt

  Step 3: Create a compliant pod 'good-pod' in 'psa-test':
    Image: nginx:1.27
    securityContext:
      runAsNonRoot: true
      runAsUser: 1000
      allowPrivilegeEscalation: false
      capabilities: { drop: ["ALL"] }
      seccompProfile: { type: RuntimeDefault }

  ── 한국어 ─────────────────────────────────────────────
  네임스페이스 'psa-test' 는 enforce=restricted 라벨이 적용되어 있습니다.
  1단계: 특권드 파드 생성 시도 → 거부 메시지를 /tmp/psa-rejection.txt 에 저장
  2단계: 규정 준수 Pod 'good-pod' 생성 (runAsNonRoot, capabilities drop ALL 등)
EOF
}
validate_q108() {
  local ok=true
  [[ -f /tmp/psa-rejection.txt ]] || { echo -e "  ${RED}✗ /tmp/psa-rejection.txt not found${NC}"; ok=false; }
  if [[ -f /tmp/psa-rejection.txt ]]; then
    local content; content=$(cat /tmp/psa-rejection.txt)
    [[ "$content" != *"violates"* && "$content" != *"forbidden"* && "$content" != *"policy"* ]] \
      && { echo -e "  ${RED}✗ Rejection message doesn't contain expected PSA error${NC}"; ok=false; }
  fi
  kubectl get pod good-pod -n psa-test &>/dev/null || { echo -e "  ${RED}✗ 'good-pod' not found in psa-test${NC}"; ok=false; }
  if [[ "$ok" == "true" ]]; then
    local rnu; rnu=$(kubectl get pod good-pod -n psa-test \
      -o jsonpath='{.spec.containers[0].securityContext.runAsNonRoot}')
    [[ "$rnu" != "true" ]] && { echo -e "  ${RED}✗ good-pod missing runAsNonRoot=true${NC}"; ok=false; }
  fi
  [[ "$ok" == "true" ]] && echo -e "  ${GREEN}✓ PSA correctly blocks privileged pod. Compliant pod running.${NC}"
  [[ "$ok" == "true" ]]
}
hint_q108() { cat <<'EOF'
  # Step 1 & 2: Try privileged pod and capture rejection
  kubectl run bad-pod --image=nginx:1.27 -n psa-test \
    --overrides='{"spec":{"containers":[{"name":"c","image":"nginx:1.27","securityContext":{"privileged":true}}]}}' \
    2>/tmp/psa-rejection.txt || true

  # Step 3: Compliant pod YAML
  apiVersion: v1
  kind: Pod
  metadata:
    name: good-pod
    namespace: psa-test
  spec:
    securityContext:
      runAsNonRoot: true
      runAsUser: 1000
      seccompProfile:
        type: RuntimeDefault
    containers:
    - name: nginx
      image: nginx:1.27
      securityContext:
        allowPrivilegeEscalation: false
        capabilities:
          drop: ["ALL"]
EOF
}

# ─── Q109 ─────────────────────────────────────────────────────────────────────
setup_q109() {
  _ns cka-q109
  kubectl delete hpa cpu-hpa -n cka-q109 2>/dev/null
  kubectl delete deployment web-app -n cka-q109 2>/dev/null
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: apps/v1
kind: Deployment
metadata:
  name: web-app
  namespace: cka-q109
spec:
  replicas: 1
  selector:
    matchLabels:
      app: web-app
  template:
    metadata:
      labels:
        app: web-app
    spec:
      containers:
      - name: web
        image: nginx:1.27
        resources:
          requests:
            cpu: 100m
          limits:
            cpu: 200m
EOF
  echo "Deployment 'web-app' created in cka-q109."
}
show_q109() { cat <<'EOF'
  TASK — Create HPA (CPU-based)
  ──────────────────────────────────────────────────────────────
  Deployment 'web-app' exists in namespace 'cka-q109'.

  Create an HPA named 'cpu-hpa':
    Namespace:         cka-q109
    Target:            Deployment/web-app
    minReplicas:       1
    maxReplicas:       5
    CPU utilization:   60%

  Verify:
    kubectl get hpa cpu-hpa -n cka-q109

  ── 한국어 ─────────────────────────────────────────────
  'cka-q109' 네임스페이스에 HPA 'cpu-hpa' 를 생성하세요:
    대상: Deployment/web-app
    minReplicas: 1 / maxReplicas: 5 / CPU 유틸리제이션: 60%
EOF
}
validate_q109() {
  kubectl get hpa cpu-hpa -n cka-q109 &>/dev/null || { echo -e "  ${RED}✗ HPA 'cpu-hpa' not found${NC}"; return 1; }
  local min max cpu
  min=$(kubectl get hpa cpu-hpa -n cka-q109 -o jsonpath='{.spec.minReplicas}')
  max=$(kubectl get hpa cpu-hpa -n cka-q109 -o jsonpath='{.spec.maxReplicas}')
  cpu=$(kubectl get hpa cpu-hpa -n cka-q109 \
    -o jsonpath='{.spec.metrics[0].resource.target.averageUtilization}')
  local ok=true
  [[ "$min" != "1" ]]  && { echo -e "  ${RED}✗ minReplicas=$min (want 1)${NC}"; ok=false; }
  [[ "$max" != "5" ]]  && { echo -e "  ${RED}✗ maxReplicas=$max (want 5)${NC}"; ok=false; }
  [[ "$cpu" != "60" ]] && { echo -e "  ${RED}✗ cpu target=$cpu% (want 60)${NC}"; ok=false; }
  [[ "$ok" == "true" ]] && echo -e "  ${GREEN}✓ HPA 'cpu-hpa' correctly configured.${NC}"
  [[ "$ok" == "true" ]]
}
hint_q109() { cat <<'EOF'
  kubectl autoscale deployment web-app \
    --name=cpu-hpa \
    --min=1 --max=5 --cpu-percent=60 \
    -n cka-q109
EOF
}

# ─── Q110 ─────────────────────────────────────────────────────────────────────
setup_q110() {
  _ns cka-q110
  kubectl delete hpa app-hpa -n cka-q110 2>/dev/null
  kubectl delete deployment backend -n cka-q110 2>/dev/null
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: apps/v1
kind: Deployment
metadata:
  name: backend
  namespace: cka-q110
spec:
  replicas: 2
  selector:
    matchLabels:
      app: backend
  template:
    metadata:
      labels:
        app: backend
    spec:
      containers:
      - name: app
        image: nginx:1.27
        resources:
          requests:
            cpu: 100m
EOF
  echo "Deployment 'backend' created in cka-q110."
}
show_q110() { cat <<'EOF'
  TASK — HPA with Custom Min/Max Replicas
  ──────────────────────────────────────────────────────────────
  Deployment 'backend' exists in namespace 'cka-q110'.

  Create HPA 'app-hpa':
    Namespace:    cka-q110
    Target:       Deployment/backend
    minReplicas:  2
    maxReplicas:  10
    CPU target:   75%

  ── 한국어 ─────────────────────────────────────────────
  'cka-q110' 의 Deployment 'backend' 를 대상으로 HPA 'app-hpa' 를 생성하세요:
    minReplicas: 2 / maxReplicas: 10 / CPU 목표: 75%
EOF
}
validate_q110() {
  kubectl get hpa app-hpa -n cka-q110 &>/dev/null || { echo -e "  ${RED}✗ HPA 'app-hpa' not found${NC}"; return 1; }
  local min max cpu
  min=$(kubectl get hpa app-hpa -n cka-q110 -o jsonpath='{.spec.minReplicas}')
  max=$(kubectl get hpa app-hpa -n cka-q110 -o jsonpath='{.spec.maxReplicas}')
  cpu=$(kubectl get hpa app-hpa -n cka-q110 \
    -o jsonpath='{.spec.metrics[0].resource.target.averageUtilization}')
  local ok=true
  [[ "$min" != "2" ]]  && { echo -e "  ${RED}✗ minReplicas=$min (want 2)${NC}"; ok=false; }
  [[ "$max" != "10" ]] && { echo -e "  ${RED}✗ maxReplicas=$max (want 10)${NC}"; ok=false; }
  [[ "$cpu" != "75" ]] && { echo -e "  ${RED}✗ cpu target=$cpu% (want 75)${NC}"; ok=false; }
  [[ "$ok" == "true" ]] && echo -e "  ${GREEN}✓ HPA 'app-hpa' min=2, max=10, cpu=75%.${NC}"
  [[ "$ok" == "true" ]]
}
hint_q110() { cat <<'EOF'
  kubectl autoscale deployment backend \
    --name=app-hpa \
    --min=2 --max=10 --cpu-percent=75 \
    -n cka-q110
EOF
}

# ─── Q111 ─────────────────────────────────────────────────────────────────────
setup_q111() {
  _ns cka-q111
  kubectl delete hpa stable-hpa -n cka-q111 2>/dev/null
  kubectl delete deployment stable-app -n cka-q111 2>/dev/null
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: apps/v1
kind: Deployment
metadata:
  name: stable-app
  namespace: cka-q111
spec:
  replicas: 3
  selector:
    matchLabels:
      app: stable-app
  template:
    metadata:
      labels:
        app: stable-app
    spec:
      containers:
      - name: app
        image: nginx:1.27
        resources:
          requests:
            cpu: 100m
EOF
  echo "Deployment 'stable-app' created in cka-q111."
}
show_q111() { cat <<'EOF'
  TASK — HPA with ScaleDown Stabilization Window
  ──────────────────────────────────────────────────────────────
  Deployment 'stable-app' exists in namespace 'cka-q111'.

  Create HPA 'stable-hpa' using YAML (kubectl autoscale doesn't support behavior):
    Namespace:    cka-q111
    Target:       Deployment/stable-app
    minReplicas:  2
    maxReplicas:  8
    CPU target:   50%
    behavior:
      scaleDown:
        stabilizationWindowSeconds: 300

  ── 한국어 ─────────────────────────────────────────────
  YAML 로 HPA 'stable-hpa' 를 생성하세요:
    대상: Deployment/stable-app / min:2 / max:8 / CPU:50%
    behavior.scaleDown.stabilizationWindowSeconds: 300
  (kubectl autoscale 는 behavior 지원 안 함)
EOF
}
validate_q111() {
  kubectl get hpa stable-hpa -n cka-q111 &>/dev/null || { echo -e "  ${RED}✗ HPA 'stable-hpa' not found${NC}"; return 1; }
  local window; window=$(kubectl get hpa stable-hpa -n cka-q111 \
    -o jsonpath='{.spec.behavior.scaleDown.stabilizationWindowSeconds}')
  [[ "$window" != "300" ]] && { echo -e "  ${RED}✗ stabilizationWindowSeconds=$window (want 300)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ HPA 'stable-hpa' with scaleDown stabilizationWindowSeconds=300.${NC}"
}
hint_q111() { cat <<'EOF'
  apiVersion: autoscaling/v2
  kind: HorizontalPodAutoscaler
  metadata:
    name: stable-hpa
    namespace: cka-q111
  spec:
    scaleTargetRef:
      apiVersion: apps/v1
      kind: Deployment
      name: stable-app
    minReplicas: 2
    maxReplicas: 8
    metrics:
    - type: Resource
      resource:
        name: cpu
        target:
          type: Utilization
          averageUtilization: 50
    behavior:
      scaleDown:
        stabilizationWindowSeconds: 300
EOF
}

# ─── Q112 ─────────────────────────────────────────────────────────────────────
setup_q112() {
  _ns cka-q112
  kubectl delete pod downward-pod -n cka-q112 --force --grace-period=0 2>/dev/null
  echo "Namespace cka-q112 ready."
}
show_q112() { cat <<'EOF'
  TASK — Downward API: Pod Name as Env Var
  ──────────────────────────────────────────────────────────────
  Create Pod 'downward-pod' in namespace 'cka-q112':
    Image: nginx:1.27
    env:
      - name: POD_NAME
        valueFrom:
          fieldRef:
            fieldPath: metadata.name
      - name: POD_NAMESPACE
        valueFrom:
          fieldRef:
            fieldPath: metadata.namespace

  Verify:
    kubectl exec downward-pod -n cka-q112 -- env | grep POD_

  ── 한국어 ─────────────────────────────────────────────
  'cka-q112' 에 Pod 'downward-pod' 를 생성하세요:
    image: nginx:1.27
    env: POD_NAME (metadata.name), POD_NAMESPACE (metadata.namespace)
  Downward API로 파드 자신의 정보를 환경변수로 주입합니다.
EOF
}
validate_q112() {
  kubectl get pod downward-pod -n cka-q112 &>/dev/null || { echo -e "  ${RED}✗ Pod not found${NC}"; return 1; }
  local env; env=$(kubectl get pod downward-pod -n cka-q112 \
    -o jsonpath='{.spec.containers[0].env}')
  [[ "$env" != *"metadata.name"* ]]      && { echo -e "  ${RED}✗ POD_NAME (metadata.name) env missing${NC}"; return 1; }
  [[ "$env" != *"metadata.namespace"* ]] && { echo -e "  ${RED}✗ POD_NAMESPACE env missing${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Pod has Downward API env vars POD_NAME and POD_NAMESPACE.${NC}"
}
hint_q112() { cat <<'EOF'
  spec:
    containers:
    - name: nginx
      image: nginx:1.27
      env:
      - name: POD_NAME
        valueFrom:
          fieldRef:
            fieldPath: metadata.name
      - name: POD_NAMESPACE
        valueFrom:
          fieldRef:
            fieldPath: metadata.namespace
EOF
}

# ─── Q113 ─────────────────────────────────────────────────────────────────────
setup_q113() {
  _ns cka-q113
  kubectl delete pod resource-pod -n cka-q113 --force --grace-period=0 2>/dev/null
  echo "Namespace cka-q113 ready."
}
show_q113() { cat <<'EOF'
  TASK — Downward API: Resource Requests as Env Vars
  ──────────────────────────────────────────────────────────────
  Create Pod 'resource-pod' in namespace 'cka-q113':
    Image: nginx:1.27
    resources.requests.cpu:    250m
    resources.requests.memory: 64Mi
    env:
      - name: CPU_REQUEST
        valueFrom:
          resourceFieldRef:
            resource: requests.cpu
      - name: MEM_REQUEST
        valueFrom:
          resourceFieldRef:
            resource: requests.memory

  ── 한국어 ─────────────────────────────────────────────
  'cka-q113' 에 Pod 'resource-pod' 를 생성하세요:
    requests.cpu: 250m / requests.memory: 64Mi
    env: CPU_REQUEST (resourceFieldRef: requests.cpu)
         MEM_REQUEST (resourceFieldRef: requests.memory)
EOF
}
validate_q113() {
  kubectl get pod resource-pod -n cka-q113 &>/dev/null || { echo -e "  ${RED}✗ Pod not found${NC}"; return 1; }
  local env; env=$(kubectl get pod resource-pod -n cka-q113 \
    -o jsonpath='{.spec.containers[0].env}')
  [[ "$env" != *"requests.cpu"* ]]    && { echo -e "  ${RED}✗ CPU_REQUEST (requests.cpu) env missing${NC}"; return 1; }
  [[ "$env" != *"requests.memory"* ]] && { echo -e "  ${RED}✗ MEM_REQUEST (requests.memory) env missing${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Pod has Downward API resource env vars.${NC}"
}
hint_q113() { cat <<'EOF'
  spec:
    containers:
    - name: nginx
      image: nginx:1.27
      resources:
        requests:
          cpu: 250m
          memory: 64Mi
      env:
      - name: CPU_REQUEST
        valueFrom:
          resourceFieldRef:
            containerName: nginx
            resource: requests.cpu
      - name: MEM_REQUEST
        valueFrom:
          resourceFieldRef:
            containerName: nginx
            resource: requests.memory
EOF
}

# ─── Q114 ─────────────────────────────────────────────────────────────────────
setup_q114() {
  _ns cka-q114
  kubectl delete pod label-pod -n cka-q114 --force --grace-period=0 2>/dev/null
  echo "Namespace cka-q114 ready."
}
show_q114() { cat <<'EOF'
  TASK — Downward API: Pod Labels as Volume File
  ──────────────────────────────────────────────────────────────
  Create Pod 'label-pod' in namespace 'cka-q114':
    Labels: app=myapp, env=prod
    Image:  nginx:1.27
    volume (downwardAPI):
      name: pod-info
      items:
        - fieldRef: metadata.labels
          path: labels
    volumeMount: /etc/podinfo

  Verify:
    kubectl exec label-pod -n cka-q114 -- cat /etc/podinfo/labels

  ── 한국어 ─────────────────────────────────────────────
  'cka-q114' 에 Pod 'label-pod' 를 생성하세요 (labels: app=myapp, env=prod):
    downwardAPI 볼륨으로 metadata.labels 를 /etc/podinfo/labels 에 마운트
EOF
}
validate_q114() {
  kubectl get pod label-pod -n cka-q114 &>/dev/null || { echo -e "  ${RED}✗ Pod not found${NC}"; return 1; }
  local vols; vols=$(kubectl get pod label-pod -n cka-q114 \
    -o jsonpath='{.spec.volumes}')
  [[ "$vols" != *"downwardAPI"* ]] && { echo -e "  ${RED}✗ No downwardAPI volume found${NC}"; return 1; }
  [[ "$vols" != *"metadata.labels"* ]] && { echo -e "  ${RED}✗ metadata.labels not in volume${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Pod has downwardAPI volume with metadata.labels.${NC}"
}
hint_q114() { cat <<'EOF'
  spec:
    containers:
    - name: nginx
      image: nginx:1.27
      volumeMounts:
      - name: pod-info
        mountPath: /etc/podinfo
    volumes:
    - name: pod-info
      downwardAPI:
        items:
        - path: labels
          fieldRef:
            fieldPath: metadata.labels
EOF
}

# ─── Q115 ─────────────────────────────────────────────────────────────────────
setup_q115() {
  kubectl delete priorityclass high-priority 2>/dev/null
  _ns cka-q115
  kubectl delete pod priority-pod -n cka-q115 --force --grace-period=0 2>/dev/null
  echo "Namespace cka-q115 ready."
}
show_q115() { cat <<'EOF'
  TASK — Create PriorityClass + Assign to Pod
  ──────────────────────────────────────────────────────────────
  Step 1: Create PriorityClass 'high-priority':
    value:            1000000
    globalDefault:    false
    description:      "High priority workloads"

  Step 2: Create Pod 'priority-pod' in namespace 'cka-q115':
    Image:              nginx:1.27
    priorityClassName:  high-priority

  Verify:
    kubectl get priorityclass high-priority
    kubectl get pod priority-pod -n cka-q115 -o jsonpath='{.spec.priorityClassName}'

  ── 한국어 ─────────────────────────────────────────────
  1단계: PriorityClass 'high-priority' 생성 (value: 1000000)
  2단계: 'cka-q115' 에 Pod 'priority-pod' 생성 (priorityClassName: high-priority)
EOF
}
validate_q115() {
  kubectl get priorityclass high-priority &>/dev/null || { echo -e "  ${RED}✗ PriorityClass 'high-priority' not found${NC}"; return 1; }
  local val; val=$(kubectl get priorityclass high-priority -o jsonpath='{.value}')
  [[ "$val" != "1000000" ]] && { echo -e "  ${RED}✗ value=$val (want 1000000)${NC}"; return 1; }
  kubectl get pod priority-pod -n cka-q115 &>/dev/null || { echo -e "  ${RED}✗ Pod 'priority-pod' not found${NC}"; return 1; }
  local pc; pc=$(kubectl get pod priority-pod -n cka-q115 -o jsonpath='{.spec.priorityClassName}')
  [[ "$pc" != "high-priority" ]] && { echo -e "  ${RED}✗ priorityClassName=$pc (want high-priority)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ PriorityClass created and assigned to pod.${NC}"
}
hint_q115() { cat <<'EOF'
  apiVersion: scheduling.k8s.io/v1
  kind: PriorityClass
  metadata:
    name: high-priority
  value: 1000000
  globalDefault: false
  description: "High priority workloads"
  ---
  # Pod with priorityClassName:
  spec:
    priorityClassName: high-priority
    containers:
    - name: nginx
      image: nginx:1.27
EOF
}

# ─── Q116 ─────────────────────────────────────────────────────────────────────
setup_q116() {
  kubectl delete priorityclass low-priority 2>/dev/null
  _ns cka-q116
  kubectl delete pod low-pod high-pod -n cka-q116 --force --grace-period=0 2>/dev/null
  kubectl create priorityclass low-priority --value=100 2>/dev/null
  echo "PriorityClass 'low-priority' (value=100) created."
}
show_q116() { cat <<'EOF'
  TASK — PriorityClass: Low vs High Priority
  ──────────────────────────────────────────────────────────────
  PriorityClass 'low-priority' (value=100) exists.

  Step 1: Create PriorityClass 'critical':
    value: 999999

  Step 2: Create two pods in namespace 'cka-q116':
    Pod 'low-pod':
      Image:             nginx:1.27
      priorityClassName: low-priority

    Pod 'high-pod':
      Image:             nginx:1.27
      priorityClassName: critical

  Verify pods are Running and check their priority values:
    kubectl get pod -n cka-q116 -o custom-columns='NAME:.metadata.name,PRIORITY:.spec.priority'

  ── 한국어 ─────────────────────────────────────────────
  'low-priority' (value=100) 는 이미 존재합니다.
  1단계: PriorityClass 'critical' 생성 (value: 999999)
  2다계: 'cka-q116' 에 두 파드 생성:
    low-pod: priorityClassName=low-priority
    high-pod: priorityClassName=critical
EOF
}
validate_q116() {
  kubectl get priorityclass critical &>/dev/null || { echo -e "  ${RED}✗ PriorityClass 'critical' not found${NC}"; return 1; }
  kubectl get pod low-pod -n cka-q116 &>/dev/null  || { echo -e "  ${RED}✗ 'low-pod' not found${NC}"; return 1; }
  kubectl get pod high-pod -n cka-q116 &>/dev/null || { echo -e "  ${RED}✗ 'high-pod' not found${NC}"; return 1; }
  local lpc; lpc=$(kubectl get pod low-pod  -n cka-q116 -o jsonpath='{.spec.priorityClassName}')
  local hpc; hpc=$(kubectl get pod high-pod -n cka-q116 -o jsonpath='{.spec.priorityClassName}')
  [[ "$lpc" != "low-priority" ]] && { echo -e "  ${RED}✗ low-pod priorityClassName=$lpc${NC}"; return 1; }
  [[ "$hpc" != "critical"     ]] && { echo -e "  ${RED}✗ high-pod priorityClassName=$hpc${NC}"; return 1; }
  echo -e "  ${GREEN}✓ low-pod=low-priority, high-pod=critical. Priority ordering correct.${NC}"
}
hint_q116() { cat <<'EOF'
  kubectl create priorityclass critical --value=999999
  kubectl run low-pod  --image=nginx:1.27 -n cka-q116 \
    --overrides='{"spec":{"priorityClassName":"low-priority"}}'
  kubectl run high-pod --image=nginx:1.27 -n cka-q116 \
    --overrides='{"spec":{"priorityClassName":"critical"}}'
EOF
}

# ─── Q117 ─────────────────────────────────────────────────────────────────────
setup_q117() {
  rm -f /tmp/static-pod-cmd.sh 2>/dev/null
  echo "Write static pod creation steps to /tmp/static-pod-cmd.sh"
}
show_q117() {
  local cp; cp=$(_cp)
  cat <<EOF
  TASK — Static Pod: Write Manifest via kubectl exec
  ──────────────────────────────────────────────────────────────
  Control plane node: $cp

  In a kind cluster, static pods are placed at:
    /etc/kubernetes/manifests/

  Write commands to /tmp/static-pod-cmd.sh that:
    1. Use 'docker exec' (or kubectl exec) to access the control plane node
    2. Create /etc/kubernetes/manifests/static-test.yaml with:
       - name: static-test
       - image: nginx:1.27

  Then actually create the static pod by running:
    docker exec $cp sh -c "cat > /etc/kubernetes/manifests/static-test.yaml << 'MANIFEST'
    <your yaml here>
    MANIFEST"

  Verify:
    kubectl get pods -A | grep static-test

  ── 한국어 ─────────────────────────────────────────────
  kind 클러스터에서 스태틱 파드는 /etc/kubernetes/manifests/ 에 놓습니다.
  docker exec 또는 kubectl exec 로 컨트롤 플레인 노드에 접속하여
  /etc/kubernetes/manifests/static-test.yaml 을 작성하세요.
EOF
}
validate_q117() {
  local cp; cp=$(_cp)
  local pod; pod=$(kubectl get pods --all-namespaces --no-headers 2>/dev/null | grep "static-test")
  [[ -z "$pod" ]] && { echo -e "  ${RED}✗ Static pod 'static-test' not found${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Static pod 'static-test' is running.${NC}"
}
hint_q117() {
  local cp; cp=$(_cp)
  cat <<EOF
  # In kind, access the control plane container:
  docker exec $cp sh -c "cat > /etc/kubernetes/manifests/static-test.yaml << 'MANIFEST'
  apiVersion: v1
  kind: Pod
  metadata:
    name: static-test
  spec:
    containers:
    - name: nginx
      image: nginx:1.27
  MANIFEST"

  # Verify:
  kubectl get pods -A | grep static-test
EOF
}

# ─── Q118 ─────────────────────────────────────────────────────────────────────
setup_q118() {
  rm -f /tmp/kubelet-fix-cmd.sh 2>/dev/null
  echo "Write kubelet container-runtime-endpoint fix to /tmp/kubelet-fix-cmd.sh"
}
show_q118() { cat <<'EOF'
  TASK — kubelet: Fix container-runtime-endpoint (Command File)
  ──────────────────────────────────────────────────────────────
  A node's kubelet fails to start because container-runtime-endpoint
  is misconfigured.

  Write fix commands to /tmp/kubelet-fix-cmd.sh:
    1. Check kubelet error:
       journalctl -u kubelet --no-pager | tail -20
    2. Edit kubelet config or drop-in to set:
       --container-runtime-endpoint=unix:///run/containerd/containerd.sock
    3. Restart kubelet:
       systemctl daemon-reload && systemctl restart kubelet
    4. Verify:
       systemctl status kubelet

  ── 한국어 ─────────────────────────────────────────────
  kubelet 실행 실패 원인인 container-runtime-endpoint 재설정 커맨드를
  /tmp/kubelet-fix-cmd.sh 에 작성하세요.
    1) journalctl 로 원인 진단
    2) containerd.sock 엔드포인트 설정
    3) daemon-reload + restart kubelet
    4) 상태 확인
EOF
}
validate_q118() {
  [[ -f /tmp/kubelet-fix-cmd.sh ]] || { echo -e "  ${RED}✗ /tmp/kubelet-fix-cmd.sh not found${NC}"; return 1; }
  local content; content=$(cat /tmp/kubelet-fix-cmd.sh)
  local ok=true
  [[ "$content" != *"journalctl"* ]]              && { echo -e "  ${RED}✗ journalctl diagnostic step missing${NC}"; ok=false; }
  [[ "$content" != *"containerd.sock"* ]]         && { echo -e "  ${RED}✗ containerd.sock endpoint missing${NC}"; ok=false; }
  [[ "$content" != *"daemon-reload"* ]]           && { echo -e "  ${RED}✗ daemon-reload missing${NC}"; ok=false; }
  [[ "$content" != *"restart kubelet"* ]]         && { echo -e "  ${RED}✗ kubelet restart missing${NC}"; ok=false; }
  [[ "$ok" == "true" ]] && echo -e "  ${GREEN}✓ kubelet fix commands are correct.${NC}"
  [[ "$ok" == "true" ]]
}
hint_q118() { cat <<'EOF'
  cat > /tmp/kubelet-fix-cmd.sh <<'SCRIPT'
  # 1. Diagnose
  journalctl -u kubelet --no-pager | tail -20

  # 2. Fix: edit /etc/systemd/system/kubelet.service.d/10-kubeadm.conf
  # Add or update: --container-runtime-endpoint=unix:///run/containerd/containerd.sock

  # 3. Restart
  systemctl daemon-reload
  systemctl restart kubelet

  # 4. Verify
  systemctl status kubelet
  SCRIPT
EOF
}

# ─── Q119 ─────────────────────────────────────────────────────────────────────
setup_q119() {
  local w; w=$(_worker)
  kubectl uncordon "$w" 2>/dev/null
  echo "Worker '$w' ready for drain exercise."
}
show_q119() {
  local w; w=$(_worker)
  cat <<EOF
  TASK — Drain a Worker Node + Verify + Uncordon
  ──────────────────────────────────────────────────────────────
  Worker node: $w

  Steps:
    1. Drain '$w':
       kubectl drain $w --ignore-daemonsets --delete-emptydir-data --force
    2. Verify node is SchedulingDisabled:
       kubectl get node $w
    3. Uncordon the node:
       kubectl uncordon $w
    4. Verify node is Ready and schedulable again.

  Final state: node must be Ready (not SchedulingDisabled).

  ── 한국어 ─────────────────────────────────────────────
  워커 노드를 drain 한 후 uncordon 하세요.
    kubectl drain <노드> --ignore-daemonsets --delete-emptydir-data --force
    kubectl uncordon <노드>
  최종 상태: 노드가 Ready 이면서 스케줄링 가능해야 합니다.
EOF
}
validate_q119() {
  local w; w=$(_worker)
  local sched; sched=$(kubectl get node "$w" -o jsonpath='{.spec.unschedulable}')
  if [[ "$sched" == "true" ]]; then
    echo -e "  ${RED}✗ Node '$w' still cordoned. Run: kubectl uncordon $w${NC}"
    return 1
  fi
  local status; status=$(kubectl get node "$w" --no-headers | awk '{print $2}')
  echo -e "  ${GREEN}✓ Node '$w' is $status and schedulable.${NC}"
}
hint_q119() {
  local w; w=$(_worker)
  cat <<EOF
  kubectl drain $w --ignore-daemonsets --delete-emptydir-data --force
  kubectl get node $w
  kubectl uncordon $w
  kubectl get node $w
EOF
}

# ─── Q120 ─────────────────────────────────────────────────────────────────────
setup_q120() {
  rm -f /tmp/cluster-info.txt 2>/dev/null
  echo "Save cluster component info to /tmp/cluster-info.txt"
}
show_q120() { cat <<'EOF'
  TASK — Cluster Info + Node Status Check
  ──────────────────────────────────────────────────────────────
  Save the following to /tmp/cluster-info.txt:

    1. kubectl cluster-info
    2. kubectl get nodes -o wide
    3. kubectl get pods -n kube-system

  All three outputs must be in the file.

    cat /tmp/cluster-info.txt

  ── 한국어 ─────────────────────────────────────────────
  다음 3가지를 모두 /tmp/cluster-info.txt 에 저장하세요:
    1. kubectl cluster-info
    2. kubectl get nodes -o wide
    3. kubectl get pods -n kube-system
EOF
}
validate_q120() {
  [[ -f /tmp/cluster-info.txt ]] || { echo -e "  ${RED}✗ /tmp/cluster-info.txt not found${NC}"; return 1; }
  local content; content=$(cat /tmp/cluster-info.txt)
  local ok=true
  [[ "$content" != *"https://"* ]]      && { echo -e "  ${RED}✗ cluster-info output missing${NC}"; ok=false; }
  [[ "$content" != *"control-plane"* ]] && { echo -e "  ${RED}✗ nodes output missing${NC}"; ok=false; }
  [[ "$content" != *"kube-system"* ]]   && { echo -e "  ${RED}✗ kube-system pods output missing${NC}"; ok=false; }
  [[ "$ok" == "true" ]] && echo -e "  ${GREEN}✓ /tmp/cluster-info.txt contains all required outputs.${NC}"
  [[ "$ok" == "true" ]]
}
hint_q120() { cat <<'EOF'
  kubectl cluster-info          > /tmp/cluster-info.txt
  kubectl get nodes -o wide    >> /tmp/cluster-info.txt
  kubectl get pods -n kube-system >> /tmp/cluster-info.txt
EOF
}
