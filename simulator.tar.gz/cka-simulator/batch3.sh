#!/usr/bin/env bash
# Batch 3: ConfigMaps, Secrets & Storage (Q41–Q60) — sourced by run.sh

BATCH_TITLE="Batch 3 — ConfigMaps, Secrets & Storage (Q41–Q60)"
Q_TITLES=(""
  "Create ConfigMap from Literals"
  "Create ConfigMap from File"
  "Mount ConfigMap as Volume"
  "ConfigMap via envFrom"
  "Individual ConfigMap Keys as Env Vars"
  "Create a Generic Secret"
  "Mount Secret as Volume"
  "Secret as Individual Env Vars (secretKeyRef)"
  "Fix Pod: Wrong ConfigMap Key"
  "Fix Pod: Wrong Secret Name Reference"
  "Create PersistentVolume (hostPath)"
  "Create PVC Binding to PV"
  "Fix PVC Stuck in Pending (Wrong StorageClass)"
  "Pod Mounting a PVC"
  "Deployment with PVC Mount"
  "Pod with emptyDir Shared Volume"
  "Pod with hostPath Volume"
  "ConfigMap as Env + Volume in Same Pod"
  "Create docker-registry Secret + imagePullSecret"
  "Create PV + PVC + Pod (End-to-End)"
)

_ns() { kubectl create namespace "$1" --dry-run=client -o yaml | kubectl apply -f - 2>/dev/null; }

# ─── Q41 ─────────────────────────────────────────────────────────────────────
setup_q41() { _ns cka-q41; kubectl delete configmap app-config -n cka-q41 2>/dev/null; echo "Namespace cka-q41 ready."; }
show_q41() { cat <<'EOF'
  TASK — Create a ConfigMap from Literals
  ──────────────────────────────────────────────────────────────
  Create a ConfigMap in namespace 'cka-q41':
    Name:  app-config
    Data:
      ENV=production
      LOG_LEVEL=info
      MAX_CONN=100

  Verify:  kubectl describe configmap app-config -n cka-q41

  ── 한국어 ─────────────────────────────────────────────
  cka-q41 에 ConfigMap 'app-config' 를 리터럴 값으로 생성하세요.
    ENV=production / LOG_LEVEL=info / MAX_CONN=100
EOF
}
validate_q41() {
  kubectl get cm app-config -n cka-q41 &>/dev/null || { echo -e "  ${RED}✗ ConfigMap not found${NC}"; return 1; }
  local e l m
  e=$(kubectl get cm app-config -n cka-q41 -o jsonpath='{.data.ENV}')
  l=$(kubectl get cm app-config -n cka-q41 -o jsonpath='{.data.LOG_LEVEL}')
  m=$(kubectl get cm app-config -n cka-q41 -o jsonpath='{.data.MAX_CONN}')
  local ok=true
  [[ "$e" != "production" ]] && { echo -e "  ${RED}✗ ENV=$e (want production)${NC}"; ok=false; }
  [[ "$l" != "info"       ]] && { echo -e "  ${RED}✗ LOG_LEVEL=$l (want info)${NC}"; ok=false; }
  [[ "$m" != "100"        ]] && { echo -e "  ${RED}✗ MAX_CONN=$m (want 100)${NC}"; ok=false; }
  [[ "$ok" == "true" ]] && echo -e "  ${GREEN}✓ ConfigMap with all 3 keys created correctly.${NC}"
  [[ "$ok" == "true" ]]
}
hint_q41() { cat <<'EOF'
  kubectl create configmap app-config \
    --from-literal=ENV=production \
    --from-literal=LOG_LEVEL=info \
    --from-literal=MAX_CONN=100 \
    -n cka-q41
EOF
}

# ─── Q42 ─────────────────────────────────────────────────────────────────────
setup_q42() {
  _ns cka-q42
  kubectl delete configmap file-config -n cka-q42 2>/dev/null
  echo -e "DB_HOST=postgres\nDB_PORT=5432\nDB_NAME=myapp" > /tmp/db.properties
  echo "Namespace cka-q42 ready. Config file created at /tmp/db.properties"
}
show_q42() { cat <<'EOF'
  TASK — Create ConfigMap from File
  ──────────────────────────────────────────────────────────────
  A config file exists at: /tmp/db.properties
  (Contains: DB_HOST, DB_PORT, DB_NAME)

  Create a ConfigMap:
    Name:      file-config
    Namespace: cka-q42
    Source:    --from-env-file=/tmp/db.properties

  Verify:  kubectl get cm file-config -n cka-q42 -o yaml

  ── 한국어 ─────────────────────────────────────────────
  /tmp/db.properties 파일을 이용해 ConfigMap 'file-config' 를 생성하세요.
    --from-env-file=/tmp/db.properties 옵션 사용 (cka-q42 네임스페이스)
EOF
}
validate_q42() {
  kubectl get cm file-config -n cka-q42 &>/dev/null || { echo -e "  ${RED}✗ ConfigMap 'file-config' not found${NC}"; return 1; }
  local h; h=$(kubectl get cm file-config -n cka-q42 -o jsonpath='{.data.DB_HOST}')
  [[ "$h" != "postgres" ]] && { echo -e "  ${RED}✗ DB_HOST=$h (want postgres)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ ConfigMap 'file-config' created from /tmp/db.properties.${NC}"
}
hint_q42() { cat <<'EOF'
  cat /tmp/db.properties   # check the file first

  kubectl create configmap file-config \
    --from-env-file=/tmp/db.properties \
    -n cka-q42
EOF
}

# ─── Q43 ─────────────────────────────────────────────────────────────────────
setup_q43() {
  _ns cka-q43
  kubectl delete cm nginx-conf -n cka-q43 2>/dev/null
  kubectl delete pod cm-vol-pod -n cka-q43 --force --grace-period=0 2>/dev/null
  kubectl create configmap nginx-conf --from-literal=server.name=myserver --from-literal=port=8080 -n cka-q43 2>/dev/null
  echo "ConfigMap 'nginx-conf' created in cka-q43."
}
show_q43() { cat <<'EOF'
  TASK — Mount ConfigMap as Volume
  ──────────────────────────────────────────────────────────────
  ConfigMap 'nginx-conf' exists in namespace 'cka-q43'.

  Create Pod 'cm-vol-pod' in namespace 'cka-q43':
    Image:  nginx:1.25
    Mount ConfigMap 'nginx-conf' as a volume at path: /etc/config

  Verify:
    kubectl exec cm-vol-pod -n cka-q43 -- ls /etc/config
    # Should list: port  server.name

  ── 한국어 ─────────────────────────────────────────────
  cka-q43 의 ConfigMap 'nginx-conf' 를 볼륨으로 마운트하는
  파드 'cm-vol-pod' 를 생성하세요. (이미지: nginx:1.25, 마운트: /etc/config)
EOF
}
validate_q43() {
  kubectl get pod cm-vol-pod -n cka-q43 &>/dev/null || { echo -e "  ${RED}✗ Pod 'cm-vol-pod' not found${NC}"; return 1; }
  local vn; vn=$(kubectl get pod cm-vol-pod -n cka-q43 -o jsonpath='{.spec.volumes[0].configMap.name}')
  [[ "$vn" != "nginx-conf" ]] && { echo -e "  ${RED}✗ volume.configMap.name=$vn (want nginx-conf)${NC}"; return 1; }
  local mp; mp=$(kubectl get pod cm-vol-pod -n cka-q43 -o jsonpath='{.spec.containers[0].volumeMounts[0].mountPath}')
  [[ "$mp" != "/etc/config" ]] && { echo -e "  ${RED}✗ mountPath=$mp (want /etc/config)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ ConfigMap mounted as volume at /etc/config.${NC}"
}
hint_q43() { cat <<'EOF'
  spec:
    containers:
    - name: nginx
      image: nginx:1.25
      volumeMounts:
      - name: config-vol
        mountPath: /etc/config
    volumes:
    - name: config-vol
      configMap:
        name: nginx-conf
EOF
}

# ─── Q44 ─────────────────────────────────────────────────────────────────────
setup_q44() {
  _ns cka-q44
  kubectl delete cm app-env-cm -n cka-q44 2>/dev/null
  kubectl delete pod envfrom-pod -n cka-q44 --force --grace-period=0 2>/dev/null
  kubectl create configmap app-env-cm \
    --from-literal=ENV=staging \
    --from-literal=LOG_LEVEL=debug \
    -n cka-q44 2>/dev/null
  echo "ConfigMap 'app-env-cm' created in cka-q44."
}
show_q44() { cat <<'EOF'
  TASK — Inject All ConfigMap Keys via envFrom
  ──────────────────────────────────────────────────────────────
  ConfigMap 'app-env-cm' exists in namespace 'cka-q44'
  with keys: ENV, LOG_LEVEL

  Create Pod 'envfrom-pod':
    Image: nginx:1.25
    Namespace: cka-q44
    Inject ALL keys from 'app-env-cm' using envFrom

  Verify:
    kubectl exec envfrom-pod -n cka-q44 -- env | grep -E 'ENV|LOG_LEVEL'

  ── 한국어 ─────────────────────────────────────────────
  cka-q44 에 파드 'envfrom-pod' 를 생성하세요.
  ConfigMap 'app-env-cm' 의 모든 키를 envFrom 으로 한 번에 주입하세요.
EOF
}
validate_q44() {
  kubectl get pod envfrom-pod -n cka-q44 &>/dev/null || { echo -e "  ${RED}✗ Pod not found${NC}"; return 1; }
  local ef; ef=$(kubectl get pod envfrom-pod -n cka-q44 -o jsonpath='{.spec.containers[0].envFrom[0].configMapRef.name}')
  [[ "$ef" != "app-env-cm" ]] && { echo -e "  ${RED}✗ envFrom.configMapRef.name=$ef (want app-env-cm)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Pod uses envFrom with ConfigMap 'app-env-cm'.${NC}"
}
hint_q44() { cat <<'EOF'
  # In pod spec under containers:
  envFrom:
  - configMapRef:
      name: app-env-cm
EOF
}

# ─── Q45 ─────────────────────────────────────────────────────────────────────
setup_q45() {
  _ns cka-q45
  kubectl delete cm selector-cm -n cka-q45 2>/dev/null
  kubectl delete pod envkey-pod -n cka-q45 --force --grace-period=0 2>/dev/null
  kubectl create configmap selector-cm \
    --from-literal=database_host=mysql.default \
    --from-literal=database_port=3306 \
    --from-literal=debug_mode=false \
    -n cka-q45 2>/dev/null
  echo "ConfigMap 'selector-cm' with 3 keys in cka-q45."
}
show_q45() { cat <<'EOF'
  TASK — Use Specific ConfigMap Keys as Env Vars
  ──────────────────────────────────────────────────────────────
  ConfigMap 'selector-cm' in namespace 'cka-q45' has keys:
    database_host, database_port, debug_mode

  Create Pod 'envkey-pod' in namespace 'cka-q45':
    Image: nginx:1.25
    env:
      DB_HOST  ← from selector-cm key: database_host
      DB_PORT  ← from selector-cm key: database_port
    (Do NOT inject debug_mode)

  ── 한국어 ─────────────────────────────────────────────
  cka-q45 에 파드 'envkey-pod' 를 생성하세요.
  ConfigMap 'selector-cm' 의 특정 키만 선택적으로 env 로 주입:
    DB_HOST ← database_host / DB_PORT ← database_port (debug_mode 는 제외)
EOF
}
validate_q45() {
  kubectl get pod envkey-pod -n cka-q45 &>/dev/null || { echo -e "  ${RED}✗ Pod not found${NC}"; return 1; }
  local env_json; env_json=$(kubectl get pod envkey-pod -n cka-q45 -o jsonpath='{.spec.containers[0].env}')
  [[ "$env_json" != *"database_host"* ]] && { echo -e "  ${RED}✗ Missing configMapKeyRef for database_host${NC}"; return 1; }
  [[ "$env_json" != *"DB_HOST"*       ]] && { echo -e "  ${RED}✗ Missing env var DB_HOST${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Pod uses specific ConfigMap keys as env vars.${NC}"
}
hint_q45() { cat <<'EOF'
  env:
  - name: DB_HOST
    valueFrom:
      configMapKeyRef:
        name: selector-cm
        key: database_host
  - name: DB_PORT
    valueFrom:
      configMapKeyRef:
        name: selector-cm
        key: database_port
EOF
}

# ─── Q46 ─────────────────────────────────────────────────────────────────────
setup_q46() { _ns cka-q46; kubectl delete secret db-secret -n cka-q46 2>/dev/null; echo "Namespace cka-q46 ready."; }
show_q46() { cat <<'EOF'
  TASK — Create a Generic Secret
  ──────────────────────────────────────────────────────────────
  Create a Secret in namespace 'cka-q46':
    Name: db-secret
    Type: Opaque (generic)
    Data:
      username=dbadmin
      password=P@ssw0rd123

  Verify:
    kubectl get secret db-secret -n cka-q46
    kubectl get secret db-secret -n cka-q46 -o jsonpath='{.data.username}' | base64 -d

  ── 한국어 ─────────────────────────────────────────────
  cka-q46 에 Secret 'db-secret' 을 생성하세요. (타입: Opaque)
    username=dbadmin / password=P@ssw0rd123
  Secret 값은 자동으로 base64 인코딩됩니다.
EOF
}
validate_q46() {
  kubectl get secret db-secret -n cka-q46 &>/dev/null || { echo -e "  ${RED}✗ Secret 'db-secret' not found${NC}"; return 1; }
  local u p
  u=$(kubectl get secret db-secret -n cka-q46 -o jsonpath='{.data.username}' | base64 -d 2>/dev/null)
  p=$(kubectl get secret db-secret -n cka-q46 -o jsonpath='{.data.password}' | base64 -d 2>/dev/null)
  local ok=true
  [[ "$u" != "dbadmin"    ]] && { echo -e "  ${RED}✗ username=$u (want dbadmin)${NC}"; ok=false; }
  [[ "$p" != "P@ssw0rd123" ]] && { echo -e "  ${RED}✗ password wrong${NC}"; ok=false; }
  [[ "$ok" == "true" ]] && echo -e "  ${GREEN}✓ Secret 'db-secret' created with correct credentials.${NC}"
  [[ "$ok" == "true" ]]
}
hint_q46() { cat <<'EOF'
  kubectl create secret generic db-secret \
    --from-literal=username=dbadmin \
    --from-literal=password=P@ssw0rd123 \
    -n cka-q46
EOF
}

# ─── Q47 ─────────────────────────────────────────────────────────────────────
setup_q47() {
  _ns cka-q47
  kubectl delete secret tls-secret -n cka-q47 2>/dev/null
  kubectl delete pod secret-vol-pod -n cka-q47 --force --grace-period=0 2>/dev/null
  kubectl create secret generic tls-secret \
    --from-literal=cert=FAKE_CERT \
    --from-literal=key=FAKE_KEY \
    -n cka-q47 2>/dev/null
  echo "Secret 'tls-secret' created in cka-q47."
}
show_q47() { cat <<'EOF'
  TASK — Mount Secret as Volume
  ──────────────────────────────────────────────────────────────
  Secret 'tls-secret' exists in namespace 'cka-q47'.

  Create Pod 'secret-vol-pod':
    Image:  nginx:1.25
    Namespace: cka-q47
    Mount Secret 'tls-secret' as volume at: /etc/tls

  Verify:
    kubectl exec secret-vol-pod -n cka-q47 -- ls /etc/tls
    # Should list: cert  key

  ── 한국어 ─────────────────────────────────────────────
  cka-q47 의 Secret 'tls-secret' 을 볼륨으로 마운트하는
  파드 'secret-vol-pod' 를 생성하세요. (이미지: nginx:1.25, 마운트: /etc/tls)
EOF
}
validate_q47() {
  kubectl get pod secret-vol-pod -n cka-q47 &>/dev/null || { echo -e "  ${RED}✗ Pod not found${NC}"; return 1; }
  local sn; sn=$(kubectl get pod secret-vol-pod -n cka-q47 -o jsonpath='{.spec.volumes[0].secret.secretName}')
  [[ "$sn" != "tls-secret" ]] && { echo -e "  ${RED}✗ volume.secret.secretName=$sn (want tls-secret)${NC}"; return 1; }
  local mp; mp=$(kubectl get pod secret-vol-pod -n cka-q47 -o jsonpath='{.spec.containers[0].volumeMounts[0].mountPath}')
  [[ "$mp" != "/etc/tls" ]] && { echo -e "  ${RED}✗ mountPath=$mp (want /etc/tls)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Secret mounted as volume at /etc/tls.${NC}"
}
hint_q47() { cat <<'EOF'
  spec:
    containers:
    - name: nginx
      image: nginx:1.25
      volumeMounts:
      - name: secret-vol
        mountPath: /etc/tls
    volumes:
    - name: secret-vol
      secret:
        secretName: tls-secret
EOF
}

# ─── Q48 ─────────────────────────────────────────────────────────────────────
setup_q48() {
  _ns cka-q48
  kubectl delete secret api-creds -n cka-q48 2>/dev/null
  kubectl delete pod secret-env-pod -n cka-q48 --force --grace-period=0 2>/dev/null
  kubectl create secret generic api-creds \
    --from-literal=api_key=sk-abc123 \
    --from-literal=api_secret=xyz789 \
    -n cka-q48 2>/dev/null
  echo "Secret 'api-creds' created in cka-q48."
}
show_q48() { cat <<'EOF'
  TASK — Secret Keys as Individual Env Vars
  ──────────────────────────────────────────────────────────────
  Secret 'api-creds' exists in namespace 'cka-q48'
    Keys: api_key, api_secret

  Create Pod 'secret-env-pod':
    Image: nginx:1.25
    Namespace: cka-q48
    env:
      API_KEY    ← from api-creds key: api_key
      API_SECRET ← from api-creds key: api_secret

  Verify:
    kubectl exec secret-env-pod -n cka-q48 -- env | grep API

  ── 한국어 ─────────────────────────────────────────────
  cka-q48 에 파드 'secret-env-pod' 를 생성하세요.
  Secret 'api-creds' 의 키를 개별 환경변수로 주입:
    API_KEY ← api_key / API_SECRET ← api_secret
EOF
}
validate_q48() {
  kubectl get pod secret-env-pod -n cka-q48 &>/dev/null || { echo -e "  ${RED}✗ Pod not found${NC}"; return 1; }
  local env_json; env_json=$(kubectl get pod secret-env-pod -n cka-q48 -o jsonpath='{.spec.containers[0].env}')
  [[ "$env_json" != *"api_key"*    ]] && { echo -e "  ${RED}✗ Missing secretKeyRef for api_key${NC}"; return 1; }
  [[ "$env_json" != *"API_KEY"*    ]] && { echo -e "  ${RED}✗ Missing env var API_KEY${NC}"; return 1; }
  [[ "$env_json" != *"api-creds"*  ]] && { echo -e "  ${RED}✗ secretKeyRef doesn't reference 'api-creds'${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Pod injects Secret keys as env vars API_KEY and API_SECRET.${NC}"
}
hint_q48() { cat <<'EOF'
  env:
  - name: API_KEY
    valueFrom:
      secretKeyRef:
        name: api-creds
        key: api_key
  - name: API_SECRET
    valueFrom:
      secretKeyRef:
        name: api-creds
        key: api_secret
EOF
}

# ─── Q49 ─────────────────────────────────────────────────────────────────────
setup_q49() {
  _ns cka-q49
  kubectl delete cm settings -n cka-q49 2>/dev/null
  kubectl delete pod broken-cm-pod -n cka-q49 --force --grace-period=0 2>/dev/null
  kubectl create configmap settings --from-literal=database_url=postgres://db/app -n cka-q49 2>/dev/null
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: v1
kind: Pod
metadata:
  name: broken-cm-pod
  namespace: cka-q49
spec:
  containers:
  - name: app
    image: nginx:1.25
    env:
    - name: DB_URL
      valueFrom:
        configMapKeyRef:
          name: settings
          key: db_url          # WRONG: correct key is 'database_url'
EOF
  echo "Pod 'broken-cm-pod' referencing wrong ConfigMap key 'db_url' (correct is 'database_url')."
}
show_q49() { cat <<'EOF'
  TASK — Fix Pod: Wrong ConfigMap Key
  ──────────────────────────────────────────────────────────────
  Pod 'broken-cm-pod' in namespace 'cka-q49' is stuck because it
  references a ConfigMap key that does NOT exist.

  ConfigMap 'settings' has key: database_url
  Pod references key:           db_url   ← WRONG

  Fix the pod. (Delete and recreate — spec is immutable.)

    kubectl describe pod broken-cm-pod -n cka-q49

  ── 한국어 ─────────────────────────────────────────────
  cka-q49 의 파드 'broken-cm-pod' 가 존재하지 않는 ConfigMap 키를 참조합니다.
    잘못된 키: db_url → 올바른 키: database_url
  파드 YAML 을 수정해 삭제 후 재생성하세요.
EOF
}
validate_q49() {
  kubectl get pod broken-cm-pod -n cka-q49 &>/dev/null || { echo -e "  ${RED}✗ Pod not found${NC}"; return 1; }
  local key; key=$(kubectl get pod broken-cm-pod -n cka-q49 -o jsonpath='{.spec.containers[0].env[0].valueFrom.configMapKeyRef.key}')
  [[ "$key" != "database_url" ]] && { echo -e "  ${RED}✗ configMapKeyRef.key=$key (want database_url)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Pod now references correct key 'database_url'.${NC}"
}
hint_q49() { cat <<'EOF'
  kubectl get pod broken-cm-pod -n cka-q49 -o yaml > pod49.yaml
  # Edit: change  key: db_url  →  key: database_url
  kubectl delete pod broken-cm-pod -n cka-q49 --force --grace-period=0
  kubectl apply -f pod49.yaml
EOF
}

# ─── Q50 ─────────────────────────────────────────────────────────────────────
setup_q50() {
  _ns cka-q50
  kubectl delete secret real-secret -n cka-q50 2>/dev/null
  kubectl delete pod broken-secret-pod -n cka-q50 --force --grace-period=0 2>/dev/null
  kubectl create secret generic real-secret --from-literal=token=abc123 -n cka-q50 2>/dev/null
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: v1
kind: Pod
metadata:
  name: broken-secret-pod
  namespace: cka-q50
spec:
  containers:
  - name: app
    image: nginx:1.25
    env:
    - name: TOKEN
      valueFrom:
        secretKeyRef:
          name: fake-secret     # WRONG: secret 'fake-secret' doesn't exist
          key: token
EOF
  echo "Pod 'broken-secret-pod' referencing non-existent secret 'fake-secret' in cka-q50."
}
show_q50() { cat <<'EOF'
  TASK — Fix Pod: Wrong Secret Name Reference
  ──────────────────────────────────────────────────────────────
  Pod 'broken-secret-pod' in namespace 'cka-q50' references
  a Secret that does NOT exist: 'fake-secret'

  The correct Secret is: real-secret

  Fix the pod. (Delete and recreate — spec is immutable.)

    kubectl describe pod broken-secret-pod -n cka-q50

  ── 한국어 ─────────────────────────────────────────────
  cka-q50 의 파드 'broken-secret-pod' 가 존재하지 않는 Secret 'fake-secret' 을 참조합니다.
    올바른 Secret 이름: real-secret
  파드 YAML 을 수정해 삭제 후 재생성하세요.
EOF
}
validate_q50() {
  kubectl get pod broken-secret-pod -n cka-q50 &>/dev/null || { echo -e "  ${RED}✗ Pod not found${NC}"; return 1; }
  local sn; sn=$(kubectl get pod broken-secret-pod -n cka-q50 -o jsonpath='{.spec.containers[0].env[0].valueFrom.secretKeyRef.name}')
  [[ "$sn" != "real-secret" ]] && { echo -e "  ${RED}✗ secretKeyRef.name=$sn (want real-secret)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Pod now references correct Secret 'real-secret'.${NC}"
}
hint_q50() { cat <<'EOF'
  kubectl get pod broken-secret-pod -n cka-q50 -o yaml > pod50.yaml
  # Edit: name: fake-secret  →  name: real-secret
  kubectl delete pod broken-secret-pod -n cka-q50 --force --grace-period=0
  kubectl apply -f pod50.yaml
EOF
}

# ─── Q51 ─────────────────────────────────────────────────────────────────────
setup_q51() {
  kubectl delete pv pv-hostpath 2>/dev/null; sleep 2
  echo "PersistentVolume 'pv-hostpath' removed. Ready to create."
}
show_q51() { cat <<'EOF'
  TASK — Create a PersistentVolume (hostPath)
  ──────────────────────────────────────────────────────────────
  Create a PersistentVolume (cluster-level):
    Name:             pv-hostpath
    Capacity:         1Gi
    AccessModes:      ReadWriteOnce
    ReclaimPolicy:    Retain
    StorageClassName: manual
    hostPath:         /tmp/pv-hostpath

  Verify:  kubectl get pv pv-hostpath

  ── 한국어 ─────────────────────────────────────────────
  클러스터 레벨 PersistentVolume 'pv-hostpath' 를 생성하세요.
    용량: 1Gi / 접근 모드: ReadWriteOnce / 재활용 정책: Retain
    스토리지 클래스: manual / hostPath: /tmp/pv-hostpath
EOF
}
validate_q51() {
  kubectl get pv pv-hostpath &>/dev/null || { echo -e "  ${RED}✗ PV 'pv-hostpath' not found${NC}"; return 1; }
  local cap sc hp am
  cap=$(kubectl get pv pv-hostpath -o jsonpath='{.spec.capacity.storage}')
  sc=$(kubectl get pv pv-hostpath -o jsonpath='{.spec.storageClassName}')
  hp=$(kubectl get pv pv-hostpath -o jsonpath='{.spec.hostPath.path}')
  am=$(kubectl get pv pv-hostpath -o jsonpath='{.spec.accessModes[0]}')
  local ok=true
  [[ "$cap" != "1Gi"             ]] && { echo -e "  ${RED}✗ capacity=$cap (want 1Gi)${NC}"; ok=false; }
  [[ "$sc" != "manual"           ]] && { echo -e "  ${RED}✗ storageClass=$sc (want manual)${NC}"; ok=false; }
  [[ "$hp" != "/tmp/pv-hostpath" ]] && { echo -e "  ${RED}✗ hostPath=$hp (want /tmp/pv-hostpath)${NC}"; ok=false; }
  [[ "$am" != "ReadWriteOnce"    ]] && { echo -e "  ${RED}✗ accessMode=$am (want ReadWriteOnce)${NC}"; ok=false; }
  [[ "$ok" == "true" ]] && echo -e "  ${GREEN}✓ PersistentVolume created correctly.${NC}"
  [[ "$ok" == "true" ]]
}
hint_q51() { cat <<'EOF'
  apiVersion: v1
  kind: PersistentVolume
  metadata:
    name: pv-hostpath
  spec:
    capacity:
      storage: 1Gi
    accessModes:
    - ReadWriteOnce
    storageClassName: manual
    persistentVolumeReclaimPolicy: Retain
    hostPath:
      path: /tmp/pv-hostpath
EOF
}

# ─── Q52 ─────────────────────────────────────────────────────────────────────
setup_q52() {
  _ns cka-q52
  kubectl delete pvc data-claim -n cka-q52 2>/dev/null
  kubectl delete pv pv-for-q52 2>/dev/null; sleep 2
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: v1
kind: PersistentVolume
metadata:
  name: pv-for-q52
spec:
  capacity:
    storage: 500Mi
  accessModes:
  - ReadWriteOnce
  storageClassName: manual
  hostPath:
    path: /tmp/pv-q52
EOF
  echo "PV 'pv-for-q52' (500Mi, manual, RWO) created. Create a PVC that binds to it."
}
show_q52() { cat <<'EOF'
  TASK — Create a PVC that Binds to an Existing PV
  ──────────────────────────────────────────────────────────────
  PV 'pv-for-q52' exists (500Mi, StorageClass=manual, RWO).

  Create a PersistentVolumeClaim:
    Name:             data-claim
    Namespace:        cka-q52
    StorageClassName: manual
    AccessModes:      ReadWriteOnce
    Storage:          200Mi

  Verify: kubectl get pvc data-claim -n cka-q52
          STATUS should be: Bound

  ── 한국어 ─────────────────────────────────────────────
  기존 PV(pv-for-q52, 500Mi, manual, RWO) 에 바인딩될 PVC 를 생성하세요.
    이름: data-claim / 네임스페이스: cka-q52
    스토리지 클래스: manual / 요청 용량: 200Mi / STATUS: Bound 확인
EOF
}
validate_q52() {
  kubectl get pvc data-claim -n cka-q52 &>/dev/null || { echo -e "  ${RED}✗ PVC 'data-claim' not found${NC}"; return 1; }
  local status; status=$(kubectl get pvc data-claim -n cka-q52 -o jsonpath='{.status.phase}')
  [[ "$status" != "Bound" ]] && { echo -e "  ${RED}✗ PVC status=$status (want Bound)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ PVC 'data-claim' is Bound.${NC}"
}
hint_q52() { cat <<'EOF'
  apiVersion: v1
  kind: PersistentVolumeClaim
  metadata:
    name: data-claim
    namespace: cka-q52
  spec:
    accessModes:
    - ReadWriteOnce
    storageClassName: manual
    resources:
      requests:
        storage: 200Mi
EOF
}

# ─── Q53 ─────────────────────────────────────────────────────────────────────
setup_q53() {
  _ns cka-q53
  kubectl delete pvc broken-claim -n cka-q53 2>/dev/null
  kubectl delete pv pv-for-q53 2>/dev/null; sleep 2
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: v1
kind: PersistentVolume
metadata:
  name: pv-for-q53
spec:
  capacity:
    storage: 300Mi
  accessModes:
  - ReadWriteOnce
  storageClassName: correct-sc
  hostPath:
    path: /tmp/pv-q53
---
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: broken-claim
  namespace: cka-q53
spec:
  accessModes:
  - ReadWriteOnce
  storageClassName: wrong-sc
  resources:
    requests:
      storage: 100Mi
EOF
  echo "PV (storageClass=correct-sc) and PVC (storageClass=wrong-sc) created in cka-q53."
}
show_q53() { cat <<'EOF'
  TASK — Fix PVC Stuck in Pending
  ──────────────────────────────────────────────────────────────
  PVC 'broken-claim' in namespace 'cka-q53' is stuck in Pending.
  The PV 'pv-for-q53' exists but the storageClassName doesn't match.

  Find the mismatch and fix it. (Delete PVC and recreate with correct SC.)

    kubectl get pv pv-for-q53
    kubectl describe pvc broken-claim -n cka-q53

  ── 한국어 ─────────────────────────────────────────────
  cka-q53 의 PVC 'broken-claim' 이 Pending 상태입니다.
  PV 의 storageClass(correct-sc) 와 PVC 의 storageClass(wrong-sc) 가 불일치합니다.
  PVC 를 삭제하고 올바른 storageClass 로 재생성하세요.
EOF
}
validate_q53() {
  kubectl get pvc broken-claim -n cka-q53 &>/dev/null || { echo -e "  ${RED}✗ PVC not found${NC}"; return 1; }
  local status; status=$(kubectl get pvc broken-claim -n cka-q53 -o jsonpath='{.status.phase}')
  [[ "$status" != "Bound" ]] && { echo -e "  ${RED}✗ PVC status=$status (want Bound)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ PVC 'broken-claim' is now Bound.${NC}"
}
hint_q53() { cat <<'EOF'
  # Check PV storageClass:
  kubectl get pv pv-for-q53 -o jsonpath='{.spec.storageClassName}'
  # Returns: correct-sc

  kubectl delete pvc broken-claim -n cka-q53
  # Recreate with storageClassName: correct-sc
  apiVersion: v1
  kind: PersistentVolumeClaim
  metadata:
    name: broken-claim
    namespace: cka-q53
  spec:
    accessModes: [ReadWriteOnce]
    storageClassName: correct-sc
    resources:
      requests:
        storage: 100Mi
EOF
}

# ─── Q54 ─────────────────────────────────────────────────────────────────────
setup_q54() {
  _ns cka-q54
  kubectl delete pvc app-pvc -n cka-q54 2>/dev/null
  kubectl delete pod pvc-pod -n cka-q54 --force --grace-period=0 2>/dev/null
  kubectl delete pv pv-for-q54 2>/dev/null; sleep 2
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: v1
kind: PersistentVolume
metadata:
  name: pv-for-q54
spec:
  capacity:
    storage: 500Mi
  accessModes:
  - ReadWriteOnce
  storageClassName: manual
  hostPath:
    path: /tmp/pv-q54
---
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: app-pvc
  namespace: cka-q54
spec:
  accessModes:
  - ReadWriteOnce
  storageClassName: manual
  resources:
    requests:
      storage: 100Mi
EOF
  echo "PV and PVC 'app-pvc' ready in cka-q54."
}
show_q54() { cat <<'EOF'
  TASK — Create a Pod that Mounts a PVC
  ──────────────────────────────────────────────────────────────
  PVC 'app-pvc' exists in namespace 'cka-q54'.

  Create Pod 'pvc-pod':
    Image:     nginx:1.25
    Namespace: cka-q54
    Mount PVC 'app-pvc' at path: /data

  ── 한국어 ─────────────────────────────────────────────
  cka-q54 의 PVC 'app-pvc' 를 마운트하는 파드 'pvc-pod' 를 생성하세요.
    이미지: nginx:1.25 / 마운트 경로: /data
EOF
}
validate_q54() {
  kubectl get pod pvc-pod -n cka-q54 &>/dev/null || { echo -e "  ${RED}✗ Pod not found${NC}"; return 1; }
  local pvc; pvc=$(kubectl get pod pvc-pod -n cka-q54 -o jsonpath='{.spec.volumes[0].persistentVolumeClaim.claimName}')
  [[ "$pvc" != "app-pvc" ]] && { echo -e "  ${RED}✗ PVC claimName=$pvc (want app-pvc)${NC}"; return 1; }
  local mp; mp=$(kubectl get pod pvc-pod -n cka-q54 -o jsonpath='{.spec.containers[0].volumeMounts[0].mountPath}')
  [[ "$mp" != "/data" ]] && { echo -e "  ${RED}✗ mountPath=$mp (want /data)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Pod mounts PVC 'app-pvc' at /data.${NC}"
}
hint_q54() { cat <<'EOF'
  spec:
    containers:
    - name: nginx
      image: nginx:1.25
      volumeMounts:
      - name: data
        mountPath: /data
    volumes:
    - name: data
      persistentVolumeClaim:
        claimName: app-pvc
EOF
}

# ─── Q55 ─────────────────────────────────────────────────────────────────────
setup_q55() {
  _ns cka-q55
  kubectl delete deploy data-deploy -n cka-q55 2>/dev/null
  kubectl delete pvc deploy-pvc -n cka-q55 2>/dev/null
  kubectl delete pv pv-for-q55 2>/dev/null; sleep 2
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: v1
kind: PersistentVolume
metadata:
  name: pv-for-q55
spec:
  capacity:
    storage: 500Mi
  accessModes:
  - ReadWriteOnce
  storageClassName: manual
  hostPath:
    path: /tmp/pv-q55
---
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: deploy-pvc
  namespace: cka-q55
spec:
  accessModes:
  - ReadWriteOnce
  storageClassName: manual
  resources:
    requests:
      storage: 200Mi
EOF
  echo "PVC 'deploy-pvc' ready in cka-q55."
}
show_q55() { cat <<'EOF'
  TASK — Deployment with PVC Mount
  ──────────────────────────────────────────────────────────────
  PVC 'deploy-pvc' exists in namespace 'cka-q55'.

  Create Deployment 'data-deploy':
    Namespace: cka-q55
    Replicas:  2
    Image:     nginx:1.25
    Mount PVC 'deploy-pvc' at: /app/data

  ── 한국어 ─────────────────────────────────────────────
  cka-q55 에 Deployment 'data-deploy' 를 생성하세요.
    레플리카: 2 / 이미지: nginx:1.25
    PVC 'deploy-pvc' 를 /app/data 에 마운트
EOF
}
validate_q55() {
  kubectl get deploy data-deploy -n cka-q55 &>/dev/null || { echo -e "  ${RED}✗ Deployment not found${NC}"; return 1; }
  local pvc; pvc=$(kubectl get deploy data-deploy -n cka-q55 -o jsonpath='{.spec.template.spec.volumes[0].persistentVolumeClaim.claimName}')
  [[ "$pvc" != "deploy-pvc" ]] && { echo -e "  ${RED}✗ PVC claimName=$pvc (want deploy-pvc)${NC}"; return 1; }
  local mp; mp=$(kubectl get deploy data-deploy -n cka-q55 -o jsonpath='{.spec.template.spec.containers[0].volumeMounts[0].mountPath}')
  [[ "$mp" != "/app/data" ]] && { echo -e "  ${RED}✗ mountPath=$mp (want /app/data)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Deployment 'data-deploy' mounts PVC at /app/data.${NC}"
}
hint_q55() { cat <<'EOF'
  spec:
    template:
      spec:
        containers:
        - name: nginx
          image: nginx:1.25
          volumeMounts:
          - name: data
            mountPath: /app/data
        volumes:
        - name: data
          persistentVolumeClaim:
            claimName: deploy-pvc
EOF
}

# ─── Q56 ─────────────────────────────────────────────────────────────────────
setup_q56() { _ns cka-q56; kubectl delete pod emptydir-pod -n cka-q56 --force --grace-period=0 2>/dev/null; echo "Namespace cka-q56 ready."; }
show_q56() { cat <<'EOF'
  TASK — Pod with emptyDir Shared Between Two Containers
  ──────────────────────────────────────────────────────────────
  Create Pod 'emptydir-pod' in namespace 'cka-q56':
    Container 1: name=writer, image=busybox:1.36
                 command=["sh","-c","while true; do echo data >> /shared/log; sleep 5; done"]
                 volumeMount: /shared
    Container 2: name=reader, image=busybox:1.36
                 command=["sh","-c","while true; do cat /shared/log 2>/dev/null; sleep 5; done"]
                 volumeMount: /shared
    Volume: name=shared-vol, emptyDir: {}

  ── 한국어 ─────────────────────────────────────────────
  cka-q56 에 파드 'emptydir-pod' 를 생성하세요.
    writer 컨테이너: /shared/log 에 데이터 쓰기
    reader 컨테이너: /shared/log 읽기
    두 컨테이너가 emptyDir 볼륨 'shared-vol' 을 /shared 에 공유 마운트
EOF
}
validate_q56() {
  kubectl get pod emptydir-pod -n cka-q56 &>/dev/null || { echo -e "  ${RED}✗ Pod not found${NC}"; return 1; }
  local cnt; cnt=$(kubectl get pod emptydir-pod -n cka-q56 -o jsonpath='{.spec.containers}' | grep -o '"name"' | wc -l)
  [[ "$cnt" -lt 2 ]] && { echo -e "  ${RED}✗ Pod has $cnt container(s) (want 2)${NC}"; return 1; }
  local vol; vol=$(kubectl get pod emptydir-pod -n cka-q56 -o jsonpath='{.spec.volumes[0].emptyDir}')
  [[ -z "$vol" ]] && { echo -e "  ${RED}✗ No emptyDir volume found${NC}"; return 1; }
  local mounts; mounts=$(kubectl get pod emptydir-pod -n cka-q56 -o jsonpath='{range .spec.containers[*]}{.volumeMounts[*].mountPath}{" "}{end}')
  local shared_cnt; shared_cnt=$(echo "$mounts" | grep -o "/shared" | wc -l)
  [[ "$shared_cnt" -lt 2 ]] && { echo -e "  ${RED}✗ Only $shared_cnt container(s) mount /shared (want 2)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Pod has 2 containers sharing emptyDir at /shared.${NC}"
}
hint_q56() { cat <<'EOF'
  spec:
    containers:
    - name: writer
      image: busybox:1.36
      command: ["sh","-c","while true; do echo data >> /shared/log; sleep 5; done"]
      volumeMounts:
      - name: shared-vol
        mountPath: /shared
    - name: reader
      image: busybox:1.36
      command: ["sh","-c","while true; do cat /shared/log 2>/dev/null; sleep 5; done"]
      volumeMounts:
      - name: shared-vol
        mountPath: /shared
    volumes:
    - name: shared-vol
      emptyDir: {}
EOF
}

# ─── Q57 ─────────────────────────────────────────────────────────────────────
setup_q57() { _ns cka-q57; kubectl delete pod hostpath-pod -n cka-q57 --force --grace-period=0 2>/dev/null; echo "Namespace cka-q57 ready."; }
show_q57() { cat <<'EOF'
  TASK — Pod with hostPath Volume
  ──────────────────────────────────────────────────────────────
  Create Pod 'hostpath-pod' in namespace 'cka-q57':
    Image:      nginx:1.25
    volumeMount: mountPath=/host-logs
    volume:      hostPath.path=/var/log, type=Directory

  ── 한국어 ─────────────────────────────────────────────
  cka-q57 에 파드 'hostpath-pod' 를 생성하세요. (이미지: nginx:1.25)
    hostPath 볼륨: 노드의 /var/log 를 파드 /host-logs 에 마운트
EOF
}
validate_q57() {
  kubectl get pod hostpath-pod -n cka-q57 &>/dev/null || { echo -e "  ${RED}✗ Pod not found${NC}"; return 1; }
  local hp; hp=$(kubectl get pod hostpath-pod -n cka-q57 -o jsonpath='{.spec.volumes[0].hostPath.path}')
  [[ "$hp" != "/var/log" ]] && { echo -e "  ${RED}✗ hostPath.path=$hp (want /var/log)${NC}"; return 1; }
  local mp; mp=$(kubectl get pod hostpath-pod -n cka-q57 -o jsonpath='{.spec.containers[0].volumeMounts[0].mountPath}')
  [[ "$mp" != "/host-logs" ]] && { echo -e "  ${RED}✗ mountPath=$mp (want /host-logs)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Pod mounts host /var/log at /host-logs.${NC}"
}
hint_q57() { cat <<'EOF'
  spec:
    containers:
    - name: nginx
      image: nginx:1.25
      volumeMounts:
      - name: host-vol
        mountPath: /host-logs
    volumes:
    - name: host-vol
      hostPath:
        path: /var/log
        type: Directory
EOF
}

# ─── Q58 ─────────────────────────────────────────────────────────────────────
setup_q58() {
  _ns cka-q58
  kubectl delete cm dual-cm -n cka-q58 2>/dev/null
  kubectl delete pod dual-pod -n cka-q58 --force --grace-period=0 2>/dev/null
  kubectl create configmap dual-cm \
    --from-literal=MODE=production \
    --from-literal=config.properties="timeout=30\nretry=3" \
    -n cka-q58 2>/dev/null
  echo "ConfigMap 'dual-cm' created in cka-q58."
}
show_q58() { cat <<'EOF'
  TASK — ConfigMap as Both Env Vars AND Volume in Same Pod
  ──────────────────────────────────────────────────────────────
  ConfigMap 'dual-cm' exists in namespace 'cka-q58' with keys: MODE, config.properties

  Create Pod 'dual-pod':
    Image: nginx:1.25
    1. Inject key MODE as env var APP_MODE (using configMapKeyRef)
    2. Mount the entire ConfigMap as volume at /etc/config

  ── 한국어 ─────────────────────────────────────────────
  cka-q58 에 파드 'dual-pod' 를 생성하세요. ConfigMap 'dual-cm' 을 두 가지 방식으로 사용:
    1. 키 MODE → 환경변수 APP_MODE (configMapKeyRef)
    2. 전체 ConfigMap → 볼륨으로 /etc/config 에 마운트
EOF
}
validate_q58() {
  kubectl get pod dual-pod -n cka-q58 &>/dev/null || { echo -e "  ${RED}✗ Pod not found${NC}"; return 1; }
  local env_json; env_json=$(kubectl get pod dual-pod -n cka-q58 -o jsonpath='{.spec.containers[0].env}')
  [[ "$env_json" != *"MODE"*     ]] && { echo -e "  ${RED}✗ Missing env var referencing MODE${NC}"; return 1; }
  [[ "$env_json" != *"dual-cm"*  ]] && { echo -e "  ${RED}✗ env does not reference 'dual-cm'${NC}"; return 1; }
  local vol; vol=$(kubectl get pod dual-pod -n cka-q58 -o jsonpath='{.spec.volumes[0].configMap.name}')
  [[ "$vol" != "dual-cm" ]] && { echo -e "  ${RED}✗ volume.configMap.name=$vol (want dual-cm)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Pod uses ConfigMap as both env var and volume.${NC}"
}
hint_q58() { cat <<'EOF'
  spec:
    containers:
    - name: nginx
      image: nginx:1.25
      env:
      - name: APP_MODE
        valueFrom:
          configMapKeyRef:
            name: dual-cm
            key: MODE
      volumeMounts:
      - name: config-vol
        mountPath: /etc/config
    volumes:
    - name: config-vol
      configMap:
        name: dual-cm
EOF
}

# ─── Q59 ─────────────────────────────────────────────────────────────────────
setup_q59() {
  _ns cka-q59
  kubectl delete secret registry-creds -n cka-q59 2>/dev/null
  kubectl delete pod private-pod -n cka-q59 --force --grace-period=0 2>/dev/null
  echo "Namespace cka-q59 ready."
}
show_q59() { cat <<'EOF'
  TASK — Create docker-registry Secret + Use as imagePullSecret
  ──────────────────────────────────────────────────────────────
  Step 1: Create a docker-registry secret:
    Name:      registry-creds
    Namespace: cka-q59
    Server:    registry.example.com
    Username:  myuser
    Password:  mypassword

  Step 2: Create Pod 'private-pod':
    Image:           nginx:1.25
    Namespace:       cka-q59
    imagePullSecrets: [registry-creds]

  ── 한국어 ─────────────────────────────────────────────
  cka-q59 에서 두 단계를 수행하세요:
    1. docker-registry 타입 Secret 'registry-creds' 생성
       (서버: registry.example.com, 사용자: myuser, 비밀번호: mypassword)
    2. 해당 Secret 을 imagePullSecrets 로 사용하는 파드 'private-pod' 생성
EOF
}
validate_q59() {
  kubectl get secret registry-creds -n cka-q59 &>/dev/null || { echo -e "  ${RED}✗ Secret 'registry-creds' not found${NC}"; return 1; }
  local t; t=$(kubectl get secret registry-creds -n cka-q59 -o jsonpath='{.type}')
  [[ "$t" != "kubernetes.io/dockerconfigjson" ]] && { echo -e "  ${RED}✗ type=$t (want kubernetes.io/dockerconfigjson)${NC}"; return 1; }
  kubectl get pod private-pod -n cka-q59 &>/dev/null || { echo -e "  ${RED}✗ Pod 'private-pod' not found${NC}"; return 1; }
  local ips; ips=$(kubectl get pod private-pod -n cka-q59 -o jsonpath='{.spec.imagePullSecrets[0].name}')
  [[ "$ips" != "registry-creds" ]] && { echo -e "  ${RED}✗ imagePullSecrets[0]=$ips (want registry-creds)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ docker-registry secret created and used as imagePullSecret.${NC}"
}
hint_q59() { cat <<'EOF'
  kubectl create secret docker-registry registry-creds \
    --docker-server=registry.example.com \
    --docker-username=myuser \
    --docker-password=mypassword \
    -n cka-q59

  # In pod spec:
  imagePullSecrets:
  - name: registry-creds
EOF
}

# ─── Q60 ─────────────────────────────────────────────────────────────────────
setup_q60() {
  _ns cka-q60
  kubectl delete pod e2e-pod -n cka-q60 --force --grace-period=0 2>/dev/null
  kubectl delete pvc e2e-pvc -n cka-q60 2>/dev/null
  kubectl delete pv e2e-pv 2>/dev/null; sleep 2
  echo "All resources removed. Create PV, PVC, and Pod from scratch."
}
show_q60() { cat <<'EOF'
  TASK — End-to-End: PV + PVC + Pod
  ──────────────────────────────────────────────────────────────
  Create ALL of the following:

  1. PersistentVolume 'e2e-pv'
     capacity=500Mi, storageClass=e2e-sc, accessModes=RWO
     hostPath=/tmp/e2e

  2. PersistentVolumeClaim 'e2e-pvc'  (namespace cka-q60)
     storageClass=e2e-sc, accessModes=RWO, request=200Mi
     → Must be Bound

  3. Pod 'e2e-pod'  (namespace cka-q60)
     image=nginx:1.25
     Mount PVC 'e2e-pvc' at /storage

  ── 한국어 ─────────────────────────────────────────────
  PV + PVC + Pod 를 처음부터 모두 생성하세요:
    1. PV 'e2e-pv': 500Mi, storageClass=e2e-sc, RWO, hostPath=/tmp/e2e
    2. PVC 'e2e-pvc' (cka-q60): e2e-sc, RWO, 200Mi → Bound 확인
    3. Pod 'e2e-pod' (cka-q60): nginx:1.25, PVC 를 /storage 에 마운트
EOF
}
validate_q60() {
  kubectl get pv e2e-pv &>/dev/null || { echo -e "  ${RED}✗ PV 'e2e-pv' not found${NC}"; return 1; }
  kubectl get pvc e2e-pvc -n cka-q60 &>/dev/null || { echo -e "  ${RED}✗ PVC 'e2e-pvc' not found${NC}"; return 1; }
  kubectl get pod e2e-pod -n cka-q60 &>/dev/null || { echo -e "  ${RED}✗ Pod 'e2e-pod' not found${NC}"; return 1; }
  local pvc_status; pvc_status=$(kubectl get pvc e2e-pvc -n cka-q60 -o jsonpath='{.status.phase}')
  [[ "$pvc_status" != "Bound" ]] && { echo -e "  ${RED}✗ PVC status=$pvc_status (want Bound)${NC}"; return 1; }
  local mp; mp=$(kubectl get pod e2e-pod -n cka-q60 -o jsonpath='{.spec.containers[0].volumeMounts[0].mountPath}')
  [[ "$mp" != "/storage" ]] && { echo -e "  ${RED}✗ mountPath=$mp (want /storage)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ PV + PVC + Pod all created. PVC Bound. Pod mounts at /storage.${NC}"
}
hint_q60() { cat <<'EOF'
  # 1. PV
  kubectl apply -f - <<YAML
  apiVersion: v1
  kind: PersistentVolume
  metadata:
    name: e2e-pv
  spec:
    capacity: { storage: 500Mi }
    accessModes: [ReadWriteOnce]
    storageClassName: e2e-sc
    hostPath: { path: /tmp/e2e }
  YAML
  # 2. PVC
  # storageClassName: e2e-sc, request: 200Mi, namespace: cka-q60
  # 3. Pod
  # volumes: pvc claimName=e2e-pvc, mount at /storage
EOF
}
