#!/usr/bin/env bash
# Batch 5: Troubleshooting & Cluster Management (Q81–Q100) — sourced by run.sh

BATCH_TITLE="Batch 5 — Troubleshooting & Cluster Management (Q81–Q100)"
Q_TITLES=(""
  "Fix Deployment: ImagePullBackOff"
  "Fix Pod: CrashLoopBackOff (Bad Command)"
  "Fix Service: No Endpoints (Wrong Selector)"
  "Fix Deployment: Failing Readiness Probe"
  "Fix Pod: Stuck in Pending (Wrong NodeSelector)"
  "Find & Fix: Pod with Wrong ConfigMap Reference"
  "Find & Fix: Pod with Wrong Secret Key"
  "Fix Missing RBAC: ClusterRoleBinding"
  "Cordon + Drain + Uncordon a Node"
  "Fix Deployment: Wrong Port in Container"
  "Find All Not-Running Pods in a Namespace"
  "Fix PVC: Wrong StorageClass (Pending)"
  "Fix Pod: Missing Resource Limits Causing OOM"
  "Fix Deployment: Wrong Image Tag"
  "Label a Node + Verify Pod Scheduling"
  "Scale Down + Verify Pod Termination"
  "Fix Service: Wrong Protocol (UDP vs TCP)"
  "Create Namespace + LimitRange + Verify"
  "Fix Pod: Wrong PVC Claim Name"
  "Cluster Health Check: Nodes + System Pods"
)

_ns() { kubectl create namespace "$1" --dry-run=client -o yaml | kubectl apply -f - 2>/dev/null; }
_worker() {
  local w; w=$(kubectl get nodes --no-headers | grep -v 'control-plane\|master' | awk 'NR==1{print $1}')
  [[ -z "$w" ]] && w=$(kubectl get nodes --no-headers | awk 'NR==1{print $1}')
  echo "$w"
}

# ─── Q81 ─────────────────────────────────────────────────────────────────────
setup_q81() {
  _ns cka-q81
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: apps/v1
kind: Deployment
metadata:
  name: broken-image-deploy
  namespace: cka-q81
spec:
  replicas: 2
  selector:
    matchLabels:
      app: broken
  template:
    metadata:
      labels:
        app: broken
    spec:
      containers:
      - name: app
        image: nginx:DOES-NOT-EXIST-TAG
EOF
  echo "Deployment 'broken-image-deploy' with broken image in cka-q81."
}
show_q81() { cat <<'EOF'
  TASK — Fix Deployment: ImagePullBackOff
  ──────────────────────────────────────────────────────────────
  Deployment 'broken-image-deploy' in namespace 'cka-q81' has pods
  stuck in ImagePullBackOff / ErrImagePull.

  Fix: Update the image to nginx:1.25
  Ensure 2/2 replicas are Running.

    kubectl get pods -n cka-q81
    kubectl describe pod <pod-name> -n cka-q81

  ── 한국어 ─────────────────────────────────────────────
  'cka-q81' 의 Deployment 'broken-image-deploy' 파드가
  ImagePullBackOff / ErrImagePull 상태입니다.
  이미지를 nginx:1.25 로 수정하고 2/2 레플리카가 Running 상태인지 확인하세요.
EOF
}
validate_q81() {
  local img; img=$(kubectl get deploy broken-image-deploy -n cka-q81 \
    -o jsonpath='{.spec.template.spec.containers[0].image}' 2>/dev/null)
  [[ "$img" != "nginx:1.25" ]] && { echo -e "  ${RED}✗ image=$img (want nginx:1.25)${NC}"; return 1; }
  kubectl rollout status deploy/broken-image-deploy -n cka-q81 --timeout=60s &>/dev/null
  local r; r=$(kubectl get deploy broken-image-deploy -n cka-q81 -o jsonpath='{.status.readyReplicas}')
  [[ "$r" != "2" ]] && { echo -e "  ${RED}✗ only $r/2 ready${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Deployment fixed. nginx:1.25, 2/2 running.${NC}"
}
hint_q81() { cat <<'EOF'
  kubectl set image deployment/broken-image-deploy \
    app=nginx:1.25 -n cka-q81
  kubectl rollout status deployment/broken-image-deploy -n cka-q81
EOF
}

# ─── Q82 ─────────────────────────────────────────────────────────────────────
setup_q82() {
  _ns cka-q82
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: v1
kind: Pod
metadata:
  name: crashloop-pod
  namespace: cka-q82
spec:
  containers:
  - name: app
    image: busybox:1.36
    command: ["sh", "-c", "echo starting; exit 1"]
  restartPolicy: Always
EOF
  echo "Pod 'crashloop-pod' (keeps crashing with exit 1) in cka-q82."
}
show_q82() { cat <<'EOF'
  TASK — Fix Pod: CrashLoopBackOff
  ──────────────────────────────────────────────────────────────
  Pod 'crashloop-pod' in namespace 'cka-q82' crashes immediately.
  Investigate the logs and fix the command so it stays Running.

  Fix: Change command to ["sleep", "3600"]
  (Delete and recreate — spec is immutable)

    kubectl describe pod crashloop-pod -n cka-q82
    kubectl logs crashloop-pod -n cka-q82

  ── 한국어 ─────────────────────────────────────────────
  'cka-q82' 의 Pod 'crashloop-pod' 가 즐시 크래시됩니다.
  로그를 확인하고 커맨드를 ["sleep", "3600"] 으로 수정하세요.
  (spec 은 불변 → 삭제 후 재생성 필요)
EOF
}
validate_q82() {
  kubectl get pod crashloop-pod -n cka-q82 &>/dev/null || { echo -e "  ${RED}✗ Pod not found${NC}"; return 1; }
  local cmd; cmd=$(kubectl get pod crashloop-pod -n cka-q82 -o jsonpath='{.spec.containers[0].command}')
  [[ "$cmd" != *"sleep"* ]] && { echo -e "  ${RED}✗ command=$cmd (want sleep 3600)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Pod command fixed to sleep 3600.${NC}"
}
hint_q82() { cat <<'EOF'
  kubectl get pod crashloop-pod -n cka-q82 -o yaml > pod82.yaml
  # Edit: command from ["sh","-c","exit 1"] to ["sleep","3600"]
  kubectl delete pod crashloop-pod -n cka-q82 --force --grace-period=0
  kubectl apply -f pod82.yaml
EOF
}

# ─── Q83 ─────────────────────────────────────────────────────────────────────
setup_q83() {
  _ns cka-q83
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: apps/v1
kind: Deployment
metadata:
  name: no-endpoints-deploy
  namespace: cka-q83
spec:
  replicas: 2
  selector:
    matchLabels:
      app: backend
  template:
    metadata:
      labels:
        app: backend
    spec:
      containers:
      - name: web
        image: nginx:1.25
        ports:
        - containerPort: 80
---
apiVersion: v1
kind: Service
metadata:
  name: no-endpoints-svc
  namespace: cka-q83
spec:
  selector:
    app: wrong-backend
  ports:
  - port: 80
    targetPort: 80
EOF
  echo "Deployment (app=backend) and Service with wrong selector (app=wrong-backend) in cka-q83."
}
show_q83() { cat <<'EOF'
  TASK — Fix Service: No Endpoints
  ──────────────────────────────────────────────────────────────
  Service 'no-endpoints-svc' in namespace 'cka-q83' routes to nothing.
  Pods have label app=backend but the service selects app=wrong-backend.

  Fix the service selector.

    kubectl get pods -n cka-q83 --show-labels
    kubectl get endpoints no-endpoints-svc -n cka-q83

  ── 한국어 ─────────────────────────────────────────────
  'cka-q83' 의 Service 'no-endpoints-svc' 의 셀렉터가
  app=wrong-backend 로 잘못 설정되어 있습니다.
  파드는 app=backend 라벨을 가지므로 셀렉터를 수정하세요.
EOF
}
validate_q83() {
  local sel; sel=$(kubectl get svc no-endpoints-svc -n cka-q83 -o jsonpath='{.spec.selector.app}')
  [[ "$sel" != "backend" ]] && { echo -e "  ${RED}✗ selector.app=$sel (want backend)${NC}"; return 1; }
  sleep 3
  local ep; ep=$(kubectl get endpoints no-endpoints-svc -n cka-q83 -o jsonpath='{.subsets}')
  [[ -z "$ep" || "$ep" == "[]" ]] && { echo -e "  ${RED}✗ Still no endpoints${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Service selector fixed. Endpoints populated.${NC}"
}
hint_q83() { cat <<'EOF'
  kubectl patch svc no-endpoints-svc -n cka-q83 \
    -p '{"spec":{"selector":{"app":"backend"}}}'
EOF
}

# ─── Q84 ─────────────────────────────────────────────────────────────────────
setup_q84() {
  _ns cka-q84
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: apps/v1
kind: Deployment
metadata:
  name: probe-deploy
  namespace: cka-q84
spec:
  replicas: 2
  selector:
    matchLabels:
      app: probe-app
  template:
    metadata:
      labels:
        app: probe-app
    spec:
      containers:
      - name: web
        image: nginx:1.25
        ports:
        - containerPort: 80
        readinessProbe:
          httpGet:
            path: /healthz       # this path returns 404 on nginx
            port: 80
          initialDelaySeconds: 5
          periodSeconds: 5
EOF
  echo "Deployment 'probe-deploy' with bad readiness probe path (/healthz) in cka-q84."
}
show_q84() { cat <<'EOF'
  TASK — Fix Deployment: Failing Readiness Probe
  ──────────────────────────────────────────────────────────────
  Deployment 'probe-deploy' in namespace 'cka-q84' has pods that
  never become Ready because the readiness probe hits /healthz
  which returns 404 on nginx.

  Fix the readiness probe path to: /

    kubectl describe pod <pod-name> -n cka-q84
    # Look for: Readiness probe failed

  ── 한국어 ─────────────────────────────────────────────
  'cka-q84' 의 Deployment 'probe-deploy' 파드가 Ready 가 되지 않습니다.
  readinessProbe 경로가 /healthz 로 잘못 설정되어 nginx에서 404 응답합니다.
  readinessProbe 경로를 / 로 수정하세요.
EOF
}
validate_q84() {
  local path; path=$(kubectl get deploy probe-deploy -n cka-q84 \
    -o jsonpath='{.spec.template.spec.containers[0].readinessProbe.httpGet.path}')
  [[ "$path" != "/" ]] && { echo -e "  ${RED}✗ readinessProbe path=$path (want /)${NC}"; return 1; }
  kubectl rollout status deploy/probe-deploy -n cka-q84 --timeout=60s &>/dev/null
  echo -e "  ${GREEN}✓ Readiness probe path fixed to /.${NC}"
}
hint_q84() { cat <<'EOF'
  kubectl edit deployment probe-deploy -n cka-q84
  # Find readinessProbe.httpGet.path and change /healthz → /
  # OR patch:
  kubectl patch deployment probe-deploy -n cka-q84 --type=json \
    -p='[{"op":"replace","path":"/spec/template/spec/containers/0/readinessProbe/httpGet/path","value":"/"}]'
EOF
}

# ─── Q85 ─────────────────────────────────────────────────────────────────────
setup_q85() {
  _ns cka-q85
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: v1
kind: Pod
metadata:
  name: pending-pod
  namespace: cka-q85
spec:
  nodeSelector:
    gpu: "true"
  containers:
  - name: app
    image: nginx:1.25
EOF
  echo "Pod 'pending-pod' with nodeSelector gpu=true (no such node) in cka-q85. It's Pending."
}
show_q85() { cat <<'EOF'
  TASK — Fix Pod Stuck in Pending: Wrong NodeSelector
  ──────────────────────────────────────────────────────────────
  Pod 'pending-pod' in namespace 'cka-q85' is stuck in Pending.
  It has nodeSelector gpu=true but no node has this label.

  Fix: Remove the nodeSelector so the pod can schedule anywhere.
  (Delete and recreate — spec is immutable)

    kubectl describe pod pending-pod -n cka-q85
    # Look for: FailedScheduling

  ── 한국어 ─────────────────────────────────────────────
  'cka-q85' 의 Pod 'pending-pod' 가 Pending 상태입니다.
  nodeSelector gpu=true 로 설정되어 있으나 해당 라벨을 가진 노드가 없습니다.
  nodeSelector 를 제거하여 어느 노드에나 스케줄링 되도록 수정하세요.
EOF
}
validate_q85() {
  kubectl get pod pending-pod -n cka-q85 &>/dev/null || { echo -e "  ${RED}✗ Pod not found${NC}"; return 1; }
  local ns; ns=$(kubectl get pod pending-pod -n cka-q85 -o jsonpath='{.spec.nodeSelector}')
  if [[ "$ns" == *"gpu"* ]]; then
    echo -e "  ${RED}✗ nodeSelector still has gpu=true — pod will remain Pending${NC}"; return 1
  fi
  echo -e "  ${GREEN}✓ nodeSelector removed. Pod can now be scheduled.${NC}"
}
hint_q85() { cat <<'EOF'
  kubectl get pod pending-pod -n cka-q85 -o yaml > pod85.yaml
  # Remove the nodeSelector block entirely
  kubectl delete pod pending-pod -n cka-q85 --force --grace-period=0
  kubectl apply -f pod85.yaml
EOF
}

# ─── Q86 ─────────────────────────────────────────────────────────────────────
setup_q86() {
  _ns cka-q86
  kubectl delete cm app-settings -n cka-q86 2>/dev/null
  kubectl delete pod cm-broken-pod -n cka-q86 --force --grace-period=0 2>/dev/null
  kubectl create configmap app-settings --from-literal=timeout=30 --from-literal=retries=3 -n cka-q86 2>/dev/null
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: v1
kind: Pod
metadata:
  name: cm-broken-pod
  namespace: cka-q86
spec:
  containers:
  - name: app
    image: nginx:1.25
    envFrom:
    - configMapRef:
        name: wrong-settings    # WRONG: should be app-settings
EOF
  echo "Pod 'cm-broken-pod' referencing wrong ConfigMap 'wrong-settings' in cka-q86."
}
show_q86() { cat <<'EOF'
  TASK — Fix Pod: Wrong ConfigMap Name
  ──────────────────────────────────────────────────────────────
  Pod 'cm-broken-pod' in namespace 'cka-q86' fails to start because
  it references ConfigMap 'wrong-settings' which does NOT exist.

  The correct ConfigMap is: app-settings

  Fix the pod. (Delete and recreate — spec is immutable)

    kubectl describe pod cm-broken-pod -n cka-q86
    kubectl get configmaps -n cka-q86

  ── 한국어 ─────────────────────────────────────────────
  'cka-q86' 의 Pod 'cm-broken-pod' 이 존재하지 않는 ConfigMap
  'wrong-settings' 를 참조하여 실패합니다.
  올바른 ConfigMap 은 'app-settings' 입니다. 파드를 수정하세요.
EOF
}
validate_q86() {
  kubectl get pod cm-broken-pod -n cka-q86 &>/dev/null || { echo -e "  ${RED}✗ Pod not found${NC}"; return 1; }
  local cm; cm=$(kubectl get pod cm-broken-pod -n cka-q86 -o jsonpath='{.spec.containers[0].envFrom[0].configMapRef.name}')
  [[ "$cm" != "app-settings" ]] && { echo -e "  ${RED}✗ envFrom.configMapRef.name=$cm (want app-settings)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Pod now references correct ConfigMap 'app-settings'.${NC}"
}
hint_q86() { cat <<'EOF'
  kubectl get pod cm-broken-pod -n cka-q86 -o yaml > pod86.yaml
  # Edit: name: wrong-settings → name: app-settings
  kubectl delete pod cm-broken-pod -n cka-q86 --force --grace-period=0
  kubectl apply -f pod86.yaml
EOF
}

# ─── Q87 ─────────────────────────────────────────────────────────────────────
setup_q87() {
  _ns cka-q87
  kubectl delete pod secret-broken-pod -n cka-q87 --force --grace-period=0 2>/dev/null
  kubectl delete secret real-token -n cka-q87 2>/dev/null
  kubectl create secret generic real-token --from-literal=token=abc123xyz -n cka-q87 2>/dev/null
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: v1
kind: Pod
metadata:
  name: secret-broken-pod
  namespace: cka-q87
spec:
  containers:
  - name: app
    image: nginx:1.25
    env:
    - name: TOKEN
      valueFrom:
        secretKeyRef:
          name: real-token
          key: wrong-key       # WRONG: correct key is 'token'
EOF
  echo "Pod 'secret-broken-pod' referencing wrong Secret key 'wrong-key' in cka-q87."
}
show_q87() { cat <<'EOF'
  TASK — Fix Pod: Wrong Secret Key
  ──────────────────────────────────────────────────────────────
  Pod 'secret-broken-pod' in namespace 'cka-q87' fails because it
  references key 'wrong-key' in secret 'real-token', but the
  correct key is 'token'.

  Fix the pod. (Delete and recreate — spec is immutable)

    kubectl describe pod secret-broken-pod -n cka-q87
    kubectl get secret real-token -n cka-q87 -o yaml

  ── 한국어 ─────────────────────────────────────────────
  'cka-q87' 의 Pod 'secret-broken-pod' 이 Secret 'real-token' 에서
  존재하지 않는 키 'wrong-key' 를 참조하여 실패합니다.
  올바른 키는 'token' 입니다. 파드를 수정하세요.
EOF
}
validate_q87() {
  kubectl get pod secret-broken-pod -n cka-q87 &>/dev/null || { echo -e "  ${RED}✗ Pod not found${NC}"; return 1; }
  local key; key=$(kubectl get pod secret-broken-pod -n cka-q87 \
    -o jsonpath='{.spec.containers[0].env[0].valueFrom.secretKeyRef.key}')
  [[ "$key" != "token" ]] && { echo -e "  ${RED}✗ secretKeyRef.key=$key (want token)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Pod references correct secret key 'token'.${NC}"
}
hint_q87() { cat <<'EOF'
  kubectl get pod secret-broken-pod -n cka-q87 -o yaml > pod87.yaml
  # Edit: key: wrong-key → key: token
  kubectl delete pod secret-broken-pod -n cka-q87 --force --grace-period=0
  kubectl apply -f pod87.yaml
EOF
}

# ─── Q88 ─────────────────────────────────────────────────────────────────────
setup_q88() {
  _ns cka-q88
  kubectl delete clusterrole pods-global-reader 2>/dev/null
  kubectl delete clusterrolebinding pods-global-reader-crb 2>/dev/null
  kubectl delete sa global-sa -n cka-q88 2>/dev/null
  kubectl create sa global-sa -n cka-q88 2>/dev/null
  kubectl create clusterrole pods-global-reader \
    --verb=get,list,watch --resource=pods 2>/dev/null
  echo "ClusterRole 'pods-global-reader' created. ClusterRoleBinding is MISSING."
}
show_q88() { cat <<'EOF'
  TASK — Fix Missing RBAC: Create ClusterRoleBinding
  ──────────────────────────────────────────────────────────────
  In namespace 'cka-q88':
    - SA 'global-sa' exists
    - ClusterRole 'pods-global-reader' exists (list pods across cluster)
    - ClusterRoleBinding is MISSING

  Create ClusterRoleBinding 'pods-global-reader-crb':
    ClusterRole: pods-global-reader
    Subject: SA 'global-sa' in namespace 'cka-q88'

  Verify:
    kubectl auth can-i list pods --all-namespaces \
      --as=system:serviceaccount:cka-q88:global-sa

  ── 한국어 ─────────────────────────────────────────────
  'cka-q88' 의 SA 'global-sa' 와 ClusterRole 'pods-global-reader' 는 존재하나
  ClusterRoleBinding 이 누락되어 있습니다.
  ClusterRoleBinding 'pods-global-reader-crb' 를 생성하세요.
EOF
}
validate_q88() {
  kubectl get clusterrolebinding pods-global-reader-crb &>/dev/null || { echo -e "  ${RED}✗ ClusterRoleBinding not found${NC}"; return 1; }
  local sa; sa=$(kubectl get clusterrolebinding pods-global-reader-crb -o jsonpath='{.subjects[0].name}')
  [[ "$sa" != "global-sa" ]] && { echo -e "  ${RED}✗ subject=$sa (want global-sa)${NC}"; return 1; }
  local can; can=$(kubectl auth can-i list pods --all-namespaces \
    --as=system:serviceaccount:cka-q88:global-sa 2>/dev/null)
  echo -e "  ${GREEN}✓ ClusterRoleBinding created. can-i list pods --all-namespaces=$can${NC}"
}
hint_q88() { cat <<'EOF'
  kubectl create clusterrolebinding pods-global-reader-crb \
    --clusterrole=pods-global-reader \
    --serviceaccount=cka-q88:global-sa
EOF
}

# ─── Q89 ─────────────────────────────────────────────────────────────────────
setup_q89() {
  local w; w=$(_worker); echo "$w" > /tmp/cka-q89-node
  kubectl uncordon "$w" 2>/dev/null
  echo "Worker node '$w' is ready. Perform cordon, drain, and uncordon."
}
show_q89() {
  local w="node01"; [[ -f /tmp/cka-q89-node ]] && w=$(cat /tmp/cka-q89-node)
  cat <<EOF
  TASK — Cordon + Drain + Uncordon a Node
  ──────────────────────────────────────────────────────────────
  Worker node: $w

  Steps:
    1. Cordon '$w' (prevent new scheduling)
    2. Drain '$w' (evict all pods)
       Use: --ignore-daemonsets --delete-emptydir-data
    3. Uncordon '$w' (re-enable scheduling)

  Final state: Node '$w' must be Ready and schedulable.

    kubectl get node $w
    # STATUS should show: Ready  (NOT SchedulingDisabled)

  ── 한국어 ─────────────────────────────────────────────
  노드 '$w' 에 대해 순서대로: cordon → drain → uncordon 을 수행하세요.
  단계: --ignore-daemonsets --delete-emptydir-data 옵션 사용
  최종 상태: 노드가 Ready 이며 스케줄링 가능이어야 합니다.
EOF
}
validate_q89() {
  local w; w=$(cat /tmp/cka-q89-node 2>/dev/null || _worker)
  local sched; sched=$(kubectl get node "$w" -o jsonpath='{.spec.unschedulable}')
  if [[ "$sched" == "true" ]]; then
    echo -e "  ${RED}✗ Node '$w' is still cordoned. Uncordon it: kubectl uncordon $w${NC}"
    return 1
  fi
  local status; status=$(kubectl get node "$w" --no-headers | awk '{print $2}')
  echo -e "  ${GREEN}✓ Node '$w' is $status and schedulable (uncordoned).${NC}"
}
hint_q89() {
  local w; w=$(cat /tmp/cka-q89-node 2>/dev/null || echo "node01")
  cat <<EOF
  kubectl cordon $w
  kubectl drain $w --ignore-daemonsets --delete-emptydir-data
  kubectl uncordon $w
  kubectl get node $w
EOF
}

# ─── Q90 ─────────────────────────────────────────────────────────────────────
setup_q90() {
  _ns cka-q90
  kubectl delete deploy wrong-port-deploy -n cka-q90 2>/dev/null
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: apps/v1
kind: Deployment
metadata:
  name: wrong-port-deploy
  namespace: cka-q90
spec:
  replicas: 2
  selector:
    matchLabels:
      app: wrongport
  template:
    metadata:
      labels:
        app: wrongport
    spec:
      containers:
      - name: web
        image: nginx:1.25
        ports:
        - containerPort: 9090   # WRONG: nginx serves on 80
EOF
  echo "Deployment with wrong containerPort (9090 instead of 80) in cka-q90."
}
show_q90() { cat <<'EOF'
  TASK — Fix Deployment: Wrong Container Port
  ──────────────────────────────────────────────────────────────
  Deployment 'wrong-port-deploy' in namespace 'cka-q90' declares
  containerPort: 9090, but nginx actually listens on port 80.

  Fix the containerPort to 80.

  (Note: containerPort is documentation only, but is used by
   services/probes to know what port to target.)

  ── 한국어 ─────────────────────────────────────────────
  'cka-q90' 의 Deployment 'wrong-port-deploy' 가 containerPort: 9090 으로
  잘못 선언되어 있습니다. nginx 는 80 포트를 사용합니다.
  containerPort 를 80 으로 수정하세요.
EOF
}
validate_q90() {
  local port; port=$(kubectl get deploy wrong-port-deploy -n cka-q90 \
    -o jsonpath='{.spec.template.spec.containers[0].ports[0].containerPort}')
  [[ "$port" != "80" ]] && { echo -e "  ${RED}✗ containerPort=$port (want 80)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ containerPort fixed to 80.${NC}"
}
hint_q90() { cat <<'EOF'
  kubectl edit deployment wrong-port-deploy -n cka-q90
  # Change containerPort: 9090 → containerPort: 80
  # OR patch:
  kubectl patch deployment wrong-port-deploy -n cka-q90 --type=json \
    -p='[{"op":"replace","path":"/spec/template/spec/containers/0/ports/0/containerPort","value":80}]'
EOF
}

# ─── Q91 ─────────────────────────────────────────────────────────────────────
setup_q91() {
  _ns cka-q91
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: v1
kind: Pod
metadata:
  name: running-pod
  namespace: cka-q91
  labels:
    status: ok
spec:
  containers:
  - name: web
    image: nginx:1.25
---
apiVersion: v1
kind: Pod
metadata:
  name: failing-pod1
  namespace: cka-q91
  labels:
    status: fail
spec:
  containers:
  - name: app
    image: nginx:1.25
    command: ["sh","-c","exit 1"]
  restartPolicy: Never
---
apiVersion: v1
kind: Pod
metadata:
  name: failing-pod2
  namespace: cka-q91
  labels:
    status: fail
spec:
  containers:
  - name: app
    image: nginx:BROKEN
  restartPolicy: Never
EOF
  echo "3 pods created in cka-q91: 1 Running, 2 failing."
}
show_q91() { cat <<'EOF'
  TASK — Find All Not-Running Pods in a Namespace
  ──────────────────────────────────────────────────────────────
  Namespace 'cka-q91' has 3 pods, but not all are Running.

  Find all pods NOT in Running state and save their names to:
    /tmp/not-running-pods.txt

  Format (one pod name per line):
    failing-pod1
    failing-pod2

    kubectl get pods -n cka-q91

  ── 한국어 ─────────────────────────────────────────────
  'cka-q91' 네임스페이스에서 Running 상태가 아닌 모든 파드 이름을
  /tmp/not-running-pods.txt 파일에 한 줄씩 저장하세요.
EOF
}
validate_q91() {
  [[ -f /tmp/not-running-pods.txt ]] || { echo -e "  ${RED}✗ File /tmp/not-running-pods.txt not found${NC}"; return 1; }
  local content; content=$(cat /tmp/not-running-pods.txt)
  [[ "$content" != *"failing-pod1"* ]] && { echo -e "  ${RED}✗ failing-pod1 missing from file${NC}"; return 1; }
  [[ "$content" != *"failing-pod2"* ]] && { echo -e "  ${RED}✗ failing-pod2 missing from file${NC}"; return 1; }
  [[ "$content" == *"running-pod"*  ]] && { echo -e "  ${RED}✗ running-pod should NOT be in file${NC}"; return 1; }
  echo -e "  ${GREEN}✓ /tmp/not-running-pods.txt contains both failing pod names.${NC}"
}
hint_q91() { cat <<'EOF'
  kubectl get pods -n cka-q91 --field-selector=status.phase!=Running \
    -o custom-columns='NAME:.metadata.name' --no-headers \
    > /tmp/not-running-pods.txt

  cat /tmp/not-running-pods.txt
EOF
}

# ─── Q92 ─────────────────────────────────────────────────────────────────────
setup_q92() {
  _ns cka-q92
  kubectl delete pvc old-claim -n cka-q92 2>/dev/null
  kubectl delete pod pvc-broken-pod -n cka-q92 --force --grace-period=0 2>/dev/null
  kubectl delete pv pv-for-q92 2>/dev/null; sleep 2
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: v1
kind: PersistentVolume
metadata:
  name: pv-for-q92
spec:
  capacity:
    storage: 500Mi
  accessModes:
  - ReadWriteOnce
  storageClassName: manual
  hostPath:
    path: /tmp/pv-q92
---
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: old-claim
  namespace: cka-q92
spec:
  accessModes:
  - ReadWriteOnce
  storageClassName: manual
  resources:
    requests:
      storage: 100Mi
---
apiVersion: v1
kind: Pod
metadata:
  name: pvc-broken-pod
  namespace: cka-q92
spec:
  containers:
  - name: app
    image: nginx:1.25
    volumeMounts:
    - name: data
      mountPath: /data
  volumes:
  - name: data
    persistentVolumeClaim:
      claimName: wrong-claim    # WRONG: correct claim is 'old-claim'
EOF
  echo "PVC 'old-claim' exists. Pod 'pvc-broken-pod' references wrong PVC 'wrong-claim'."
}
show_q92() { cat <<'EOF'
  TASK — Fix Pod: Wrong PVC Claim Name
  ──────────────────────────────────────────────────────────────
  Pod 'pvc-broken-pod' in namespace 'cka-q92' fails because it
  references PVC 'wrong-claim' which does NOT exist.

  The correct PVC is: old-claim

  Fix the pod. (Delete and recreate)

    kubectl describe pod pvc-broken-pod -n cka-q92
    kubectl get pvc -n cka-q92

  ── 한국어 ─────────────────────────────────────────────
  'cka-q92' 의 Pod 'pvc-broken-pod' 이 존재하지 않는 PVC 'wrong-claim' 을
  참조하여 실패합니다. 올바른 PVC 는 'old-claim' 입니다. 파드를 수정하세요.
EOF
}
validate_q92() {
  kubectl get pod pvc-broken-pod -n cka-q92 &>/dev/null || { echo -e "  ${RED}✗ Pod not found${NC}"; return 1; }
  local claim; claim=$(kubectl get pod pvc-broken-pod -n cka-q92 \
    -o jsonpath='{.spec.volumes[0].persistentVolumeClaim.claimName}')
  [[ "$claim" != "old-claim" ]] && { echo -e "  ${RED}✗ claimName=$claim (want old-claim)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Pod references correct PVC 'old-claim'.${NC}"
}
hint_q92() { cat <<'EOF'
  kubectl get pod pvc-broken-pod -n cka-q92 -o yaml > pod92.yaml
  # Edit: claimName: wrong-claim → claimName: old-claim
  kubectl delete pod pvc-broken-pod -n cka-q92 --force --grace-period=0
  kubectl apply -f pod92.yaml
EOF
}

# ─── Q93 ─────────────────────────────────────────────────────────────────────
setup_q93() {
  _ns cka-q93
  kubectl delete deploy old-image-deploy -n cka-q93 2>/dev/null
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: apps/v1
kind: Deployment
metadata:
  name: old-image-deploy
  namespace: cka-q93
spec:
  replicas: 2
  selector:
    matchLabels:
      app: old
  template:
    metadata:
      labels:
        app: old
    spec:
      containers:
      - name: web
        image: nginx:1.20    # old tag
EOF
  echo "Deployment 'old-image-deploy' with old image nginx:1.20 in cka-q93."
}
show_q93() { cat <<'EOF'
  TASK — Fix Deployment: Update Old Image Tag
  ──────────────────────────────────────────────────────────────
  Deployment 'old-image-deploy' in namespace 'cka-q93' uses an
  outdated image: nginx:1.20

  Update it to: nginx:1.25
  Verify the rollout completes successfully.

    kubectl rollout status deployment/old-image-deploy -n cka-q93

  ── 한국어 ─────────────────────────────────────────────
  'cka-q93' 의 Deployment 'old-image-deploy' 가 오래된 이미지 nginx:1.20 을
  사용하고 있습니다. nginx:1.25 로 업데이트하고 롤아웃 완료를 확인하세요.
EOF
}
validate_q93() {
  local img; img=$(kubectl get deploy old-image-deploy -n cka-q93 \
    -o jsonpath='{.spec.template.spec.containers[0].image}')
  [[ "$img" != "nginx:1.25" ]] && { echo -e "  ${RED}✗ image=$img (want nginx:1.25)${NC}"; return 1; }
  kubectl rollout status deploy/old-image-deploy -n cka-q93 --timeout=60s &>/dev/null
  echo -e "  ${GREEN}✓ Image updated to nginx:1.25. Rollout complete.${NC}"
}
hint_q93() { cat <<'EOF'
  kubectl set image deployment/old-image-deploy web=nginx:1.25 -n cka-q93
  kubectl rollout status deployment/old-image-deploy -n cka-q93
EOF
}

# ─── Q94 ─────────────────────────────────────────────────────────────────────
setup_q94() {
  local w; w=$(_worker); echo "$w" > /tmp/cka-q94-node
  kubectl label node "$w" env=prod --overwrite 2>/dev/null
  _ns cka-q94
  kubectl delete pod env-selector-pod -n cka-q94 --force --grace-period=0 2>/dev/null
  echo "Node '$w' labeled env=prod."
}
show_q94() {
  local w="node01"; [[ -f /tmp/cka-q94-node ]] && w=$(cat /tmp/cka-q94-node)
  cat <<EOF
  TASK — Label a Node + Verify Pod Scheduling
  ──────────────────────────────────────────────────────────────
  Node '$w' has label: env=prod

  Create Pod 'env-selector-pod' in namespace 'cka-q94':
    Image:        nginx:1.25
    nodeSelector: env=prod

  Verify: pod is Running on node '$w'

    kubectl get pod env-selector-pod -n cka-q94 -o wide

  ── 한국어 ─────────────────────────────────────────────
  노드 '$w' 에 env=prod 라벨이 있습니다.
  'cka-q94' 에 Pod 'env-selector-pod' 를 생성하세요:
    image: nginx:1.25 / nodeSelector: env=prod
  파드가 '$w' 노드에 스케줄링되는지 확인하세요.
EOF
}
validate_q94() {
  kubectl get pod env-selector-pod -n cka-q94 &>/dev/null || { echo -e "  ${RED}✗ Pod not found${NC}"; return 1; }
  local ns; ns=$(kubectl get pod env-selector-pod -n cka-q94 -o jsonpath='{.spec.nodeSelector.env}')
  [[ "$ns" != "prod" ]] && { echo -e "  ${RED}✗ nodeSelector.env=$ns (want prod)${NC}"; return 1; }
  local node; node=$(kubectl get pod env-selector-pod -n cka-q94 -o jsonpath='{.spec.nodeName}')
  local expected; expected=$(cat /tmp/cka-q94-node 2>/dev/null)
  [[ -n "$expected" && "$node" != "$expected" ]] && { echo -e "  ${RED}✗ Pod on $node (want $expected)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Pod scheduled on $node using nodeSelector env=prod.${NC}"
}
hint_q94() { cat <<'EOF'
  # Check node labels:
  kubectl get nodes --show-labels | grep env=prod

  # Pod with nodeSelector:
  spec:
    nodeSelector:
      env: prod
    containers:
    - name: nginx
      image: nginx:1.25
EOF
}

# ─── Q95 ─────────────────────────────────────────────────────────────────────
setup_q95() {
  _ns cka-q95
  kubectl delete deploy scale-deploy -n cka-q95 2>/dev/null
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: apps/v1
kind: Deployment
metadata:
  name: scale-deploy
  namespace: cka-q95
spec:
  replicas: 6
  selector:
    matchLabels:
      app: scale
  template:
    metadata:
      labels:
        app: scale
    spec:
      containers:
      - name: web
        image: nginx:1.25
EOF
  echo "Deployment 'scale-deploy' with 6 replicas in cka-q95."
}
show_q95() { cat <<'EOF'
  TASK — Scale Down Deployment + Verify
  ──────────────────────────────────────────────────────────────
  Deployment 'scale-deploy' in namespace 'cka-q95' has 6 replicas.
  Scale it DOWN to 2 replicas.
  Verify old pods terminate and only 2 remain Running.

    kubectl get deployment scale-deploy -n cka-q95
    kubectl get pods -n cka-q95

  ── 한국어 ─────────────────────────────────────────────
  'cka-q95' 의 Deployment 'scale-deploy' 가 6개의 레플리카를 가지고 있습니다.
  2개로 스케일 다운하고 이전 파드가 종료되어 2개만 남는지 확인하세요.
EOF
}
validate_q95() {
  local rep; rep=$(kubectl get deploy scale-deploy -n cka-q95 -o jsonpath='{.spec.replicas}')
  [[ "$rep" != "2" ]] && { echo -e "  ${RED}✗ replicas=$rep (want 2)${NC}"; return 1; }
  kubectl rollout status deploy/scale-deploy -n cka-q95 --timeout=30s &>/dev/null
  local ready; ready=$(kubectl get deploy scale-deploy -n cka-q95 -o jsonpath='{.status.readyReplicas}')
  [[ "$ready" != "2" ]] && { echo -e "  ${RED}✗ only $ready/2 ready${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Deployment scaled to 2 replicas.${NC}"
}
hint_q95() { cat <<'EOF'
  kubectl scale deployment scale-deploy --replicas=2 -n cka-q95
  kubectl get pods -n cka-q95
EOF
}

# ─── Q96 ─────────────────────────────────────────────────────────────────────
setup_q96() {
  _ns cka-q96
  kubectl delete svc udp-broken-svc -n cka-q96 2>/dev/null
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: apps/v1
kind: Deployment
metadata:
  name: tcp-app
  namespace: cka-q96
spec:
  replicas: 1
  selector:
    matchLabels:
      app: tcp-app
  template:
    metadata:
      labels:
        app: tcp-app
    spec:
      containers:
      - name: web
        image: nginx:1.25
        ports:
        - containerPort: 80
---
apiVersion: v1
kind: Service
metadata:
  name: udp-broken-svc
  namespace: cka-q96
spec:
  selector:
    app: tcp-app
  ports:
  - port: 80
    targetPort: 80
    protocol: UDP    # WRONG: nginx uses TCP
EOF
  echo "Service 'udp-broken-svc' with protocol UDP (should be TCP) in cka-q96."
}
show_q96() { cat <<'EOF'
  TASK — Fix Service: Wrong Protocol (UDP→TCP)
  ──────────────────────────────────────────────────────────────
  Service 'udp-broken-svc' in namespace 'cka-q96' has protocol: UDP
  but nginx uses TCP. This prevents TCP connections.

  Fix the service protocol to TCP.

    kubectl describe svc udp-broken-svc -n cka-q96

  ── 한국어 ─────────────────────────────────────────────
  'cka-q96' 의 Service 'udp-broken-svc' 가 protocol: UDP 로 잘못 설정되어 있습니다.
  nginx 는 TCP 를 사용하므로 프로토콜을 TCP 로 수정하세요.
EOF
}
validate_q96() {
  local proto; proto=$(kubectl get svc udp-broken-svc -n cka-q96 \
    -o jsonpath='{.spec.ports[0].protocol}')
  [[ "$proto" != "TCP" ]] && { echo -e "  ${RED}✗ protocol=$proto (want TCP)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Service protocol fixed to TCP.${NC}"
}
hint_q96() { cat <<'EOF'
  kubectl patch svc udp-broken-svc -n cka-q96 \
    -p '{"spec":{"ports":[{"port":80,"targetPort":80,"protocol":"TCP"}]}}'
EOF
}

# ─── Q97 ─────────────────────────────────────────────────────────────────────
setup_q97() {
  kubectl delete namespace limitrange-test 2>/dev/null; sleep 2
  echo "Namespace 'limitrange-test' removed."
}
show_q97() { cat <<'EOF'
  TASK — Create Namespace + LimitRange + Verify
  ──────────────────────────────────────────────────────────────
  Step 1: Create namespace 'limitrange-test'

  Step 2: Create LimitRange 'default-limits' in 'limitrange-test':
    type: Container
    default:      { cpu: 200m, memory: 128Mi }
    defaultRequest: { cpu: 50m,  memory: 32Mi }

  Step 3: Create Pod 'test-pod' in 'limitrange-test':
    image: nginx:1.25
    (NO resource fields — limits should be auto-applied by LimitRange)

  Verify: kubectl describe pod test-pod -n limitrange-test
          # Should show auto-applied limits: 200m / 128Mi

  ── 한국어 ─────────────────────────────────────────────
  1단계: 네임스페이스 'limitrange-test' 생성
  2단계: LimitRange 'default-limits' 생성:
    type: Container / default: cpu=200m, memory=128Mi / defaultRequest: cpu=50m, memory=32Mi
  3단계: 리소스 필드 없이 Pod 'test-pod' 생성 → LimitRange가 자동 적용되는지 확인
EOF
}
validate_q97() {
  kubectl get namespace limitrange-test &>/dev/null || { echo -e "  ${RED}✗ Namespace not found${NC}"; return 1; }
  kubectl get limitrange default-limits -n limitrange-test &>/dev/null || { echo -e "  ${RED}✗ LimitRange not found${NC}"; return 1; }
  kubectl get pod test-pod -n limitrange-test &>/dev/null || { echo -e "  ${RED}✗ Pod 'test-pod' not found${NC}"; return 1; }
  local cpu; cpu=$(kubectl get limitrange default-limits -n limitrange-test \
    -o jsonpath='{.spec.limits[0].default.cpu}')
  [[ "$cpu" != "200m" ]] && { echo -e "  ${RED}✗ LimitRange default.cpu=$cpu (want 200m)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Namespace + LimitRange + Pod all configured.${NC}"
}
hint_q97() { cat <<'EOF'
  kubectl create namespace limitrange-test
  kubectl apply -n limitrange-test -f - <<YAML
  apiVersion: v1
  kind: LimitRange
  metadata:
    name: default-limits
  spec:
    limits:
    - type: Container
      default:
        cpu: 200m
        memory: 128Mi
      defaultRequest:
        cpu: 50m
        memory: 32Mi
  YAML
  kubectl run test-pod --image=nginx:1.25 -n limitrange-test
EOF
}

# ─── Q98 ─────────────────────────────────────────────────────────────────────
setup_q98() {
  _ns cka-q98
  kubectl delete deploy bad-cmd-deploy -n cka-q98 2>/dev/null
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: apps/v1
kind: Deployment
metadata:
  name: bad-cmd-deploy
  namespace: cka-q98
spec:
  replicas: 2
  selector:
    matchLabels:
      app: bad-cmd
  template:
    metadata:
      labels:
        app: bad-cmd
    spec:
      containers:
      - name: web
        image: nginx:1.25
        command: ["nginx", "-g", "daemon off;", "--wrong-flag"]   # WRONG flag
EOF
  echo "Deployment 'bad-cmd-deploy' with wrong nginx flag in cka-q98."
}
show_q98() { cat <<'EOF'
  TASK — Fix Deployment: Wrong Command Flag
  ──────────────────────────────────────────────────────────────
  Deployment 'bad-cmd-deploy' in namespace 'cka-q98' has pods in
  CrashLoopBackOff. The command has an invalid flag: --wrong-flag

  Fix: Remove the bad flag. Correct command:
    ["nginx", "-g", "daemon off;"]

    kubectl describe pod <pod-name> -n cka-q98
    kubectl logs <pod-name> -n cka-q98

  ── 한국어 ─────────────────────────────────────────────
  'cka-q98' 의 Deployment 'bad-cmd-deploy' 파드가 CrashLoopBackOff 상태입니다.
  커맨드에 잘못된 플래그 --wrong-flag 가 포함되어 있습니다.
  해당 플래그를 제거하여 ["nginx", "-g", "daemon off;"] 로 수정하세요.
EOF
}
validate_q98() {
  local cmd; cmd=$(kubectl get deploy bad-cmd-deploy -n cka-q98 \
    -o jsonpath='{.spec.template.spec.containers[0].command}')
  [[ "$cmd" == *"wrong-flag"* ]] && { echo -e "  ${RED}✗ command still contains --wrong-flag: $cmd${NC}"; return 1; }
  kubectl rollout status deploy/bad-cmd-deploy -n cka-q98 --timeout=60s &>/dev/null
  local ready; ready=$(kubectl get deploy bad-cmd-deploy -n cka-q98 -o jsonpath='{.status.readyReplicas}')
  [[ "$ready" != "2" ]] && { echo -e "  ${RED}✗ only $ready/2 ready${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Bad command flag removed. 2/2 replicas running.${NC}"
}
hint_q98() { cat <<'EOF'
  kubectl edit deployment bad-cmd-deploy -n cka-q98
  # Remove "--wrong-flag" from the command array
  # Final command: ["nginx", "-g", "daemon off;"]
EOF
}

# ─── Q99 ─────────────────────────────────────────────────────────────────────
setup_q99() {
  _ns cka-q99
  kubectl delete pod multi-log-pod -n cka-q99 --force --grace-period=0 2>/dev/null
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: v1
kind: Pod
metadata:
  name: multi-log-pod
  namespace: cka-q99
spec:
  containers:
  - name: app
    image: nginx:1.25
  - name: logger
    image: busybox:1.36
    command: ["sh","-c","while true; do echo 'log entry' $(date); sleep 3; done"]
EOF
  echo "Pod 'multi-log-pod' with 2 containers in cka-q99."
}
show_q99() { cat <<'EOF'
  TASK — Multi-Container Pod: View Logs by Container Name
  ──────────────────────────────────────────────────────────────
  Pod 'multi-log-pod' in namespace 'cka-q99' has 2 containers:
    - app    (nginx)
    - logger (busybox, writing logs)

  Task: Save the last 5 lines of logs from the 'logger' container to:
    /tmp/logger-logs.txt

  Verify:
    cat /tmp/logger-logs.txt
    # Should show lines with 'log entry'

  ── 한국어 ─────────────────────────────────────────────
  'cka-q99' 의 Pod 'multi-log-pod' 에는 app, logger 2개 컨테이너가 있습니다.
  'logger' 컨테이너의 마지막 5줄 로그를 /tmp/logger-logs.txt 에 저장하세요.
EOF
}
validate_q99() {
  [[ -f /tmp/logger-logs.txt ]] || { echo -e "  ${RED}✗ File /tmp/logger-logs.txt not found${NC}"; return 1; }
  local lines; lines=$(wc -l < /tmp/logger-logs.txt)
  [[ "$lines" -lt 1 ]] && { echo -e "  ${RED}✗ File is empty${NC}"; return 1; }
  local content; content=$(cat /tmp/logger-logs.txt)
  [[ "$content" != *"log entry"* ]] && { echo -e "  ${RED}✗ File doesn't contain 'log entry'${NC}"; return 1; }
  echo -e "  ${GREEN}✓ /tmp/logger-logs.txt has $lines lines from 'logger' container.${NC}"
}
hint_q99() { cat <<'EOF'
  kubectl logs multi-log-pod -c logger -n cka-q99 --tail=5 \
    > /tmp/logger-logs.txt

  cat /tmp/logger-logs.txt
EOF
}

# ─── Q100 ────────────────────────────────────────────────────────────────────
setup_q100() {
  echo "No environment changes needed for Q100."
  echo "This question checks the health of your existing cluster."
}
show_q100() { cat <<'EOF'
  TASK — Cluster Health Check
  ──────────────────────────────────────────────────────────────
  Perform a full cluster health check and save report to:
    /tmp/cluster-health.txt

  The report must contain ALL of the following:
    1. Output of:  kubectl get nodes
    2. Output of:  kubectl get pods -n kube-system
    3. Output of:  kubectl cluster-info

  Combine them into one file (use >> to append).

  Verify: cat /tmp/cluster-health.txt

  ── 한국어 ─────────────────────────────────────────────
  클러스터 헬스 체크 보고서를 /tmp/cluster-health.txt 에 저장하세요.
  다음 3가지를 모두 포함해야 합니다:
    1. kubectl get nodes
    2. kubectl get pods -n kube-system
    3. kubectl cluster-info
EOF
}
validate_q100() {
  [[ -f /tmp/cluster-health.txt ]] || { echo -e "  ${RED}✗ File /tmp/cluster-health.txt not found${NC}"; return 1; }
  local content; content=$(cat /tmp/cluster-health.txt)
  local ok=true
  [[ "$content" != *"Ready"*        ]] && { echo -e "  ${RED}✗ Missing 'kubectl get nodes' output (no 'Ready')${NC}"; ok=false; }
  [[ "$content" != *"kube-system"* && "$content" != *"coredns"* ]] \
    && { echo -e "  ${RED}✗ Missing kube-system pods output${NC}"; ok=false; }
  [[ "$content" != *"cluster-info"* && "$content" != *"https://"* ]] \
    && { echo -e "  ${RED}✗ Missing cluster-info output${NC}"; ok=false; }
  [[ "$ok" == "true" ]] && echo -e "  ${GREEN}✓ Cluster health report saved to /tmp/cluster-health.txt.${NC}"
  [[ "$ok" == "true" ]]
}
hint_q100() { cat <<'EOF'
  echo "=== NODES ===" > /tmp/cluster-health.txt
  kubectl get nodes >> /tmp/cluster-health.txt

  echo "=== KUBE-SYSTEM PODS ===" >> /tmp/cluster-health.txt
  kubectl get pods -n kube-system >> /tmp/cluster-health.txt

  echo "=== CLUSTER INFO ===" >> /tmp/cluster-health.txt
  kubectl cluster-info >> /tmp/cluster-health.txt

  cat /tmp/cluster-health.txt
EOF
}
