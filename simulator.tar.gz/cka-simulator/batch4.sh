#!/usr/bin/env bash
# Batch 4: RBAC, Security & Scheduling (Q61–Q80) — sourced by run.sh

BATCH_TITLE="Batch 4 — RBAC, Security & Scheduling (Q61–Q80)"
Q_TITLES=(""
  "Create a ServiceAccount"
  "Create Role + RoleBinding"
  "Create ClusterRole + ClusterRoleBinding"
  "Fix RBAC: Missing RoleBinding"
  "Pod with runAsUser securityContext"
  "Pod with Read-Only Root Filesystem"
  "Pod with Added Capability (NET_ADMIN)"
  "Create ResourceQuota for Namespace"
  "Create LimitRange for Namespace"
  "Taint Node + Pod with Toleration"
  "NodeAffinity: Required (label node first)"
  "NodeAffinity: Preferred"
  "Pod Anti-Affinity"
  "Schedule Pod on Specific Node (nodeName)"
  "Cordon a Node + Label It"
  "Create a PodDisruptionBudget"
  "RBAC for Deployment Management"
  "Pod with runAsGroup + fsGroup"
  "Create Namespace + ResourceQuota"
  "ClusterRole for Non-Resource URL"
)

_ns() { kubectl create namespace "$1" --dry-run=client -o yaml | kubectl apply -f - 2>/dev/null; }
_worker() {
  local w; w=$(kubectl get nodes --no-headers | grep -v 'control-plane\|master' | awk 'NR==1{print $1}')
  [[ -z "$w" ]] && w=$(kubectl get nodes --no-headers | awk 'NR==1{print $1}')
  echo "$w"
}
_cp() {
  local c; c=$(kubectl get nodes --no-headers | grep -i 'control-plane\|master' | awk 'NR==1{print $1}')
  [[ -z "$c" ]] && c=$(kubectl get nodes --no-headers | awk 'NR==1{print $1}')
  echo "$c"
}

# ─── Q61 ─────────────────────────────────────────────────────────────────────
setup_q61() { _ns cka-q61; kubectl delete sa app-sa -n cka-q61 2>/dev/null; echo "Namespace cka-q61 ready."; }
show_q61() { cat <<'EOF'
  TASK — Create a ServiceAccount
  ──────────────────────────────────────────────────────────────
  Create a ServiceAccount:
    Name:      app-sa
    Namespace: cka-q61

  Verify:
    kubectl get serviceaccount app-sa -n cka-q61
    kubectl describe sa app-sa -n cka-q61

  ── 한국어 ─────────────────────────────────────────────
  cka-q61 에 ServiceAccount 'app-sa' 를 생성하세요.
EOF
}
validate_q61() {
  kubectl get sa app-sa -n cka-q61 &>/dev/null || { echo -e "  ${RED}✗ SA 'app-sa' not found in cka-q61${NC}"; return 1; }
  echo -e "  ${GREEN}✓ ServiceAccount 'app-sa' created in cka-q61.${NC}"
}
hint_q61() { cat <<'EOF'
  kubectl create serviceaccount app-sa -n cka-q61
EOF
}

# ─── Q62 ─────────────────────────────────────────────────────────────────────
setup_q62() {
  _ns cka-q62
  kubectl delete role pod-reader -n cka-q62 2>/dev/null
  kubectl delete rolebinding pod-reader-binding -n cka-q62 2>/dev/null
  kubectl delete sa cka-sa -n cka-q62 2>/dev/null
  kubectl create sa cka-sa -n cka-q62 2>/dev/null
  echo "SA 'cka-sa' created. Create Role and RoleBinding."
}
show_q62() { cat <<'EOF'
  TASK — Create Role + RoleBinding
  ──────────────────────────────────────────────────────────────
  ServiceAccount 'cka-sa' exists in namespace 'cka-q62'.

  Step 1: Create Role 'pod-reader' in 'cka-q62':
    apiGroups: [""]
    resources: ["pods", "pods/log"]
    verbs:     ["get", "list", "watch"]

  Step 2: Create RoleBinding 'pod-reader-binding':
    Binds Role 'pod-reader' to ServiceAccount 'cka-sa'

  Verify:
    kubectl auth can-i list pods \
      --as=system:serviceaccount:cka-q62:cka-sa -n cka-q62

  ── 한국어 ─────────────────────────────────────────────
  cka-q62 에서 RBAC 을 구성하세요:
    1. Role 'pod-reader': pods/pods.log 에 get,list,watch 권한
    2. RoleBinding 'pod-reader-binding': SA 'cka-sa' 에 해당 Role 바인딩
EOF
}
validate_q62() {
  kubectl get role pod-reader -n cka-q62 &>/dev/null || { echo -e "  ${RED}✗ Role 'pod-reader' not found${NC}"; return 1; }
  kubectl get rolebinding pod-reader-binding -n cka-q62 &>/dev/null || { echo -e "  ${RED}✗ RoleBinding not found${NC}"; return 1; }
  local rb_role; rb_role=$(kubectl get rolebinding pod-reader-binding -n cka-q62 -o jsonpath='{.roleRef.name}')
  local rb_sa;   rb_sa=$(kubectl get rolebinding pod-reader-binding -n cka-q62 -o jsonpath='{.subjects[0].name}')
  local ok=true
  [[ "$rb_role" != "pod-reader" ]] && { echo -e "  ${RED}✗ RoleBinding roleRef=$rb_role (want pod-reader)${NC}"; ok=false; }
  [[ "$rb_sa" != "cka-sa"       ]] && { echo -e "  ${RED}✗ RoleBinding subject=$rb_sa (want cka-sa)${NC}"; ok=false; }
  if [[ "$ok" == "true" ]]; then
    local can; can=$(kubectl auth can-i list pods --as=system:serviceaccount:cka-q62:cka-sa -n cka-q62 2>/dev/null)
    echo -e "  ${GREEN}✓ RBAC correct. can-i list pods=$can${NC}"
  fi
  [[ "$ok" == "true" ]]
}
hint_q62() { cat <<'EOF'
  kubectl create role pod-reader \
    --verb=get,list,watch \
    --resource=pods,pods/log \
    -n cka-q62

  kubectl create rolebinding pod-reader-binding \
    --role=pod-reader \
    --serviceaccount=cka-q62:cka-sa \
    -n cka-q62
EOF
}

# ─── Q63 ─────────────────────────────────────────────────────────────────────
setup_q63() {
  _ns cka-q63
  kubectl delete clusterrole node-reader 2>/dev/null
  kubectl delete clusterrolebinding node-reader-crb 2>/dev/null
  echo "Namespace cka-q63 ready."
}
show_q63() { cat <<'EOF'
  TASK — Create ClusterRole + ClusterRoleBinding
  ──────────────────────────────────────────────────────────────
  Step 1: Create ClusterRole 'node-reader':
    apiGroups: [""]
    resources: ["nodes"]
    verbs:     ["get", "list", "watch"]

  Step 2: Create ClusterRoleBinding 'node-reader-crb':
    Binds ClusterRole 'node-reader' to SA 'default' in ns 'cka-q63'

  Verify:
    kubectl auth can-i list nodes \
      --as=system:serviceaccount:cka-q63:default

  ── 한국어 ─────────────────────────────────────────────
  ClusterRole + ClusterRoleBinding 을 생성하세요:
    1. ClusterRole 'node-reader': nodes 리소스에 get,list,watch 권한
    2. ClusterRoleBinding 'node-reader-crb': cka-q63 의 SA 'default' 에 바인딩
EOF
}
validate_q63() {
  kubectl get clusterrole node-reader &>/dev/null || { echo -e "  ${RED}✗ ClusterRole 'node-reader' not found${NC}"; return 1; }
  kubectl get clusterrolebinding node-reader-crb &>/dev/null || { echo -e "  ${RED}✗ ClusterRoleBinding not found${NC}"; return 1; }
  local res; res=$(kubectl get clusterrole node-reader -o jsonpath='{.rules[0].resources[0]}')
  [[ "$res" != "nodes" ]] && { echo -e "  ${RED}✗ resource=$res (want nodes)${NC}"; return 1; }
  local ns; ns=$(kubectl get clusterrolebinding node-reader-crb -o jsonpath='{.subjects[0].namespace}')
  [[ "$ns" != "cka-q63" ]] && { echo -e "  ${RED}✗ subject.namespace=$ns (want cka-q63)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ ClusterRole + ClusterRoleBinding created correctly.${NC}"
}
hint_q63() { cat <<'EOF'
  kubectl create clusterrole node-reader \
    --verb=get,list,watch --resource=nodes

  kubectl create clusterrolebinding node-reader-crb \
    --clusterrole=node-reader \
    --serviceaccount=cka-q63:default
EOF
}

# ─── Q64 ─────────────────────────────────────────────────────────────────────
setup_q64() {
  _ns cka-q64
  kubectl delete role secret-reader -n cka-q64 2>/dev/null
  kubectl delete rolebinding secret-reader-binding -n cka-q64 2>/dev/null
  kubectl delete sa reader-sa -n cka-q64 2>/dev/null
  kubectl create sa reader-sa -n cka-q64 2>/dev/null
  kubectl create role secret-reader --verb=get,list --resource=secrets -n cka-q64 2>/dev/null
  echo "SA 'reader-sa' and Role 'secret-reader' created. RoleBinding is MISSING — fix this."
}
show_q64() { cat <<'EOF'
  TASK — Fix RBAC: Create Missing RoleBinding
  ──────────────────────────────────────────────────────────────
  In namespace 'cka-q64':
    - Role 'secret-reader' exists (can get/list secrets)
    - SA 'reader-sa' exists
    - BUT there is NO RoleBinding connecting them

  Create RoleBinding 'secret-reader-binding':
    Binds Role 'secret-reader' to SA 'reader-sa'

  Verify:
    kubectl auth can-i list secrets \
      --as=system:serviceaccount:cka-q64:reader-sa -n cka-q64

  ── 한국어 ─────────────────────────────────────────────
  cka-q64 에 Role 'secret-reader' 와 SA 'reader-sa' 는 이미 있으나
  RoleBinding 이 없습니다. RoleBinding 'secret-reader-binding' 을 생성해 연결하세요.
EOF
}
validate_q64() {
  kubectl get rolebinding secret-reader-binding -n cka-q64 &>/dev/null || { echo -e "  ${RED}✗ RoleBinding 'secret-reader-binding' not found${NC}"; return 1; }
  local sa; sa=$(kubectl get rolebinding secret-reader-binding -n cka-q64 -o jsonpath='{.subjects[0].name}')
  [[ "$sa" != "reader-sa" ]] && { echo -e "  ${RED}✗ subject=$sa (want reader-sa)${NC}"; return 1; }
  local can; can=$(kubectl auth can-i list secrets --as=system:serviceaccount:cka-q64:reader-sa -n cka-q64 2>/dev/null)
  echo -e "  ${GREEN}✓ RoleBinding created. can-i list secrets=$can${NC}"
}
hint_q64() { cat <<'EOF'
  kubectl create rolebinding secret-reader-binding \
    --role=secret-reader \
    --serviceaccount=cka-q64:reader-sa \
    -n cka-q64
EOF
}

# ─── Q65 ─────────────────────────────────────────────────────────────────────
setup_q65() { _ns cka-q65; kubectl delete pod sec-pod -n cka-q65 --force --grace-period=0 2>/dev/null; echo "Namespace cka-q65 ready."; }
show_q65() { cat <<'EOF'
  TASK — Pod with runAsUser SecurityContext
  ──────────────────────────────────────────────────────────────
  Create Pod 'sec-pod' in namespace 'cka-q65':
    Image: nginx:1.25
    securityContext (pod-level):
      runAsUser:    1000
      runAsGroup:   3000

  Verify:
    kubectl exec sec-pod -n cka-q65 -- id
    # Should show: uid=1000 gid=3000

  ── 한국어 ─────────────────────────────────────────────
  cka-q65 에 파드 'sec-pod' 를 생성하세요. (이미지: nginx:1.25)
    securityContext (파드 레벨): runAsUser=1000, runAsGroup=3000
EOF
}
validate_q65() {
  kubectl get pod sec-pod -n cka-q65 &>/dev/null || { echo -e "  ${RED}✗ Pod not found${NC}"; return 1; }
  local uid gid
  uid=$(kubectl get pod sec-pod -n cka-q65 -o jsonpath='{.spec.securityContext.runAsUser}')
  gid=$(kubectl get pod sec-pod -n cka-q65 -o jsonpath='{.spec.securityContext.runAsGroup}')
  local ok=true
  [[ "$uid" != "1000" ]] && { echo -e "  ${RED}✗ runAsUser=$uid (want 1000)${NC}"; ok=false; }
  [[ "$gid" != "3000" ]] && { echo -e "  ${RED}✗ runAsGroup=$gid (want 3000)${NC}"; ok=false; }
  [[ "$ok" == "true" ]] && echo -e "  ${GREEN}✓ Pod runs as uid=1000, gid=3000.${NC}"
  [[ "$ok" == "true" ]]
}
hint_q65() { cat <<'EOF'
  spec:
    securityContext:
      runAsUser: 1000
      runAsGroup: 3000
    containers:
    - name: nginx
      image: nginx:1.25
EOF
}

# ─── Q66 ─────────────────────────────────────────────────────────────────────
setup_q66() { _ns cka-q66; kubectl delete pod ro-pod -n cka-q66 --force --grace-period=0 2>/dev/null; echo "Namespace cka-q66 ready."; }
show_q66() { cat <<'EOF'
  TASK — Pod with Read-Only Root Filesystem
  ──────────────────────────────────────────────────────────────
  Create Pod 'ro-pod' in namespace 'cka-q66':
    Image: nginx:1.25
    securityContext (container-level):
      readOnlyRootFilesystem: true

  TIP: nginx needs /tmp writable — add an emptyDir at /tmp.

  ── 한국어 ─────────────────────────────────────────────
  cka-q66 에 파드 'ro-pod' 를 생성하세요. (이미지: nginx:1.25)
    securityContext (컨테이너 레벨): readOnlyRootFilesystem=true
  팁: nginx 는 /tmp 쓰기 권한이 필요하므로 emptyDir 볼륨을 /tmp 에 마운트하세요.
EOF
}
validate_q66() {
  kubectl get pod ro-pod -n cka-q66 &>/dev/null || { echo -e "  ${RED}✗ Pod not found${NC}"; return 1; }
  local ro; ro=$(kubectl get pod ro-pod -n cka-q66 -o jsonpath='{.spec.containers[0].securityContext.readOnlyRootFilesystem}')
  [[ "$ro" != "true" ]] && { echo -e "  ${RED}✗ readOnlyRootFilesystem=$ro (want true)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Pod has readOnlyRootFilesystem=true.${NC}"
}
hint_q66() { cat <<'EOF'
  spec:
    containers:
    - name: nginx
      image: nginx:1.25
      securityContext:
        readOnlyRootFilesystem: true
      volumeMounts:
      - name: tmp
        mountPath: /tmp
    volumes:
    - name: tmp
      emptyDir: {}
EOF
}

# ─── Q67 ─────────────────────────────────────────────────────────────────────
setup_q67() { _ns cka-q67; kubectl delete pod cap-pod -n cka-q67 --force --grace-period=0 2>/dev/null; echo "Namespace cka-q67 ready."; }
show_q67() { cat <<'EOF'
  TASK — Pod with Added Linux Capability
  ──────────────────────────────────────────────────────────────
  Create Pod 'cap-pod' in namespace 'cka-q67':
    Image: busybox:1.36
    Command: ["sleep", "3600"]
    securityContext (container-level):
      capabilities:
        add: ["NET_ADMIN"]

  ── 한국어 ─────────────────────────────────────────────
  cka-q67 에 파드 'cap-pod' 를 생성하세요. (이미지: busybox:1.36, 명령어: sleep 3600)
    securityContext (컨테이너 레벨): capabilities.add=[NET_ADMIN]
EOF
}
validate_q67() {
  kubectl get pod cap-pod -n cka-q67 &>/dev/null || { echo -e "  ${RED}✗ Pod not found${NC}"; return 1; }
  local caps; caps=$(kubectl get pod cap-pod -n cka-q67 -o jsonpath='{.spec.containers[0].securityContext.capabilities.add}')
  [[ "$caps" != *"NET_ADMIN"* ]] && { echo -e "  ${RED}✗ capabilities.add=$caps (want NET_ADMIN)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Pod has capability NET_ADMIN added.${NC}"
}
hint_q67() { cat <<'EOF'
  spec:
    containers:
    - name: app
      image: busybox:1.36
      command: ["sleep","3600"]
      securityContext:
        capabilities:
          add:
          - NET_ADMIN
EOF
}

# ─── Q68 ─────────────────────────────────────────────────────────────────────
setup_q68() { _ns cka-q68; kubectl delete resourcequota cka-rq -n cka-q68 2>/dev/null; echo "Namespace cka-q68 ready."; }
show_q68() { cat <<'EOF'
  TASK — Create a ResourceQuota for a Namespace
  ──────────────────────────────────────────────────────────────
  Create ResourceQuota 'cka-rq' in namespace 'cka-q68':
    pods:             10
    requests.cpu:     2
    requests.memory:  1Gi
    limits.cpu:       4
    limits.memory:    2Gi

  Verify:  kubectl describe resourcequota cka-rq -n cka-q68

  ── 한국어 ─────────────────────────────────────────────
  cka-q68 에 ResourceQuota 'cka-rq' 를 생성하세요.
    파드 수: 10 / CPU 요청: 2 / 메모리 요청: 1Gi / CPU 제한: 4 / 메모리 제한: 2Gi
EOF
}
validate_q68() {
  kubectl get resourcequota cka-rq -n cka-q68 &>/dev/null || { echo -e "  ${RED}✗ ResourceQuota not found${NC}"; return 1; }
  local pods; pods=$(kubectl get resourcequota cka-rq -n cka-q68 -o jsonpath='{.spec.hard.pods}')
  local cpu_req; cpu_req=$(kubectl get resourcequota cka-rq -n cka-q68 -o jsonpath='{.spec.hard.requests\.cpu}')
  local ok=true
  [[ "$pods" != "10" ]] && { echo -e "  ${RED}✗ pods=$pods (want 10)${NC}"; ok=false; }
  [[ "$cpu_req" != "2" ]] && { echo -e "  ${RED}✗ requests.cpu=$cpu_req (want 2)${NC}"; ok=false; }
  [[ "$ok" == "true" ]] && echo -e "  ${GREEN}✓ ResourceQuota created with correct limits.${NC}"
  [[ "$ok" == "true" ]]
}
hint_q68() { cat <<'EOF'
  kubectl create resourcequota cka-rq -n cka-q68 \
    --hard=pods=10,requests.cpu=2,requests.memory=1Gi,limits.cpu=4,limits.memory=2Gi
EOF
}

# ─── Q69 ─────────────────────────────────────────────────────────────────────
setup_q69() { _ns cka-q69; kubectl delete limitrange cka-lr -n cka-q69 2>/dev/null; echo "Namespace cka-q69 ready."; }
show_q69() { cat <<'EOF'
  TASK — Create a LimitRange for a Namespace
  ──────────────────────────────────────────────────────────────
  Create LimitRange 'cka-lr' in namespace 'cka-q69':
    type: Container
    default:
      cpu:    500m
      memory: 256Mi
    defaultRequest:
      cpu:    100m
      memory: 64Mi

  (LimitRange sets default resource limits on pods that don't specify them)

  ── 한국어 ─────────────────────────────────────────────
  cka-q69 에 LimitRange 'cka-lr' 를 생성하세요.
    기본 제한: cpu=500m, memory=256Mi
    기본 요청: cpu=100m, memory=64Mi
  LimitRange 는 리소스를 명시하지 않은 파드에 기본값을 자동 적용합니다.
EOF
}
validate_q69() {
  kubectl get limitrange cka-lr -n cka-q69 &>/dev/null || { echo -e "  ${RED}✗ LimitRange not found${NC}"; return 1; }
  local cpu; cpu=$(kubectl get limitrange cka-lr -n cka-q69 -o jsonpath='{.spec.limits[0].default.cpu}')
  [[ "$cpu" != "500m" ]] && { echo -e "  ${RED}✗ default.cpu=$cpu (want 500m)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ LimitRange 'cka-lr' created with correct defaults.${NC}"
}
hint_q69() { cat <<'EOF'
  apiVersion: v1
  kind: LimitRange
  metadata:
    name: cka-lr
    namespace: cka-q69
  spec:
    limits:
    - type: Container
      default:
        cpu: 500m
        memory: 256Mi
      defaultRequest:
        cpu: 100m
        memory: 64Mi
EOF
}

# ─── Q70 ─────────────────────────────────────────────────────────────────────
setup_q70() {
  _ns cka-q70
  kubectl delete pod toleration-pod -n cka-q70 --force --grace-period=0 2>/dev/null
  local w; w=$(_worker); echo "$w" > /tmp/cka-q70-node
  kubectl taint node "$w" dedicated=special:NoSchedule --overwrite 2>/dev/null
  echo "Node '$w' tainted with dedicated=special:NoSchedule."
}
show_q70() {
  local w="node01"; [[ -f /tmp/cka-q70-node ]] && w=$(cat /tmp/cka-q70-node)
  cat <<EOF
  TASK — Taint + Toleration
  ──────────────────────────────────────────────────────────────
  Node '$w' has taint: dedicated=special:NoSchedule

  Create Pod 'toleration-pod' in namespace 'cka-q70':
    Image: nginx:1.25
    tolerations:
      key:    dedicated
      value:  special
      effect: NoSchedule

  ── 한국어 ─────────────────────────────────────────────
  노드 '$w' 에 테인트 dedicated=special:NoSchedule 이 설정되어 있습니다.
  해당 테인트를 허용(toleration)하는 파드 'toleration-pod' 를 cka-q70 에 생성하세요.
EOF
}
validate_q70() {
  kubectl get pod toleration-pod -n cka-q70 &>/dev/null || { echo -e "  ${RED}✗ Pod not found${NC}"; return 1; }
  local tols; tols=$(kubectl get pod toleration-pod -n cka-q70 -o jsonpath='{.spec.tolerations}')
  [[ "$tols" != *"dedicated"* ]] && { echo -e "  ${RED}✗ Missing toleration for key 'dedicated'${NC}"; return 1; }
  [[ "$tols" != *"NoSchedule"* ]] && { echo -e "  ${RED}✗ Toleration effect is not NoSchedule${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Pod has toleration for dedicated=special:NoSchedule.${NC}"
}
hint_q70() { cat <<'EOF'
  spec:
    tolerations:
    - key: dedicated
      value: special
      effect: NoSchedule
    containers:
    - name: nginx
      image: nginx:1.25
EOF
}

# ─── Q71 ─────────────────────────────────────────────────────────────────────
setup_q71() {
  _ns cka-q71
  kubectl delete pod affinity-pod -n cka-q71 --force --grace-period=0 2>/dev/null
  local w; w=$(_worker); echo "$w" > /tmp/cka-q71-node
  kubectl label node "$w" zone=us-east-1 --overwrite 2>/dev/null
  echo "Node '$w' labeled zone=us-east-1."
}
show_q71() {
  local w="node01"; [[ -f /tmp/cka-q71-node ]] && w=$(cat /tmp/cka-q71-node)
  cat <<EOF
  TASK — NodeAffinity: Required Scheduling
  ──────────────────────────────────────────────────────────────
  Node '$w' has label: zone=us-east-1

  Create Pod 'affinity-pod' in namespace 'cka-q71':
    Image: nginx:1.25
    nodeAffinity:
      requiredDuringSchedulingIgnoredDuringExecution:
        nodeSelectorTerms:
        - matchExpressions:
          - key: zone
            operator: In
            values: [us-east-1]

  ── 한국어 ─────────────────────────────────────────────
  노드 '$w' 에 zone=us-east-1 레이블이 있습니다.
  cka-q71 에 파드 'affinity-pod' 를 생성하세요.
    nodeAffinity (required): zone 레이블 값이 us-east-1 인 노드에만 스케줄링
EOF
}
validate_q71() {
  kubectl get pod affinity-pod -n cka-q71 &>/dev/null || { echo -e "  ${RED}✗ Pod not found${NC}"; return 1; }
  local aff; aff=$(kubectl get pod affinity-pod -n cka-q71 -o jsonpath='{.spec.affinity}')
  [[ -z "$aff" ]]                          && { echo -e "  ${RED}✗ No affinity defined${NC}"; return 1; }
  [[ "$aff" != *"requiredDuring"* ]]       && { echo -e "  ${RED}✗ Not using requiredDuringScheduling${NC}"; return 1; }
  [[ "$aff" != *"zone"* ]]                 && { echo -e "  ${RED}✗ Affinity not targeting 'zone' label${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Pod uses requiredDuringScheduling NodeAffinity on zone=us-east-1.${NC}"
}
hint_q71() { cat <<'EOF'
  spec:
    affinity:
      nodeAffinity:
        requiredDuringSchedulingIgnoredDuringExecution:
          nodeSelectorTerms:
          - matchExpressions:
            - key: zone
              operator: In
              values:
              - us-east-1
    containers:
    - name: nginx
      image: nginx:1.25
EOF
}

# ─── Q72 ─────────────────────────────────────────────────────────────────────
setup_q72() { _ns cka-q72; kubectl delete pod preferred-pod -n cka-q72 --force --grace-period=0 2>/dev/null; echo "Namespace cka-q72 ready."; }
show_q72() { cat <<'EOF'
  TASK — NodeAffinity: Preferred Scheduling
  ──────────────────────────────────────────────────────────────
  Create Pod 'preferred-pod' in namespace 'cka-q72':
    Image: nginx:1.25
    nodeAffinity:
      preferredDuringSchedulingIgnoredDuringExecution:
      - weight: 50
        preference:
          matchExpressions:
          - key: disktype
            operator: In
            values: [ssd]

  (Pod prefers ssd nodes but will run anywhere if none available)

  ── 한국어 ─────────────────────────────────────────────
  cka-q72 에 파드 'preferred-pod' 를 생성하세요. (이미지: nginx:1.25)
    nodeAffinity (preferred, weight=50): disktype=ssd 노드를 선호하지만 없으면 어디서든 실행
EOF
}
validate_q72() {
  kubectl get pod preferred-pod -n cka-q72 &>/dev/null || { echo -e "  ${RED}✗ Pod not found${NC}"; return 1; }
  local aff; aff=$(kubectl get pod preferred-pod -n cka-q72 -o jsonpath='{.spec.affinity}')
  [[ "$aff" != *"preferredDuring"* ]] && { echo -e "  ${RED}✗ Not using preferredDuringScheduling${NC}"; return 1; }
  [[ "$aff" != *"disktype"* ]]         && { echo -e "  ${RED}✗ Not targeting disktype label${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Pod uses preferredDuringScheduling NodeAffinity on disktype=ssd.${NC}"
}
hint_q72() { cat <<'EOF'
  spec:
    affinity:
      nodeAffinity:
        preferredDuringSchedulingIgnoredDuringExecution:
        - weight: 50
          preference:
            matchExpressions:
            - key: disktype
              operator: In
              values:
              - ssd
    containers:
    - name: nginx
      image: nginx:1.25
EOF
}

# ─── Q73 ─────────────────────────────────────────────────────────────────────
setup_q73() {
  _ns cka-q73
  kubectl delete pod spread-pod -n cka-q73 --force --grace-period=0 2>/dev/null
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: v1
kind: Pod
metadata:
  name: existing-pod
  namespace: cka-q73
  labels:
    app: myapp
spec:
  containers:
  - name: nginx
    image: nginx:1.25
EOF
  echo "Existing pod 'existing-pod' (app=myapp) running in cka-q73."
}
show_q73() { cat <<'EOF'
  TASK — Pod Anti-Affinity
  ──────────────────────────────────────────────────────────────
  An 'existing-pod' (label app=myapp) runs in namespace 'cka-q73'.

  Create Pod 'spread-pod' in namespace 'cka-q73':
    Image: nginx:1.25
    label: app=myapp
    podAntiAffinity:
      requiredDuringSchedulingIgnoredDuringExecution:
      - labelSelector:
          matchExpressions:
          - key: app, operator: In, values: [myapp]
        topologyKey: kubernetes.io/hostname

  (Ensures 'spread-pod' runs on a different node than 'existing-pod')

  ── 한국어 ─────────────────────────────────────────────
  cka-q73 에 파드 'spread-pod' 를 생성하세요. (레이블: app=myapp)
    podAntiAffinity (required): app=myapp 파드가 있는 노드에는 스케줄링 금지
    topologyKey: kubernetes.io/hostname (노드 단위로 분산)
EOF
}
validate_q73() {
  kubectl get pod spread-pod -n cka-q73 &>/dev/null || { echo -e "  ${RED}✗ Pod 'spread-pod' not found${NC}"; return 1; }
  local aff; aff=$(kubectl get pod spread-pod -n cka-q73 -o jsonpath='{.spec.affinity}')
  [[ "$aff" != *"podAntiAffinity"*        ]] && { echo -e "  ${RED}✗ No podAntiAffinity found${NC}"; return 1; }
  [[ "$aff" != *"hostname"* ]]               && { echo -e "  ${RED}✗ topologyKey must include 'hostname'${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Pod has podAntiAffinity by hostname.${NC}"
}
hint_q73() { cat <<'EOF'
  spec:
    affinity:
      podAntiAffinity:
        requiredDuringSchedulingIgnoredDuringExecution:
        - labelSelector:
            matchExpressions:
            - key: app
              operator: In
              values:
              - myapp
          topologyKey: kubernetes.io/hostname
    containers:
    - name: nginx
      image: nginx:1.25
EOF
}

# ─── Q74 ─────────────────────────────────────────────────────────────────────
setup_q74() {
  _ns cka-q74
  kubectl delete pod nodename-pod -n cka-q74 --force --grace-period=0 2>/dev/null
  local cp; cp=$(_cp); echo "$cp" > /tmp/cka-q74-cp
  echo "Controlplane node: $cp"
}
show_q74() {
  local cp="controlplane"; [[ -f /tmp/cka-q74-cp ]] && cp=$(cat /tmp/cka-q74-cp)
  cat <<EOF
  TASK — Schedule Pod on Specific Node (nodeName)
  ──────────────────────────────────────────────────────────────
  Create Pod 'nodename-pod' in namespace 'cka-q74':
    Image:    nginx:1.25
    nodeName: $cp
    Tolerations for controlplane taint (if needed):
      key: node-role.kubernetes.io/control-plane
      effect: NoSchedule
      operator: Exists

  ── 한국어 ─────────────────────────────────────────────
  cka-q74 에 파드 'nodename-pod' 를 생성하세요.
    nodeName: $cp (스케줄러를 거치지 않고 직접 노드 지정)
    컨트롤플레인의 NoSchedule 테인트에 대한 toleration 도 추가하세요.
EOF
}
validate_q74() {
  kubectl get pod nodename-pod -n cka-q74 &>/dev/null || { echo -e "  ${RED}✗ Pod not found${NC}"; return 1; }
  local cp; cp=$(cat /tmp/cka-q74-cp 2>/dev/null || echo "controlplane")
  local node; node=$(kubectl get pod nodename-pod -n cka-q74 -o jsonpath='{.spec.nodeName}')
  [[ "$node" != "$cp" ]] && { echo -e "  ${RED}✗ nodeName=$node (want $cp)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Pod 'nodename-pod' scheduled on $cp via nodeName.${NC}"
}
hint_q74() {
  local cp; cp=$(cat /tmp/cka-q74-cp 2>/dev/null || echo "controlplane")
  cat <<EOF
  spec:
    nodeName: $cp
    tolerations:
    - key: node-role.kubernetes.io/control-plane
      operator: Exists
      effect: NoSchedule
    containers:
    - name: nginx
      image: nginx:1.25
EOF
}

# ─── Q75 ─────────────────────────────────────────────────────────────────────
setup_q75() {
  local w; w=$(_worker); echo "$w" > /tmp/cka-q75-node
  kubectl uncordon "$w" 2>/dev/null
  kubectl label node "$w" maintenance- 2>/dev/null
  echo "Node '$w' uncordoned. Ready for maintenance task."
}
show_q75() {
  local w="node01"; [[ -f /tmp/cka-q75-node ]] && w=$(cat /tmp/cka-q75-node)
  cat <<EOF
  TASK — Cordon Node + Label it for Maintenance
  ──────────────────────────────────────────────────────────────
  Worker node: $w

  Perform BOTH:
    1. Cordon node '$w' (prevent new pod scheduling)
    2. Add label:  maintenance=true  to node '$w'

  Verify:
    kubectl get node $w  # STATUS should show SchedulingDisabled
    kubectl get node $w --show-labels

  ── 한국어 ─────────────────────────────────────────────
  워커 노드 '$w' 에 두 가지를 수행하세요:
    1. 코든(cordon): 새 파드 스케줄링 차단 (기존 파드는 유지)
    2. 레이블 추가: maintenance=true
EOF
}
validate_q75() {
  local w; w=$(cat /tmp/cka-q75-node 2>/dev/null || _worker)
  local ok=true
  local sched; sched=$(kubectl get node "$w" -o jsonpath='{.spec.unschedulable}')
  [[ "$sched" != "true" ]] && { echo -e "  ${RED}✗ Node is NOT cordoned${NC}"; ok=false; }
  local lbl; lbl=$(kubectl get node "$w" -o jsonpath='{.metadata.labels.maintenance}')
  [[ "$lbl" != "true" ]] && { echo -e "  ${RED}✗ label maintenance=$lbl (want true)${NC}"; ok=false; }
  [[ "$ok" == "true" ]] && echo -e "  ${GREEN}✓ Node cordoned and labeled maintenance=true.${NC}"
  [[ "$ok" == "true" ]]
}
hint_q75() {
  local w; w=$(cat /tmp/cka-q75-node 2>/dev/null || echo "node01")
  cat <<EOF
  kubectl cordon $w
  kubectl label node $w maintenance=true
  kubectl get node $w --show-labels
EOF
}

# ─── Q76 ─────────────────────────────────────────────────────────────────────
setup_q76() {
  _ns cka-q76
  kubectl delete pdb app-pdb -n cka-q76 2>/dev/null
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ha-app
  namespace: cka-q76
spec:
  replicas: 4
  selector:
    matchLabels:
      app: ha-app
  template:
    metadata:
      labels:
        app: ha-app
    spec:
      containers:
      - name: web
        image: nginx:1.25
EOF
  echo "Deployment 'ha-app' (4 replicas) ready in cka-q76."
}
show_q76() { cat <<'EOF'
  TASK — Create a PodDisruptionBudget
  ──────────────────────────────────────────────────────────────
  Deployment 'ha-app' has 4 replicas in namespace 'cka-q76'.

  Create PodDisruptionBudget 'app-pdb':
    Namespace:    cka-q76
    selector:     app=ha-app
    minAvailable: 2

  (Ensures at least 2 pods always remain during voluntary disruptions)

  ── 한국어 ─────────────────────────────────────────────
  cka-q76 에 PodDisruptionBudget 'app-pdb' 를 생성하세요.
    셀렉터: app=ha-app / minAvailable: 2
  자발적 중단(드레인 등) 시 최소 2개 파드는 항상 유지됩니다.
EOF
}
validate_q76() {
  kubectl get pdb app-pdb -n cka-q76 &>/dev/null || { echo -e "  ${RED}✗ PDB 'app-pdb' not found${NC}"; return 1; }
  local min; min=$(kubectl get pdb app-pdb -n cka-q76 -o jsonpath='{.spec.minAvailable}')
  [[ "$min" != "2" ]] && { echo -e "  ${RED}✗ minAvailable=$min (want 2)${NC}"; return 1; }
  local sel; sel=$(kubectl get pdb app-pdb -n cka-q76 -o jsonpath='{.spec.selector.matchLabels.app}')
  [[ "$sel" != "ha-app" ]] && { echo -e "  ${RED}✗ selector.app=$sel (want ha-app)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ PDB ensures minAvailable=2 for app=ha-app.${NC}"
}
hint_q76() { cat <<'EOF'
  kubectl create poddisruptionbudget app-pdb \
    --selector=app=ha-app \
    --min-available=2 \
    -n cka-q76
EOF
}

# ─── Q77 ─────────────────────────────────────────────────────────────────────
setup_q77() {
  _ns cka-q77
  kubectl delete role deployment-manager -n cka-q77 2>/dev/null
  kubectl delete rolebinding deploy-manager-binding -n cka-q77 2>/dev/null
  kubectl delete sa deploy-sa -n cka-q77 2>/dev/null
  kubectl create sa deploy-sa -n cka-q77 2>/dev/null
  echo "SA 'deploy-sa' created in cka-q77."
}
show_q77() { cat <<'EOF'
  TASK — RBAC for Deployment Management
  ──────────────────────────────────────────────────────────────
  SA 'deploy-sa' exists in namespace 'cka-q77'.

  Create Role 'deployment-manager':
    apiGroups: ["apps"]
    resources: ["deployments"]
    verbs:     ["get", "list", "create", "update", "patch", "delete"]

  Create RoleBinding 'deploy-manager-binding':
    Binds Role 'deployment-manager' to SA 'deploy-sa'

  Verify:
    kubectl auth can-i create deployments \
      --as=system:serviceaccount:cka-q77:deploy-sa -n cka-q77

  ── 한국어 ─────────────────────────────────────────────
  cka-q77 에서 Deployment 관리 RBAC 을 구성하세요:
    1. Role 'deployment-manager': apps/deployments 에 전체 CRUD 권한
    2. RoleBinding 'deploy-manager-binding': SA 'deploy-sa' 에 바인딩
EOF
}
validate_q77() {
  kubectl get role deployment-manager -n cka-q77 &>/dev/null || { echo -e "  ${RED}✗ Role not found${NC}"; return 1; }
  kubectl get rolebinding deploy-manager-binding -n cka-q77 &>/dev/null || { echo -e "  ${RED}✗ RoleBinding not found${NC}"; return 1; }
  local ag; ag=$(kubectl get role deployment-manager -n cka-q77 -o jsonpath='{.rules[0].apiGroups[0]}')
  [[ "$ag" != "apps" ]] && { echo -e "  ${RED}✗ apiGroup=$ag (want apps)${NC}"; return 1; }
  local can; can=$(kubectl auth can-i create deployments --as=system:serviceaccount:cka-q77:deploy-sa -n cka-q77 2>/dev/null)
  echo -e "  ${GREEN}✓ RBAC for apps/deployments correct. can-i create deployments=$can${NC}"
}
hint_q77() { cat <<'EOF'
  kubectl create role deployment-manager \
    --verb=get,list,create,update,patch,delete \
    --resource=deployments \
    -n cka-q77

  # Note: --resource=deployments uses apps apiGroup automatically
  kubectl create rolebinding deploy-manager-binding \
    --role=deployment-manager \
    --serviceaccount=cka-q77:deploy-sa \
    -n cka-q77
EOF
}

# ─── Q78 ─────────────────────────────────────────────────────────────────────
setup_q78() { _ns cka-q78; kubectl delete pod group-pod -n cka-q78 --force --grace-period=0 2>/dev/null; echo "Namespace cka-q78 ready."; }
show_q78() { cat <<'EOF'
  TASK — Pod with runAsGroup + fsGroup
  ──────────────────────────────────────────────────────────────
  Create Pod 'group-pod' in namespace 'cka-q78':
    Image: nginx:1.25
    securityContext (pod-level):
      runAsUser:  2000
      runAsGroup: 4000
      fsGroup:    5000

  fsGroup ensures volumes are owned by group 5000.

  Verify:
    kubectl exec group-pod -n cka-q78 -- id

  ── 한국어 ─────────────────────────────────────────────
  cka-q78 에 파드 'group-pod' 를 생성하세요. (이미지: nginx:1.25)
    securityContext: runAsUser=2000, runAsGroup=4000, fsGroup=5000
  fsGroup: 마운트된 볼륨의 소유 그룹을 5000 으로 설정
EOF
}
validate_q78() {
  kubectl get pod group-pod -n cka-q78 &>/dev/null || { echo -e "  ${RED}✗ Pod not found${NC}"; return 1; }
  local uid gid fsg
  uid=$(kubectl get pod group-pod -n cka-q78 -o jsonpath='{.spec.securityContext.runAsUser}')
  gid=$(kubectl get pod group-pod -n cka-q78 -o jsonpath='{.spec.securityContext.runAsGroup}')
  fsg=$(kubectl get pod group-pod -n cka-q78 -o jsonpath='{.spec.securityContext.fsGroup}')
  local ok=true
  [[ "$uid" != "2000" ]] && { echo -e "  ${RED}✗ runAsUser=$uid (want 2000)${NC}"; ok=false; }
  [[ "$gid" != "4000" ]] && { echo -e "  ${RED}✗ runAsGroup=$gid (want 4000)${NC}"; ok=false; }
  [[ "$fsg" != "5000" ]] && { echo -e "  ${RED}✗ fsGroup=$fsg (want 5000)${NC}"; ok=false; }
  [[ "$ok" == "true" ]] && echo -e "  ${GREEN}✓ Pod securityContext: runAsUser=2000, runAsGroup=4000, fsGroup=5000.${NC}"
  [[ "$ok" == "true" ]]
}
hint_q78() { cat <<'EOF'
  spec:
    securityContext:
      runAsUser: 2000
      runAsGroup: 4000
      fsGroup: 5000
    containers:
    - name: nginx
      image: nginx:1.25
EOF
}

# ─── Q79 ─────────────────────────────────────────────────────────────────────
setup_q79() {
  kubectl delete namespace quota-ns 2>/dev/null; sleep 2
  echo "Namespace 'quota-ns' removed. Create it with a ResourceQuota."
}
show_q79() { cat <<'EOF'
  TASK — Create Namespace + Apply ResourceQuota
  ──────────────────────────────────────────────────────────────
  Step 1: Create namespace 'quota-ns'

  Step 2: Create ResourceQuota 'ns-quota' in 'quota-ns':
    pods: 5
    requests.cpu: 1
    requests.memory: 512Mi

  Verify:
    kubectl describe namespace quota-ns
    kubectl get resourcequota ns-quota -n quota-ns

  ── 한국어 ─────────────────────────────────────────────
  1단계: 네임스페이스 'quota-ns' 를 생성하세요.
  2단계: 'quota-ns' 에 ResourceQuota 'ns-quota' 를 생성하세요:
    pods: 5 / requests.cpu: 1 / requests.memory: 512Mi
EOF
}
validate_q79() {
  kubectl get namespace quota-ns &>/dev/null || { echo -e "  ${RED}✗ Namespace 'quota-ns' not found${NC}"; return 1; }
  kubectl get resourcequota ns-quota -n quota-ns &>/dev/null || { echo -e "  ${RED}✗ ResourceQuota 'ns-quota' not found${NC}"; return 1; }
  local pods; pods=$(kubectl get resourcequota ns-quota -n quota-ns -o jsonpath='{.spec.hard.pods}')
  [[ "$pods" != "5" ]] && { echo -e "  ${RED}✗ pods quota=$pods (want 5)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Namespace 'quota-ns' created with ResourceQuota pods=5.${NC}"
}
hint_q79() { cat <<'EOF'
  kubectl create namespace quota-ns
  kubectl create resourcequota ns-quota \
    --hard=pods=5,requests.cpu=1,requests.memory=512Mi \
    -n quota-ns
EOF
}

# ─── Q80 ─────────────────────────────────────────────────────────────────────
setup_q80() {
  kubectl delete clusterrole health-reader 2>/dev/null
  echo "ClusterRole 'health-reader' removed."
}
show_q80() { cat <<'EOF'
  TASK — ClusterRole for Non-Resource URL
  ──────────────────────────────────────────────────────────────
  Create ClusterRole 'health-reader':
    nonResourceURLs: ["/healthz", "/readyz"]
    verbs:           ["get"]

  This allows reading the API server's health endpoints.

  Verify:
    kubectl describe clusterrole health-reader

  ── 한국어 ─────────────────────────────────────────────
  ClusterRole 'health-reader' 를 생성하세요:
    nonResourceURLs: ["/healthz", "/readyz"]
    verbs: ["get"]
  API 서버의 헬스 엔드포인트에 읽기 권한을 부여합니다.
EOF
}
validate_q80() {
  kubectl get clusterrole health-reader &>/dev/null || { echo -e "  ${RED}✗ ClusterRole 'health-reader' not found${NC}"; return 1; }
  local nru; nru=$(kubectl get clusterrole health-reader -o jsonpath='{.rules[0].nonResourceURLs}')
  [[ "$nru" != *"healthz"* ]] && { echo -e "  ${RED}✗ nonResourceURLs doesn't include /healthz: $nru${NC}"; return 1; }
  echo -e "  ${GREEN}✓ ClusterRole 'health-reader' with nonResourceURLs=[/healthz, /readyz].${NC}"
}
hint_q80() { cat <<'EOF'
  apiVersion: rbac.authorization.k8s.io/v1
  kind: ClusterRole
  metadata:
    name: health-reader
  rules:
  - nonResourceURLs:
    - /healthz
    - /readyz
    verbs:
    - get
EOF
}
