#!/usr/bin/env bash
# Batch 1: Pods & Deployments (Q1–Q20) — sourced by run.sh

BATCH_TITLE="Batch 1 — Pods & Deployments (Q1–Q20)"
Q_TITLES=(""
  "Create Pod with Labels"
  "Fix Deployment Wrong Image"
  "Scale Deployment to 4 Replicas"
  "Rolling Update Deployment Image"
  "Pod with Resource Requests & Limits"
  "Create a DaemonSet"
  "Create a Job"
  "Create a CronJob"
  "Fix CrashLoopBackOff Pod"
  "Multi-Container Pod (Sidecar)"
  "Pod with Init Container"
  "Pod with Liveness Probe (httpGet)"
  "Pod with Readiness Probe (httpGet)"
  "Add Annotation to Deployment"
  "Pod with NodeSelector (label node first)"
  "Rollback a Deployment"
  "Create a Static Pod"
  "Pod with Literal Env Vars"
  "Pod Using a ServiceAccount"
  "Change Deployment Update Strategy to Recreate"
)

_ns() { kubectl create namespace "$1" --dry-run=client -o yaml | kubectl apply -f - 2>/dev/null; }

# ─── Q1 ──────────────────────────────────────────────────────────────────────
setup_q1() { _ns cka-q1; kubectl delete pod web-pod -n cka-q1 --force --grace-period=0 2>/dev/null; echo "Namespace cka-q1 ready."; }
show_q1() { cat <<'EOF'
  TASK — Create a Pod with Labels
  ──────────────────────────────────────────────────────────────
  Create a Pod:
    Name:           web-pod
    Namespace:      cka-q1
    Image:          nginx:1.25
    Labels:         app=web, tier=frontend
    restartPolicy:  Never

  ── 한국어 ─────────────────────────────────────────────
  네임스페이스 cka-q1 에 파드를 생성하세요.
    이름: web-pod / 이미지: nginx:1.25
    레이블: app=web, tier=frontend / 재시작 정책: Never
EOF
}
validate_q1() {
  kubectl get pod web-pod -n cka-q1 &>/dev/null || { echo -e "  ${RED}✗ Pod 'web-pod' not found in cka-q1${NC}"; return 1; }
  local img app tier
  img=$(kubectl get pod web-pod -n cka-q1 -o jsonpath='{.spec.containers[0].image}')
  app=$(kubectl get pod web-pod -n cka-q1 -o jsonpath='{.metadata.labels.app}')
  tier=$(kubectl get pod web-pod -n cka-q1 -o jsonpath='{.metadata.labels.tier}')
  local ok=true
  [[ "$img"  != "nginx:1.25"  ]] && { echo -e "  ${RED}✗ image=$img (want nginx:1.25)${NC}"; ok=false; }
  [[ "$app"  != "web"         ]] && { echo -e "  ${RED}✗ label app=$app (want web)${NC}"; ok=false; }
  [[ "$tier" != "frontend"    ]] && { echo -e "  ${RED}✗ label tier=$tier (want frontend)${NC}"; ok=false; }
  [[ "$ok" == "true" ]] && echo -e "  ${GREEN}✓ Pod created with correct image and labels.${NC}"
  [[ "$ok" == "true" ]]
}
hint_q1() { cat <<'EOF'
  kubectl run web-pod --image=nginx:1.25 --labels="app=web,tier=frontend" --restart=Never -n cka-q1
EOF
}

# ─── Q2 ──────────────────────────────────────────────────────────────────────
setup_q2() {
  _ns cka-q2
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: apps/v1
kind: Deployment
metadata:
  name: api-server
  namespace: cka-q2
spec:
  replicas: 2
  selector:
    matchLabels:
      app: api-server
  template:
    metadata:
      labels:
        app: api-server
    spec:
      containers:
      - name: api
        image: nginx:BROKEN_TAG
EOF
  echo "Deployment 'api-server' created with broken image in cka-q2."
}
show_q2() { cat <<'EOF'
  TASK — Fix Deployment with Wrong Image
  ──────────────────────────────────────────────────────────────
  Deployment 'api-server' in namespace 'cka-q2' has pods in
  ImagePullBackOff/ErrImagePull. Fix the image to: nginx:1.25
  Ensure 2/2 replicas are Running.

    kubectl get pods -n cka-q2
    kubectl describe deployment api-server -n cka-q2

  ── 한국어 ─────────────────────────────────────────────
  cka-q2 의 Deployment 'api-server' 가 잘못된 이미지로
  ImagePullBackOff 상태입니다. 이미지를 nginx:1.25 로 수정하고
  2/2 레플리카가 Running 인지 확인하세요.
EOF
}
validate_q2() {
  local img; img=$(kubectl get deploy api-server -n cka-q2 -o jsonpath='{.spec.template.spec.containers[0].image}' 2>/dev/null)
  [[ "$img" != "nginx:1.25" ]] && { echo -e "  ${RED}✗ image=$img (want nginx:1.25)${NC}"; return 1; }
  kubectl rollout status deploy/api-server -n cka-q2 --timeout=60s &>/dev/null
  local ready; ready=$(kubectl get deploy api-server -n cka-q2 -o jsonpath='{.status.readyReplicas}')
  [[ "$ready" != "2" ]] && { echo -e "  ${RED}✗ only ${ready}/2 replicas ready${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Image fixed → nginx:1.25, 2/2 replicas ready.${NC}"
}
hint_q2() { cat <<'EOF'
  kubectl set image deployment/api-server api=nginx:1.25 -n cka-q2
  kubectl rollout status deployment/api-server -n cka-q2
EOF
}

# ─── Q3 ──────────────────────────────────────────────────────────────────────
setup_q3() {
  _ns cka-q3
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: apps/v1
kind: Deployment
metadata:
  name: frontend
  namespace: cka-q3
spec:
  replicas: 1
  selector:
    matchLabels:
      app: frontend
  template:
    metadata:
      labels:
        app: frontend
    spec:
      containers:
      - name: web
        image: nginx:1.25
EOF
  echo "Deployment 'frontend' with 1 replica in cka-q3."
}
show_q3() { cat <<'EOF'
  TASK — Scale Deployment to 4 Replicas
  ──────────────────────────────────────────────────────────────
  Deployment 'frontend' in namespace 'cka-q3' has 1 replica.
  Scale it to 4 replicas and verify all pods are Running.

    kubectl get deployment frontend -n cka-q3

  ── 한국어 ─────────────────────────────────────────────
  cka-q3 의 Deployment 'frontend' 가 1개 레플리카로 실행 중입니다.
  4개로 스케일 업하고 모든 파드가 Running 인지 확인하세요.
EOF
}
validate_q3() {
  local rep; rep=$(kubectl get deploy frontend -n cka-q3 -o jsonpath='{.spec.replicas}')
  [[ "$rep" != "4" ]] && { echo -e "  ${RED}✗ replicas=$rep (want 4)${NC}"; return 1; }
  kubectl rollout status deploy/frontend -n cka-q3 --timeout=60s &>/dev/null
  local ready; ready=$(kubectl get deploy frontend -n cka-q3 -o jsonpath='{.status.readyReplicas}')
  [[ "$ready" != "4" ]] && { echo -e "  ${RED}✗ only ${ready}/4 ready${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Deployment scaled to 4 replicas, all Running.${NC}"
}
hint_q3() { cat <<'EOF'
  kubectl scale deployment frontend --replicas=4 -n cka-q3
EOF
}

# ─── Q4 ──────────────────────────────────────────────────────────────────────
setup_q4() {
  _ns cka-q4
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: apps/v1
kind: Deployment
metadata:
  name: backend
  namespace: cka-q4
spec:
  replicas: 2
  selector:
    matchLabels:
      app: backend
  template:
    metadata:
      labels:
        app: backend
    spec:
      containers:
      - name: app
        image: nginx:1.23
EOF
  echo "Deployment 'backend' with image nginx:1.23 in cka-q4."
}
show_q4() { cat <<'EOF'
  TASK — Rolling Update Deployment Image
  ──────────────────────────────────────────────────────────────
  Deployment 'backend' in namespace 'cka-q4' runs nginx:1.23.
  Update it to use image: nginx:1.25
  Verify the rollout completes (2/2 ready).

    kubectl rollout status deployment/backend -n cka-q4

  ── 한국어 ─────────────────────────────────────────────
  cka-q4 의 Deployment 'backend' 가 nginx:1.23 으로 실행 중입니다.
  이미지를 nginx:1.25 로 업데이트하고 롤아웃이 완료(2/2)되었는지 확인하세요.
EOF
}
validate_q4() {
  local img; img=$(kubectl get deploy backend -n cka-q4 -o jsonpath='{.spec.template.spec.containers[0].image}')
  [[ "$img" != "nginx:1.25" ]] && { echo -e "  ${RED}✗ image=$img (want nginx:1.25)${NC}"; return 1; }
  kubectl rollout status deploy/backend -n cka-q4 --timeout=60s &>/dev/null
  local ready; ready=$(kubectl get deploy backend -n cka-q4 -o jsonpath='{.status.readyReplicas}')
  [[ "$ready" != "2" ]] && { echo -e "  ${RED}✗ only ${ready}/2 ready${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Image updated to nginx:1.25, 2/2 running.${NC}"
}
hint_q4() { cat <<'EOF'
  kubectl set image deployment/backend app=nginx:1.25 -n cka-q4
  kubectl rollout status deployment/backend -n cka-q4
EOF
}

# ─── Q5 ──────────────────────────────────────────────────────────────────────
setup_q5() { _ns cka-q5; kubectl delete pod limit-pod -n cka-q5 --force --grace-period=0 2>/dev/null; echo "Namespace cka-q5 ready."; }
show_q5() { cat <<'EOF'
  TASK — Pod with Resource Requests & Limits
  ──────────────────────────────────────────────────────────────
  Create a Pod:
    Name:       limit-pod
    Namespace:  cka-q5
    Image:      nginx:1.25
    resources:
      requests:  cpu=250m,  memory=64Mi
      limits:    cpu=500m,  memory=128Mi

  ── 한국어 ─────────────────────────────────────────────
  cka-q5 에 파드 'limit-pod' 를 생성하세요. (이미지: nginx:1.25)
    리소스 요청: cpu=250m, memory=64Mi
    리소스 제한: cpu=500m, memory=128Mi
EOF
}
validate_q5() {
  kubectl get pod limit-pod -n cka-q5 &>/dev/null || { echo -e "  ${RED}✗ Pod not found${NC}"; return 1; }
  local cr mr cl ml
  cr=$(kubectl get pod limit-pod -n cka-q5 -o jsonpath='{.spec.containers[0].resources.requests.cpu}')
  mr=$(kubectl get pod limit-pod -n cka-q5 -o jsonpath='{.spec.containers[0].resources.requests.memory}')
  cl=$(kubectl get pod limit-pod -n cka-q5 -o jsonpath='{.spec.containers[0].resources.limits.cpu}')
  ml=$(kubectl get pod limit-pod -n cka-q5 -o jsonpath='{.spec.containers[0].resources.limits.memory}')
  local ok=true
  [[ "$cr" != "250m"  ]] && { echo -e "  ${RED}✗ cpu.request=$cr (want 250m)${NC}"; ok=false; }
  [[ "$mr" != "64Mi"  ]] && { echo -e "  ${RED}✗ mem.request=$mr (want 64Mi)${NC}"; ok=false; }
  [[ "$cl" != "500m"  ]] && { echo -e "  ${RED}✗ cpu.limit=$cl (want 500m)${NC}"; ok=false; }
  [[ "$ml" != "128Mi" ]] && { echo -e "  ${RED}✗ mem.limit=$ml (want 128Mi)${NC}"; ok=false; }
  [[ "$ok" == "true" ]] && echo -e "  ${GREEN}✓ Resource requests and limits set correctly.${NC}"
  [[ "$ok" == "true" ]]
}
hint_q5() { cat <<'EOF'
  # Generate base yaml, add resources block under containers:
  kubectl run limit-pod --image=nginx:1.25 -n cka-q5 --dry-run=client -o yaml > pod5.yaml
  # Add:  resources:
  #         requests: { cpu: "250m", memory: "64Mi" }
  #         limits:   { cpu: "500m", memory: "128Mi" }
  kubectl apply -f pod5.yaml
EOF
}

# ─── Q6 ──────────────────────────────────────────────────────────────────────
setup_q6() { _ns cka-q6; kubectl delete daemonset log-ds -n cka-q6 2>/dev/null; echo "Namespace cka-q6 ready."; }
show_q6() { cat <<'EOF'
  TASK — Create a DaemonSet
  ──────────────────────────────────────────────────────────────
  Create a DaemonSet:
    Name:       log-ds
    Namespace:  cka-q6
    Image:      nginx:1.25
    Label:      app=log-ds

  A DaemonSet runs one pod per node (including controlplane if untainted).

  ── 한국어 ─────────────────────────────────────────────
  cka-q6 에 DaemonSet 'log-ds' 를 생성하세요. (이미지: nginx:1.25, 레이블: app=log-ds)
  DaemonSet 은 모든 노드에 파드 1개씩 자동으로 실행됩니다.
  (kubectl create daemonset 명령어는 없음 — YAML 로 작성하세요)
EOF
}
validate_q6() {
  kubectl get daemonset log-ds -n cka-q6 &>/dev/null || { echo -e "  ${RED}✗ DaemonSet 'log-ds' not found${NC}"; return 1; }
  local img; img=$(kubectl get daemonset log-ds -n cka-q6 -o jsonpath='{.spec.template.spec.containers[0].image}')
  [[ "$img" != "nginx:1.25" ]] && { echo -e "  ${RED}✗ image=$img (want nginx:1.25)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ DaemonSet 'log-ds' exists with image nginx:1.25.${NC}"
}
hint_q6() { cat <<'EOF'
  # DaemonSet YAML (cannot use kubectl create daemonset directly):
  apiVersion: apps/v1
  kind: DaemonSet
  metadata:
    name: log-ds
    namespace: cka-q6
  spec:
    selector:
      matchLabels:
        app: log-ds
    template:
      metadata:
        labels:
          app: log-ds
      spec:
        containers:
        - name: log
          image: nginx:1.25
EOF
}

# ─── Q7 ──────────────────────────────────────────────────────────────────────
setup_q7() { _ns cka-q7; kubectl delete job pi-job -n cka-q7 2>/dev/null; echo "Namespace cka-q7 ready."; }
show_q7() { cat <<'EOF'
  TASK — Create a Job
  ──────────────────────────────────────────────────────────────
  Create a Job:
    Name:         pi-job
    Namespace:    cka-q7
    Image:        busybox:1.36
    Command:      ["sh", "-c", "echo 'Job Done!'"]
    Completions:  1 (default)
    restartPolicy: Never

  ── 한국어 ─────────────────────────────────────────────
  cka-q7 에 Job 'pi-job' 을 생성하세요.
    이미지: busybox:1.36 / 명령어: echo 'Job Done!' / 재시작: Never
EOF
}
validate_q7() {
  kubectl get job pi-job -n cka-q7 &>/dev/null || { echo -e "  ${RED}✗ Job 'pi-job' not found${NC}"; return 1; }
  local img; img=$(kubectl get job pi-job -n cka-q7 -o jsonpath='{.spec.template.spec.containers[0].image}')
  [[ "$img" != "busybox:1.36" ]] && { echo -e "  ${RED}✗ image=$img (want busybox:1.36)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Job 'pi-job' created with busybox:1.36.${NC}"
}
hint_q7() { cat <<'EOF'
  kubectl create job pi-job --image=busybox:1.36 -n cka-q7 \
    -- sh -c "echo 'Job Done!'"
EOF
}

# ─── Q8 ──────────────────────────────────────────────────────────────────────
setup_q8() { _ns cka-q8; kubectl delete cronjob cleanup -n cka-q8 2>/dev/null; echo "Namespace cka-q8 ready."; }
show_q8() { cat <<'EOF'
  TASK — Create a CronJob
  ──────────────────────────────────────────────────────────────
  Create a CronJob:
    Name:      cleanup
    Namespace: cka-q8
    Schedule:  */1 * * * *  (every minute)
    Image:     busybox:1.36
    Command:   ["sh", "-c", "date; echo cleanup done"]
    restartPolicy: OnFailure

  ── 한국어 ─────────────────────────────────────────────
  cka-q8 에 CronJob 'cleanup' 을 생성하세요.
    스케줄: */1 * * * * (매 1분) / 이미지: busybox:1.36 / 재시작: OnFailure
EOF
}
validate_q8() {
  kubectl get cronjob cleanup -n cka-q8 &>/dev/null || { echo -e "  ${RED}✗ CronJob 'cleanup' not found${NC}"; return 1; }
  local sched; sched=$(kubectl get cronjob cleanup -n cka-q8 -o jsonpath='{.spec.schedule}')
  local img;   img=$(kubectl get cronjob cleanup -n cka-q8 -o jsonpath='{.spec.jobTemplate.spec.template.spec.containers[0].image}')
  local ok=true
  [[ "$sched" != "*/1 * * * *" ]] && { echo -e "  ${RED}✗ schedule='$sched' (want '*/1 * * * *')${NC}"; ok=false; }
  [[ "$img" != "busybox:1.36"  ]] && { echo -e "  ${RED}✗ image=$img (want busybox:1.36)${NC}"; ok=false; }
  [[ "$ok" == "true" ]] && echo -e "  ${GREEN}✓ CronJob 'cleanup' with correct schedule and image.${NC}"
  [[ "$ok" == "true" ]]
}
hint_q8() { cat <<'EOF'
  kubectl create cronjob cleanup --image=busybox:1.36 \
    --schedule="*/1 * * * *" -n cka-q8 \
    -- sh -c "date; echo cleanup done"
EOF
}

# ─── Q9 ──────────────────────────────────────────────────────────────────────
setup_q9() {
  _ns cka-q9
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: v1
kind: Pod
metadata:
  name: crash-pod
  namespace: cka-q9
spec:
  containers:
  - name: app
    image: busybox:1.36
    command: ["sh", "-c", "exit 1"]
  restartPolicy: Always
EOF
  echo "Pod 'crash-pod' created with bad command (will CrashLoopBackOff) in cka-q9."
}
show_q9() { cat <<'EOF'
  TASK — Fix CrashLoopBackOff Pod
  ──────────────────────────────────────────────────────────────
  Pod 'crash-pod' in namespace 'cka-q9' is in CrashLoopBackOff.
  Find why it keeps crashing and fix the command so it stays Running.

  Fix: change the command to: ["sleep", "3600"]

  NOTE: Pod spec is immutable — delete and recreate.

    kubectl describe pod crash-pod -n cka-q9
    kubectl logs crash-pod -n cka-q9

  ── 한국어 ─────────────────────────────────────────────
  cka-q9 의 파드 'crash-pod' 가 CrashLoopBackOff 상태입니다.
  충돌 원인을 파악하고 명령어를 ["sleep", "3600"] 으로 수정하세요.
  주의: 파드 spec 은 불변 — yaml 내보내기 후 삭제 & 재생성하세요.
EOF
}
validate_q9() {
  kubectl get pod crash-pod -n cka-q9 &>/dev/null || { echo -e "  ${RED}✗ Pod 'crash-pod' not found${NC}"; return 1; }
  local cmd; cmd=$(kubectl get pod crash-pod -n cka-q9 -o jsonpath='{.spec.containers[0].command}')
  if [[ "$cmd" != *"sleep"* && "$cmd" != *"3600"* ]]; then
    echo -e "  ${RED}✗ Command still looks wrong: $cmd${NC}"; return 1
  fi
  echo -e "  ${GREEN}✓ Pod command fixed — no longer crashing.${NC}"
}
hint_q9() { cat <<'EOF'
  # Export, edit, delete & recreate:
  kubectl get pod crash-pod -n cka-q9 -o yaml > crash-pod.yaml
  # Edit command from ["sh","-c","exit 1"] to ["sleep","3600"]
  kubectl delete pod crash-pod -n cka-q9 --force --grace-period=0
  kubectl apply -f crash-pod.yaml
EOF
}

# ─── Q10 ─────────────────────────────────────────────────────────────────────
setup_q10() { _ns cka-q10; kubectl delete pod two-containers -n cka-q10 --force --grace-period=0 2>/dev/null; echo "Namespace cka-q10 ready."; }
show_q10() { cat <<'EOF'
  TASK — Multi-Container Pod (Sidecar)
  ──────────────────────────────────────────────────────────────
  Create a Pod named 'two-containers' in namespace 'cka-q10':
    Container 1:  name=main,    image=nginx:1.25
    Container 2:  name=sidecar, image=busybox:1.36
                  command=["sh","-c","while true; do echo sidecar; sleep 10; done"]

  ── 한국어 ─────────────────────────────────────────────
  cka-q10 에 파드 'two-containers' 를 생성하세요.
    컨테이너1: main (nginx:1.25)
    컨테이너2: sidecar (busybox:1.36, 10초마다 "sidecar" 출력)
EOF
}
validate_q10() {
  kubectl get pod two-containers -n cka-q10 &>/dev/null || { echo -e "  ${RED}✗ Pod not found${NC}"; return 1; }
  local count; count=$(kubectl get pod two-containers -n cka-q10 -o jsonpath='{.spec.containers[*].name}' | wc -w)
  [[ "$count" -lt 2 ]] && { echo -e "  ${RED}✗ Pod has $count container(s), need 2${NC}"; return 1; }
  local imgs; imgs=$(kubectl get pod two-containers -n cka-q10 -o jsonpath='{.spec.containers[*].image}')
  [[ "$imgs" != *"nginx"* ]]   && { echo -e "  ${RED}✗ Missing nginx container${NC}"; return 1; }
  [[ "$imgs" != *"busybox"* ]] && { echo -e "  ${RED}✗ Missing busybox container${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Pod has 2 containers (nginx + busybox).${NC}"
}
hint_q10() { cat <<'EOF'
  # YAML with two containers:
  spec:
    containers:
    - name: main
      image: nginx:1.25
    - name: sidecar
      image: busybox:1.36
      command: ["sh","-c","while true; do echo sidecar; sleep 10; done"]
EOF
}

# ─── Q11 ─────────────────────────────────────────────────────────────────────
setup_q11() { _ns cka-q11; kubectl delete pod init-demo -n cka-q11 --force --grace-period=0 2>/dev/null; echo "Namespace cka-q11 ready."; }
show_q11() { cat <<'EOF'
  TASK — Pod with Init Container
  ──────────────────────────────────────────────────────────────
  Create a Pod named 'init-demo' in namespace 'cka-q11':
    initContainer:
      name:    init-writer
      image:   busybox:1.36
      command: ["sh","-c","echo initialized > /init/ready"]
      volumeMount: /init  (shared volume named 'init-vol')
    mainContainer:
      name:    app
      image:   nginx:1.25
      volumeMount: /init  (same volume)
    volume:
      name: init-vol
      emptyDir: {}

  ── 한국어 ─────────────────────────────────────────────
  cka-q11 에 파드 'init-demo' 를 생성하세요.
    initContainer: busybox:1.36 → /init/ready 파일 생성 후 종료
    메인 컨테이너: nginx:1.25
    공유 볼륨(emptyDir) 'init-vol' 을 /init 에 마운트 (두 컨테이너 공유)
EOF
}
validate_q11() {
  kubectl get pod init-demo -n cka-q11 &>/dev/null || { echo -e "  ${RED}✗ Pod not found${NC}"; return 1; }
  local ic; ic=$(kubectl get pod init-demo -n cka-q11 -o jsonpath='{.spec.initContainers[0].image}')
  [[ -z "$ic" ]] && { echo -e "  ${RED}✗ No initContainer found${NC}"; return 1; }
  [[ "$ic" != "busybox:1.36" ]] && { echo -e "  ${RED}✗ initContainer image=$ic (want busybox:1.36)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Pod has init container with busybox:1.36.${NC}"
}
hint_q11() { cat <<'EOF'
  spec:
    initContainers:
    - name: init-writer
      image: busybox:1.36
      command: ["sh","-c","echo initialized > /init/ready"]
      volumeMounts:
      - name: init-vol
        mountPath: /init
    containers:
    - name: app
      image: nginx:1.25
      volumeMounts:
      - name: init-vol
        mountPath: /init
    volumes:
    - name: init-vol
      emptyDir: {}
EOF
}

# ─── Q12 ─────────────────────────────────────────────────────────────────────
setup_q12() { _ns cka-q12; kubectl delete pod liveness-pod -n cka-q12 --force --grace-period=0 2>/dev/null; echo "Namespace cka-q12 ready."; }
show_q12() { cat <<'EOF'
  TASK — Pod with Liveness Probe (httpGet)
  ──────────────────────────────────────────────────────────────
  Create a Pod named 'liveness-pod' in namespace 'cka-q12':
    Image: nginx:1.25
    livenessProbe:
      httpGet:
        path: /
        port: 80
      initialDelaySeconds: 5
      periodSeconds: 10

  ── 한국어 ─────────────────────────────────────────────
  cka-q12 에 파드 'liveness-pod' 를 생성하세요. (이미지: nginx:1.25)
    활성 프로브(livenessProbe): httpGet / 경로: / / 포트: 80
    초기 지연: 5초, 주기: 10초
EOF
}
validate_q12() {
  kubectl get pod liveness-pod -n cka-q12 &>/dev/null || { echo -e "  ${RED}✗ Pod not found${NC}"; return 1; }
  local probe; probe=$(kubectl get pod liveness-pod -n cka-q12 -o jsonpath='{.spec.containers[0].livenessProbe.httpGet.port}')
  [[ -z "$probe" ]] && { echo -e "  ${RED}✗ No httpGet liveness probe found${NC}"; return 1; }
  [[ "$probe" != "80" ]] && { echo -e "  ${RED}✗ liveness port=$probe (want 80)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Pod has httpGet liveness probe on port 80.${NC}"
}
hint_q12() { cat <<'EOF'
  # Add under containers:
  livenessProbe:
    httpGet:
      path: /
      port: 80
    initialDelaySeconds: 5
    periodSeconds: 10
EOF
}

# ─── Q13 ─────────────────────────────────────────────────────────────────────
setup_q13() { _ns cka-q13; kubectl delete pod readiness-pod -n cka-q13 --force --grace-period=0 2>/dev/null; echo "Namespace cka-q13 ready."; }
show_q13() { cat <<'EOF'
  TASK — Pod with Readiness Probe (httpGet)
  ──────────────────────────────────────────────────────────────
  Create a Pod named 'readiness-pod' in namespace 'cka-q13':
    Image: nginx:1.25
    readinessProbe:
      httpGet:
        path: /
        port: 80
      initialDelaySeconds: 5
      periodSeconds: 5

  ── 한국어 ─────────────────────────────────────────────
  cka-q13 에 파드 'readiness-pod' 를 생성하세요. (이미지: nginx:1.25)
    준비 프로브(readinessProbe): httpGet / 경로: / / 포트: 80
    초기 지연: 5초, 주기: 5초
EOF
}
validate_q13() {
  kubectl get pod readiness-pod -n cka-q13 &>/dev/null || { echo -e "  ${RED}✗ Pod not found${NC}"; return 1; }
  local probe; probe=$(kubectl get pod readiness-pod -n cka-q13 -o jsonpath='{.spec.containers[0].readinessProbe.httpGet.port}')
  [[ -z "$probe" ]] && { echo -e "  ${RED}✗ No httpGet readiness probe found${NC}"; return 1; }
  [[ "$probe" != "80" ]] && { echo -e "  ${RED}✗ readiness port=$probe (want 80)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Pod has httpGet readiness probe on port 80.${NC}"
}
hint_q13() { cat <<'EOF'
  readinessProbe:
    httpGet:
      path: /
      port: 80
    initialDelaySeconds: 5
    periodSeconds: 5
EOF
}

# ─── Q14 ─────────────────────────────────────────────────────────────────────
setup_q14() {
  _ns cka-q14
  kubectl create deployment app --image=nginx:1.25 -n cka-q14 2>/dev/null || true
  echo "Deployment 'app' in cka-q14 ready."
}
show_q14() { cat <<'EOF'
  TASK — Add Annotation to a Deployment
  ──────────────────────────────────────────────────────────────
  Deployment 'app' exists in namespace 'cka-q14'.
  Add annotation:  contact=admin@company.com

    kubectl describe deployment app -n cka-q14

  ── 한국어 ─────────────────────────────────────────────
  cka-q14 의 Deployment 'app' 에 어노테이션을 추가하세요.
    contact=admin@company.com
EOF
}
validate_q14() {
  local ann; ann=$(kubectl get deploy app -n cka-q14 -o jsonpath='{.metadata.annotations.contact}' 2>/dev/null)
  [[ "$ann" != "admin@company.com" ]] && { echo -e "  ${RED}✗ annotation contact='$ann' (want 'admin@company.com')${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Annotation contact=admin@company.com added to deployment.${NC}"
}
hint_q14() { cat <<'EOF'
  kubectl annotate deployment app contact=admin@company.com -n cka-q14
EOF
}

# ─── Q15 ─────────────────────────────────────────────────────────────────────
setup_q15() {
  _ns cka-q15
  kubectl delete pod ssd-pod -n cka-q15 --force --grace-period=0 2>/dev/null
  local worker; worker=$(kubectl get nodes --no-headers | grep -v 'control-plane\|master' | awk 'NR==1{print $1}')
  [[ -z "$worker" ]] && worker=$(kubectl get nodes --no-headers | awk 'NR==1{print $1}')
  kubectl label node "$worker" disktype=ssd --overwrite 2>/dev/null
  echo "$worker" > /tmp/cka-q15-node
  echo "Node '$worker' labeled disktype=ssd."
}
show_q15() {
  local w="node01"; [[ -f /tmp/cka-q15-node ]] && w=$(cat /tmp/cka-q15-node)
  cat <<EOF
  TASK — Pod with NodeSelector
  ──────────────────────────────────────────────────────────────
  Node '$w' has been labeled: disktype=ssd

  Create a Pod named 'ssd-pod' in namespace 'cka-q15':
    Image:        nginx:1.25
    nodeSelector: disktype=ssd

  The pod must be scheduled on node '$w'.

  ── 한국어 ─────────────────────────────────────────────
  노드 '$w' 에 disktype=ssd 레이블이 설정되어 있습니다.
  cka-q15 에 파드 'ssd-pod' 를 생성하세요. (이미지: nginx:1.25)
    nodeSelector: disktype=ssd (해당 노드에 스케줄링되어야 함)
EOF
}
validate_q15() {
  kubectl get pod ssd-pod -n cka-q15 &>/dev/null || { echo -e "  ${RED}✗ Pod 'ssd-pod' not found${NC}"; return 1; }
  local ns; ns=$(kubectl get pod ssd-pod -n cka-q15 -o jsonpath='{.spec.nodeSelector.disktype}')
  [[ "$ns" != "ssd" ]] && { echo -e "  ${RED}✗ nodeSelector disktype=$ns (want ssd)${NC}"; return 1; }
  local node; node=$(kubectl get pod ssd-pod -n cka-q15 -o jsonpath='{.spec.nodeName}')
  local expected; expected=$(cat /tmp/cka-q15-node 2>/dev/null)
  [[ -n "$expected" && "$node" != "$expected" ]] && { echo -e "  ${RED}✗ Pod on node=$node (want $expected)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Pod 'ssd-pod' uses nodeSelector disktype=ssd and runs on correct node.${NC}"
}
hint_q15() { cat <<'EOF'
  # Pod YAML with nodeSelector:
  spec:
    nodeSelector:
      disktype: ssd
    containers:
    - name: nginx
      image: nginx:1.25
EOF
}

# ─── Q16 ─────────────────────────────────────────────────────────────────────
setup_q16() {
  _ns cka-q16
  kubectl delete deploy webapp -n cka-q16 2>/dev/null; sleep 2
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: apps/v1
kind: Deployment
metadata:
  name: webapp
  namespace: cka-q16
spec:
  replicas: 2
  selector:
    matchLabels:
      app: webapp
  template:
    metadata:
      labels:
        app: webapp
    spec:
      containers:
      - name: web
        image: nginx:1.24
EOF
  sleep 3
  kubectl set image deployment/webapp web=nginx:ROLLBACK_BROKEN -n cka-q16 2>/dev/null
  echo "Deployment 'webapp' updated to broken image. Rollback required."
}
show_q16() { cat <<'EOF'
  TASK — Rollback a Deployment
  ──────────────────────────────────────────────────────────────
  Deployment 'webapp' in namespace 'cka-q16' was updated to a broken
  image. Rollback it to the previous working revision (nginx:1.24).

    kubectl rollout history deployment/webapp -n cka-q16
    kubectl rollout undo deployment/webapp -n cka-q16

  ── 한국어 ─────────────────────────────────────────────
  cka-q16 의 Deployment 'webapp' 이 잘못된 이미지로 업데이트되었습니다.
  이전 정상 버전(nginx:1.24)으로 롤백하세요.
EOF
}
validate_q16() {
  local img; img=$(kubectl get deploy webapp -n cka-q16 -o jsonpath='{.spec.template.spec.containers[0].image}')
  [[ "$img" != "nginx:1.24" ]] && { echo -e "  ${RED}✗ image=$img (want nginx:1.24 after rollback)${NC}"; return 1; }
  kubectl rollout status deploy/webapp -n cka-q16 --timeout=60s &>/dev/null
  echo -e "  ${GREEN}✓ Deployment rolled back to nginx:1.24.${NC}"
}
hint_q16() { cat <<'EOF'
  kubectl rollout undo deployment/webapp -n cka-q16
  kubectl rollout status deployment/webapp -n cka-q16
  # To roll back to a specific revision:
  # kubectl rollout undo deployment/webapp --to-revision=1 -n cka-q16
EOF
}

# ─── Q17 ─────────────────────────────────────────────────────────────────────
setup_q17() {
  rm -f /etc/kubernetes/manifests/static-nginx.yaml 2>/dev/null
  local cp_node; cp_node=$(kubectl get nodes --no-headers | grep -i 'control-plane\|master' | awk 'NR==1{print $1}')
  [[ -z "$cp_node" ]] && cp_node=$(hostname)
  echo "$cp_node" > /tmp/cka-q17-cp
  echo "Static pod manifest removed. Controlplane: $cp_node"
  echo "Directory /etc/kubernetes/manifests is where kubelet watches for static pods."
}
show_q17() {
  local cp="controlplane"; [[ -f /tmp/cka-q17-cp ]] && cp=$(cat /tmp/cka-q17-cp)
  cat <<EOF
  TASK — Create a Static Pod
  ──────────────────────────────────────────────────────────────
  Create a static pod manifest on the controlplane node ($cp):

    File:  /etc/kubernetes/manifests/static-nginx.yaml
    Name:  static-nginx
    Image: nginx:1.25

  The kubelet will auto-create the pod. It will appear as:
    static-nginx-${cp}

  ── 한국어 ─────────────────────────────────────────────
  컨트롤플레인 노드($cp) 에 정적 파드 매니페스트를 생성하세요.
    파일: /etc/kubernetes/manifests/static-nginx.yaml
    이름: static-nginx / 이미지: nginx:1.25
  kubelet 이 자동으로 파드를 생성하며 'static-nginx-$cp' 로 표시됩니다.
EOF
}
validate_q17() {
  if [[ ! -f /etc/kubernetes/manifests/static-nginx.yaml ]]; then
    echo -e "  ${RED}✗ /etc/kubernetes/manifests/static-nginx.yaml not found${NC}"; return 1
  fi
  echo -e "  ${YELLOW}  Waiting for kubelet to create static pod (5s)...${NC}"; sleep 5
  local pod; pod=$(kubectl get pods --all-namespaces --no-headers 2>/dev/null | grep "static-nginx" | awk '{print $2}')
  [[ -z "$pod" ]] && { echo -e "  ${RED}✗ Static pod not appearing in cluster yet${NC}"; return 1; }
  local img; img=$(kubectl get pod "$pod" -A -o jsonpath='{.spec.containers[0].image}' 2>/dev/null)
  [[ "$img" != "nginx:1.25" ]] && { echo -e "  ${RED}✗ image=$img (want nginx:1.25)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Static pod '$pod' running with nginx:1.25.${NC}"
}
hint_q17() { cat <<'EOF'
  cat > /etc/kubernetes/manifests/static-nginx.yaml <<MANIFEST
  apiVersion: v1
  kind: Pod
  metadata:
    name: static-nginx
  spec:
    containers:
    - name: nginx
      image: nginx:1.25
  MANIFEST
  # kubelet will auto-create it. Check with:
  kubectl get pods | grep static-nginx
EOF
}

# ─── Q18 ─────────────────────────────────────────────────────────────────────
setup_q18() { _ns cka-q18; kubectl delete pod env-pod -n cka-q18 --force --grace-period=0 2>/dev/null; echo "Namespace cka-q18 ready."; }
show_q18() { cat <<'EOF'
  TASK — Pod with Literal Env Vars
  ──────────────────────────────────────────────────────────────
  Create a Pod named 'env-pod' in namespace 'cka-q18':
    Image: nginx:1.25
    env:
      APP_ENV=production
      APP_PORT=8080

  Verify:
    kubectl exec env-pod -n cka-q18 -- env | grep APP

  ── 한국어 ─────────────────────────────────────────────
  cka-q18 에 파드 'env-pod' 를 생성하세요. (이미지: nginx:1.25)
    환경변수: APP_ENV=production, APP_PORT=8080
EOF
}
validate_q18() {
  kubectl get pod env-pod -n cka-q18 &>/dev/null || { echo -e "  ${RED}✗ Pod not found${NC}"; return 1; }
  local env_json; env_json=$(kubectl get pod env-pod -n cka-q18 -o jsonpath='{.spec.containers[0].env}')
  [[ "$env_json" != *"APP_ENV"*     ]] && { echo -e "  ${RED}✗ Missing env var APP_ENV${NC}"; return 1; }
  [[ "$env_json" != *"production"*  ]] && { echo -e "  ${RED}✗ APP_ENV is not 'production'${NC}"; return 1; }
  [[ "$env_json" != *"APP_PORT"*    ]] && { echo -e "  ${RED}✗ Missing env var APP_PORT${NC}"; return 1; }
  [[ "$env_json" != *"8080"*        ]] && { echo -e "  ${RED}✗ APP_PORT is not '8080'${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Pod has env vars APP_ENV=production and APP_PORT=8080.${NC}"
}
hint_q18() { cat <<'EOF'
  kubectl run env-pod --image=nginx:1.25 -n cka-q18 \
    --env="APP_ENV=production" --env="APP_PORT=8080"
EOF
}

# ─── Q19 ─────────────────────────────────────────────────────────────────────
setup_q19() {
  _ns cka-q19
  kubectl delete serviceaccount custom-sa -n cka-q19 2>/dev/null
  kubectl delete pod sa-pod -n cka-q19 --force --grace-period=0 2>/dev/null
  kubectl create serviceaccount custom-sa -n cka-q19 2>/dev/null
  echo "ServiceAccount 'custom-sa' created in cka-q19. Create pod using it."
}
show_q19() { cat <<'EOF'
  TASK — Pod Using a ServiceAccount
  ──────────────────────────────────────────────────────────────
  A ServiceAccount named 'custom-sa' exists in namespace 'cka-q19'.

  Create a Pod named 'sa-pod' in namespace 'cka-q19':
    Image:             nginx:1.25
    serviceAccountName: custom-sa

  ── 한국어 ─────────────────────────────────────────────
  cka-q19 에 ServiceAccount 'custom-sa' 가 이미 있습니다.
  해당 SA 를 사용하는 파드 'sa-pod' 를 생성하세요. (이미지: nginx:1.25)
    spec.serviceAccountName: custom-sa
EOF
}
validate_q19() {
  kubectl get pod sa-pod -n cka-q19 &>/dev/null || { echo -e "  ${RED}✗ Pod 'sa-pod' not found${NC}"; return 1; }
  local sa; sa=$(kubectl get pod sa-pod -n cka-q19 -o jsonpath='{.spec.serviceAccountName}')
  [[ "$sa" != "custom-sa" ]] && { echo -e "  ${RED}✗ serviceAccountName=$sa (want custom-sa)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Pod 'sa-pod' uses serviceAccountName=custom-sa.${NC}"
}
hint_q19() { cat <<'EOF'
  # In pod YAML under spec:
  serviceAccountName: custom-sa
  # OR generate and edit:
  kubectl run sa-pod --image=nginx:1.25 -n cka-q19 --dry-run=client -o yaml > pod19.yaml
  # Add 'serviceAccountName: custom-sa' under spec
EOF
}

# ─── Q20 ─────────────────────────────────────────────────────────────────────
setup_q20() {
  _ns cka-q20
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: apps/v1
kind: Deployment
metadata:
  name: rolling
  namespace: cka-q20
spec:
  replicas: 2
  strategy:
    type: RollingUpdate
  selector:
    matchLabels:
      app: rolling
  template:
    metadata:
      labels:
        app: rolling
    spec:
      containers:
      - name: app
        image: nginx:1.25
EOF
  echo "Deployment 'rolling' with RollingUpdate strategy in cka-q20."
}
show_q20() { cat <<'EOF'
  TASK — Change Deployment Update Strategy to Recreate
  ──────────────────────────────────────────────────────────────
  Deployment 'rolling' in namespace 'cka-q20' uses RollingUpdate.
  Change its update strategy to: Recreate

  (Recreate kills all pods before creating new ones.)

    kubectl describe deployment rolling -n cka-q20

  ── 한국어 ─────────────────────────────────────────────
  cka-q20 의 Deployment 'rolling' 이 RollingUpdate 전략을 사용 중입니다.
  업데이트 전략을 Recreate 로 변경하세요.
  (Recreate: 새 파드 생성 전 기존 파드를 모두 먼저 종료)
EOF
}
validate_q20() {
  local strat; strat=$(kubectl get deploy rolling -n cka-q20 -o jsonpath='{.spec.strategy.type}')
  [[ "$strat" != "Recreate" ]] && { echo -e "  ${RED}✗ strategy=$strat (want Recreate)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Deployment strategy changed to Recreate.${NC}"
}
hint_q20() { cat <<'EOF'
  kubectl patch deployment rolling -n cka-q20 \
    -p '{"spec":{"strategy":{"type":"Recreate","rollingUpdate":null}}}'
  # OR:  kubectl edit deployment rolling -n cka-q20
  # Change: strategy.type from RollingUpdate → Recreate
  # Remove: rollingUpdate block
EOF
}
