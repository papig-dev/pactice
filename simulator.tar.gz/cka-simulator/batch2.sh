#!/usr/bin/env bash
# Batch 2: Services & Networking (Q21–Q40) — sourced by run.sh

BATCH_TITLE="Batch 2 — Services & Networking (Q21–Q40)"
Q_TITLES=(""
  "Create ClusterIP Service"
  "Fix Service with Wrong Selector"
  "Create NodePort Service (30090)"
  "NetworkPolicy: Allow role=api → role=db"
  "NetworkPolicy: Deny All Ingress"
  "Create a Headless Service"
  "Fix Service with Wrong TargetPort"
  "NetworkPolicy: Allow from Labeled Namespace"
  "Create Multi-Port Service (80 & 443)"
  "Expose Deployment as ClusterIP"
  "Service with SessionAffinity=ClientIP"
  "NetworkPolicy: Deny All Egress"
  "Create ExternalName Service"
  "NetworkPolicy: Allow Specific Pod Selector + Port"
  "Fix Service with Wrong Port"
  "NodePort Service on Port 30095"
  "NetworkPolicy: Allow Egress to Port 443 Only"
  "NetworkPolicy: Allow Ingress from CIDR"
  "Service with Named Port"
  "Fix Service with Wrong Selector AND Port"
)

_ns() { kubectl create namespace "$1" --dry-run=client -o yaml | kubectl apply -f - 2>/dev/null; }

# ─── Q21 ─────────────────────────────────────────────────────────────────────
setup_q21() {
  _ns cka-q21
  kubectl delete svc web-svc -n cka-q21 2>/dev/null
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: apps/v1
kind: Deployment
metadata:
  name: web-app
  namespace: cka-q21
spec:
  replicas: 2
  selector:
    matchLabels:
      app: web-app
  template:
    metadata:
      labels:
        app: web-app
    spec:
      containers:
      - name: nginx
        image: nginx:1.25
        ports:
        - containerPort: 80
EOF
  echo "Deployment 'web-app' ready. No service exists yet."
}
show_q21() { cat <<'EOF'
  TASK — Create a ClusterIP Service
  ──────────────────────────────────────────────────────────────
  Deployment 'web-app' in namespace 'cka-q21' serves on port 80.
  Pods have label: app=web-app

  Create a ClusterIP Service:
    Name:        web-svc
    Namespace:   cka-q21
    Port:        80
    TargetPort:  80
    Selector:    app=web-app

  Verify endpoints: kubectl get endpoints web-svc -n cka-q21

  ── 한국어 ─────────────────────────────────────────────
  cka-q21 의 Deployment 'web-app' (포트 80) 앞에
  ClusterIP Service 'web-svc' 를 생성하세요.
    포트: 80 / 셀렉터: app=web-app
EOF
}
validate_q21() {
  kubectl get svc web-svc -n cka-q21 &>/dev/null || { echo -e "  ${RED}✗ Service 'web-svc' not found${NC}"; return 1; }
  local t p sel
  t=$(kubectl get svc web-svc -n cka-q21 -o jsonpath='{.spec.type}')
  p=$(kubectl get svc web-svc -n cka-q21 -o jsonpath='{.spec.ports[0].port}')
  sel=$(kubectl get svc web-svc -n cka-q21 -o jsonpath='{.spec.selector.app}')
  local ok=true
  [[ "$t" != "ClusterIP" ]] && { echo -e "  ${RED}✗ type=$t (want ClusterIP)${NC}"; ok=false; }
  [[ "$p" != "80"         ]] && { echo -e "  ${RED}✗ port=$p (want 80)${NC}"; ok=false; }
  [[ "$sel" != "web-app"  ]] && { echo -e "  ${RED}✗ selector.app=$sel (want web-app)${NC}"; ok=false; }
  [[ "$ok" == "true" ]] && echo -e "  ${GREEN}✓ ClusterIP service 'web-svc' created correctly.${NC}"
  [[ "$ok" == "true" ]]
}
hint_q21() { cat <<'EOF'
  kubectl expose deployment web-app --name=web-svc \
    --port=80 --target-port=80 --type=ClusterIP -n cka-q21
EOF
}

# ─── Q22 ─────────────────────────────────────────────────────────────────────
setup_q22() {
  _ns cka-q22
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: apps/v1
kind: Deployment
metadata:
  name: backend
  namespace: cka-q22
spec:
  replicas: 2
  selector:
    matchLabels:
      app: backend
  template:
    metadata:
      labels:
        app: backend
    spec:
      containers:
      - name: app
        image: nginx:1.25
        ports:
        - containerPort: 80
---
apiVersion: v1
kind: Service
metadata:
  name: broken-svc
  namespace: cka-q22
spec:
  selector:
    app: wrong-label
  ports:
  - port: 80
    targetPort: 80
EOF
  echo "Service 'broken-svc' with wrong selector in cka-q22."
}
show_q22() { cat <<'EOF'
  TASK — Fix Service with Wrong Selector
  ──────────────────────────────────────────────────────────────
  Service 'broken-svc' in namespace 'cka-q22' has no endpoints.
  Its selector does NOT match the backend pods.

  Fix the selector so endpoints are populated.

    kubectl get pods -n cka-q22 --show-labels
    kubectl describe svc broken-svc -n cka-q22
    kubectl get endpoints broken-svc -n cka-q22

  ── 한국어 ─────────────────────────────────────────────
  cka-q22 의 Service 'broken-svc' 의 셀렉터가 파드 레이블과 맞지 않아
  엔드포인트가 없습니다. 셀렉터를 올바르게 수정하세요. (정답: app=backend)
EOF
}
validate_q22() {
  local sel; sel=$(kubectl get svc broken-svc -n cka-q22 -o jsonpath='{.spec.selector.app}')
  [[ "$sel" != "backend" ]] && { echo -e "  ${RED}✗ selector.app=$sel (want 'backend')${NC}"; return 1; }
  local ep; ep=$(kubectl get endpoints broken-svc -n cka-q22 -o jsonpath='{.subsets}')
  [[ -z "$ep" || "$ep" == "[]" ]] && { echo -e "  ${RED}✗ No endpoints populated yet${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Selector fixed → endpoints now populated.${NC}"
}
hint_q22() { cat <<'EOF'
  kubectl patch svc broken-svc -n cka-q22 \
    -p '{"spec":{"selector":{"app":"backend"}}}'
EOF
}

# ─── Q23 ─────────────────────────────────────────────────────────────────────
setup_q23() {
  _ns cka-q23
  kubectl delete svc np-svc -n cka-q23 2>/dev/null
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: apps/v1
kind: Deployment
metadata:
  name: app
  namespace: cka-q23
spec:
  replicas: 1
  selector:
    matchLabels:
      app: app
  template:
    metadata:
      labels:
        app: app
    spec:
      containers:
      - name: web
        image: nginx:1.25
        ports:
        - containerPort: 80
EOF
  echo "Deployment 'app' ready in cka-q23."
}
show_q23() { cat <<'EOF'
  TASK — Create NodePort Service on Port 30090
  ──────────────────────────────────────────────────────────────
  Deployment 'app' exists in namespace 'cka-q23'.

  Create a NodePort Service:
    Name:       np-svc
    Namespace:  cka-q23
    Port:       80
    TargetPort: 80
    NodePort:   30090
    Selector:   app=app

  ── 한국어 ─────────────────────────────────────────────
  cka-q23 에 NodePort Service 'np-svc' 를 생성하세요.
    포트: 80 / NodePort: 30090 / 셀렉터: app=app
EOF
}
validate_q23() {
  kubectl get svc np-svc -n cka-q23 &>/dev/null || { echo -e "  ${RED}✗ Service 'np-svc' not found${NC}"; return 1; }
  local t np p
  t=$(kubectl get svc np-svc -n cka-q23 -o jsonpath='{.spec.type}')
  np=$(kubectl get svc np-svc -n cka-q23 -o jsonpath='{.spec.ports[0].nodePort}')
  p=$(kubectl get svc np-svc -n cka-q23 -o jsonpath='{.spec.ports[0].port}')
  local ok=true
  [[ "$t" != "NodePort" ]] && { echo -e "  ${RED}✗ type=$t (want NodePort)${NC}"; ok=false; }
  [[ "$np" != "30090"   ]] && { echo -e "  ${RED}✗ nodePort=$np (want 30090)${NC}"; ok=false; }
  [[ "$p" != "80"       ]] && { echo -e "  ${RED}✗ port=$p (want 80)${NC}"; ok=false; }
  [[ "$ok" == "true" ]] && echo -e "  ${GREEN}✓ NodePort service on port 80 exposed as nodePort 30090.${NC}"
  [[ "$ok" == "true" ]]
}
hint_q23() { cat <<'EOF'
  kubectl expose deployment app --name=np-svc --port=80 \
    --target-port=80 --type=NodePort -n cka-q23
  kubectl patch svc np-svc -n cka-q23 \
    -p '{"spec":{"ports":[{"port":80,"targetPort":80,"nodePort":30090}]}}'
EOF
}

# ─── Q24 ─────────────────────────────────────────────────────────────────────
setup_q24() {
  _ns cka-q24
  kubectl delete networkpolicy db-policy -n cka-q24 2>/dev/null
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: v1
kind: Pod
metadata:
  name: db-pod
  namespace: cka-q24
  labels:
    role: db
spec:
  containers:
  - name: db
    image: nginx:1.25
    ports:
    - containerPort: 5432
---
apiVersion: v1
kind: Pod
metadata:
  name: api-pod
  namespace: cka-q24
  labels:
    role: api
spec:
  containers:
  - name: api
    image: nginx:1.25
EOF
  echo "Pods db-pod(role=db) and api-pod(role=api) in cka-q24."
}
show_q24() { cat <<'EOF'
  TASK — NetworkPolicy: Allow role=api → role=db on Port 5432
  ──────────────────────────────────────────────────────────────
  Namespace cka-q24 has:
    db-pod  (label: role=db)
    api-pod (label: role=api)

  Create NetworkPolicy 'db-policy' that:
    - Applies to pods with label: role=db
    - Allows Ingress ONLY from pods with label: role=api
    - On port 5432
    - Denies all other ingress

  ── 한국어 ─────────────────────────────────────────────
  cka-q24 에 NetworkPolicy 'db-policy' 를 생성하세요.
    적용 대상: role=db 파드
    허용: role=api 파드에서 포트 5432 인바운드만 허용
    나머지 인바운드는 모두 차단
EOF
}
validate_q24() {
  kubectl get networkpolicy db-policy -n cka-q24 &>/dev/null || { echo -e "  ${RED}✗ NetworkPolicy 'db-policy' not found${NC}"; return 1; }
  local ps fr port
  ps=$(kubectl get netpol db-policy -n cka-q24 -o jsonpath='{.spec.podSelector.matchLabels.role}')
  fr=$(kubectl get netpol db-policy -n cka-q24 -o jsonpath='{.spec.ingress[0].from[0].podSelector.matchLabels.role}')
  port=$(kubectl get netpol db-policy -n cka-q24 -o jsonpath='{.spec.ingress[0].ports[0].port}')
  local ok=true
  [[ "$ps" != "db"  ]] && { echo -e "  ${RED}✗ podSelector.role=$ps (want db)${NC}"; ok=false; }
  [[ "$fr" != "api" ]] && { echo -e "  ${RED}✗ ingress.from.role=$fr (want api)${NC}"; ok=false; }
  [[ "$port" != "5432" ]] && { echo -e "  ${RED}✗ port=$port (want 5432)${NC}"; ok=false; }
  [[ "$ok" == "true" ]] && echo -e "  ${GREEN}✓ NetworkPolicy allows only role=api → role=db on port 5432.${NC}"
  [[ "$ok" == "true" ]]
}
hint_q24() { cat <<'EOF'
  apiVersion: networking.k8s.io/v1
  kind: NetworkPolicy
  metadata:
    name: db-policy
    namespace: cka-q24
  spec:
    podSelector:
      matchLabels:
        role: db
    policyTypes:
    - Ingress
    ingress:
    - from:
      - podSelector:
          matchLabels:
            role: api
      ports:
      - protocol: TCP
        port: 5432
EOF
}

# ─── Q25 ─────────────────────────────────────────────────────────────────────
setup_q25() { _ns cka-q25; kubectl delete networkpolicy deny-all-ingress -n cka-q25 2>/dev/null; echo "Namespace cka-q25 ready."; }
show_q25() { cat <<'EOF'
  TASK — NetworkPolicy: Deny All Ingress to Namespace
  ──────────────────────────────────────────────────────────────
  Create a NetworkPolicy named 'deny-all-ingress' in namespace 'cka-q25'
  that blocks ALL incoming traffic to ALL pods in the namespace.

  (Empty podSelector = applies to all pods;
   empty ingress = blocks all ingress)

  ── 한국어 ─────────────────────────────────────────────
  cka-q25 의 모든 파드에 대한 인바운드 트래픽을 전부 차단하는
  NetworkPolicy 'deny-all-ingress' 를 생성하세요.
    podSelector: {} (전체 파드) / ingress 규칙: 없음 (전부 차단)
EOF
}
validate_q25() {
  kubectl get netpol deny-all-ingress -n cka-q25 &>/dev/null || { echo -e "  ${RED}✗ NetworkPolicy 'deny-all-ingress' not found${NC}"; return 1; }
  local ps; ps=$(kubectl get netpol deny-all-ingress -n cka-q25 -o jsonpath='{.spec.podSelector}')
  local pt; pt=$(kubectl get netpol deny-all-ingress -n cka-q25 -o jsonpath='{.spec.policyTypes[0]}')
  local ingress; ingress=$(kubectl get netpol deny-all-ingress -n cka-q25 -o jsonpath='{.spec.ingress}')
  [[ "$pt" != "Ingress" ]]          && { echo -e "  ${RED}✗ policyTypes[0]=$pt (want Ingress)${NC}"; return 1; }
  [[ -n "$ingress" && "$ingress" != "[]" ]] && { echo -e "  ${RED}✗ ingress rules exist (should be empty to deny all)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ NetworkPolicy denies all ingress to all pods in cka-q25.${NC}"
}
hint_q25() { cat <<'EOF'
  apiVersion: networking.k8s.io/v1
  kind: NetworkPolicy
  metadata:
    name: deny-all-ingress
    namespace: cka-q25
  spec:
    podSelector: {}
    policyTypes:
    - Ingress
EOF
}

# ─── Q26 ─────────────────────────────────────────────────────────────────────
setup_q26() {
  _ns cka-q26
  kubectl delete svc db-headless -n cka-q26 2>/dev/null
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: apps/v1
kind: Deployment
metadata:
  name: db
  namespace: cka-q26
spec:
  replicas: 2
  selector:
    matchLabels:
      app: db
  template:
    metadata:
      labels:
        app: db
    spec:
      containers:
      - name: db
        image: nginx:1.25
        ports:
        - containerPort: 3306
EOF
  echo "Deployment 'db' ready in cka-q26."
}
show_q26() { cat <<'EOF'
  TASK — Create a Headless Service (clusterIP: None)
  ──────────────────────────────────────────────────────────────
  Deployment 'db' exists in namespace 'cka-q26' with pods app=db.

  Create a headless Service:
    Name:       db-headless
    Namespace:  cka-q26
    clusterIP:  None      ← this makes it headless
    Port:       3306
    Selector:   app=db

  Verify:
    kubectl get svc db-headless -n cka-q26
    # CLUSTER-IP should show: None

  ── 한국어 ─────────────────────────────────────────────
  cka-q26 에 헤드리스 Service 'db-headless' 를 생성하세요.
    clusterIP: None (헤드리스) / 포트: 3306 / 셀렉터: app=db
  헤드리스 서비스는 DNS 로 각 파드 IP 를 직접 반환합니다.
EOF
}
validate_q26() {
  kubectl get svc db-headless -n cka-q26 &>/dev/null || { echo -e "  ${RED}✗ Service 'db-headless' not found${NC}"; return 1; }
  local cip; cip=$(kubectl get svc db-headless -n cka-q26 -o jsonpath='{.spec.clusterIP}')
  [[ "$cip" != "None" ]] && { echo -e "  ${RED}✗ clusterIP=$cip (want None)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Headless service 'db-headless' with clusterIP=None.${NC}"
}
hint_q26() { cat <<'EOF'
  apiVersion: v1
  kind: Service
  metadata:
    name: db-headless
    namespace: cka-q26
  spec:
    clusterIP: None
    selector:
      app: db
    ports:
    - port: 3306
      targetPort: 3306
EOF
}

# ─── Q27 ─────────────────────────────────────────────────────────────────────
setup_q27() {
  _ns cka-q27
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: apps/v1
kind: Deployment
metadata:
  name: webserver
  namespace: cka-q27
spec:
  replicas: 1
  selector:
    matchLabels:
      app: webserver
  template:
    metadata:
      labels:
        app: webserver
    spec:
      containers:
      - name: web
        image: nginx:1.25
        ports:
        - containerPort: 80
---
apiVersion: v1
kind: Service
metadata:
  name: mismatch-svc
  namespace: cka-q27
spec:
  selector:
    app: webserver
  ports:
  - port: 80
    targetPort: 9999
EOF
  echo "Service 'mismatch-svc' with wrong targetPort (9999) in cka-q27."
}
show_q27() { cat <<'EOF'
  TASK — Fix Service with Wrong TargetPort
  ──────────────────────────────────────────────────────────────
  Service 'mismatch-svc' in namespace 'cka-q27' has the wrong
  targetPort. Pods serve on port 80 but service targets 9999.

  Fix the targetPort to 80.

    kubectl describe svc mismatch-svc -n cka-q27
    kubectl get endpoints mismatch-svc -n cka-q27

  ── 한국어 ─────────────────────────────────────────────
  cka-q27 의 Service 'mismatch-svc' 의 targetPort 가 9999 로 잘못 설정되어
  있습니다. 파드는 80 포트를 사용합니다. targetPort 를 80 으로 수정하세요.
EOF
}
validate_q27() {
  local tp; tp=$(kubectl get svc mismatch-svc -n cka-q27 -o jsonpath='{.spec.ports[0].targetPort}')
  [[ "$tp" != "80" ]] && { echo -e "  ${RED}✗ targetPort=$tp (want 80)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ TargetPort fixed to 80.${NC}"
}
hint_q27() { cat <<'EOF'
  kubectl patch svc mismatch-svc -n cka-q27 \
    -p '{"spec":{"ports":[{"port":80,"targetPort":80}]}}'
  # OR: kubectl edit svc mismatch-svc -n cka-q27
EOF
}

# ─── Q28 ─────────────────────────────────────────────────────────────────────
setup_q28() {
  _ns cka-q28
  kubectl create namespace monitoring --dry-run=client -o yaml | kubectl apply -f - 2>/dev/null
  kubectl label namespace monitoring team=monitoring --overwrite 2>/dev/null
  kubectl delete networkpolicy allow-monitoring -n cka-q28 2>/dev/null
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: v1
kind: Pod
metadata:
  name: app-pod
  namespace: cka-q28
  labels:
    app: myapp
spec:
  containers:
  - name: app
    image: nginx:1.25
    ports:
    - containerPort: 80
EOF
  echo "Pod 'app-pod' in cka-q28. Namespace 'monitoring' labeled team=monitoring."
}
show_q28() { cat <<'EOF'
  TASK — NetworkPolicy: Allow Ingress from Labeled Namespace
  ──────────────────────────────────────────────────────────────
  Pod 'app-pod' (label: app=myapp) runs in namespace 'cka-q28'.
  Namespace 'monitoring' has label: team=monitoring

  Create NetworkPolicy 'allow-monitoring' in namespace 'cka-q28':
    - Applies to pods with: app=myapp
    - Allows Ingress from namespace with label: team=monitoring
    - On port 80

  ── 한국어 ─────────────────────────────────────────────
  cka-q28 에 NetworkPolicy 'allow-monitoring' 을 생성하세요.
    적용 대상: app=myapp 파드
    허용: team=monitoring 레이블이 있는 네임스페이스에서 포트 80 인바운드
EOF
}
validate_q28() {
  kubectl get netpol allow-monitoring -n cka-q28 &>/dev/null || { echo -e "  ${RED}✗ NetworkPolicy not found${NC}"; return 1; }
  local ns_sel; ns_sel=$(kubectl get netpol allow-monitoring -n cka-q28 \
    -o jsonpath='{.spec.ingress[0].from[0].namespaceSelector.matchLabels.team}')
  [[ "$ns_sel" != "monitoring" ]] && { echo -e "  ${RED}✗ namespaceSelector.team=$ns_sel (want monitoring)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ NetworkPolicy allows ingress from namespace team=monitoring.${NC}"
}
hint_q28() { cat <<'EOF'
  spec:
    podSelector:
      matchLabels:
        app: myapp
    policyTypes:
    - Ingress
    ingress:
    - from:
      - namespaceSelector:
          matchLabels:
            team: monitoring
      ports:
      - port: 80
EOF
}

# ─── Q29 ─────────────────────────────────────────────────────────────────────
setup_q29() {
  _ns cka-q29; kubectl delete svc multi-port-svc -n cka-q29 2>/dev/null
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: apps/v1
kind: Deployment
metadata:
  name: multi-app
  namespace: cka-q29
spec:
  replicas: 1
  selector:
    matchLabels:
      app: multi-app
  template:
    metadata:
      labels:
        app: multi-app
    spec:
      containers:
      - name: app
        image: nginx:1.25
        ports:
        - containerPort: 80
        - containerPort: 443
EOF
  echo "Deployment 'multi-app' ready in cka-q29."
}
show_q29() { cat <<'EOF'
  TASK — Create a Multi-Port Service
  ──────────────────────────────────────────────────────────────
  Deployment 'multi-app' in namespace 'cka-q29' exposes ports 80 and 443.

  Create a ClusterIP Service 'multi-port-svc' with:
    Namespace: cka-q29
    Port 1:  name=http,  port=80,  targetPort=80
    Port 2:  name=https, port=443, targetPort=443
    Selector: app=multi-app

  ── 한국어 ─────────────────────────────────────────────
  cka-q29 에 멀티포트 ClusterIP Service 'multi-port-svc' 를 생성하세요.
    포트1: http (80→80) / 포트2: https (443→443) / 셀렉터: app=multi-app
EOF
}
validate_q29() {
  kubectl get svc multi-port-svc -n cka-q29 &>/dev/null || { echo -e "  ${RED}✗ Service not found${NC}"; return 1; }
  local ports; ports=$(kubectl get svc multi-port-svc -n cka-q29 -o jsonpath='{.spec.ports[*].port}')
  [[ "$ports" != *"80"*  ]] && { echo -e "  ${RED}✗ port 80 not found${NC}"; return 1; }
  [[ "$ports" != *"443"* ]] && { echo -e "  ${RED}✗ port 443 not found${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Multi-port service with ports 80 and 443 created.${NC}"
}
hint_q29() { cat <<'EOF'
  apiVersion: v1
  kind: Service
  metadata:
    name: multi-port-svc
    namespace: cka-q29
  spec:
    selector:
      app: multi-app
    ports:
    - name: http
      port: 80
      targetPort: 80
    - name: https
      port: 443
      targetPort: 443
EOF
}

# ─── Q30 ─────────────────────────────────────────────────────────────────────
setup_q30() {
  _ns cka-q30; kubectl delete svc quick-svc -n cka-q30 2>/dev/null
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: apps/v1
kind: Deployment
metadata:
  name: quick-expose
  namespace: cka-q30
spec:
  replicas: 2
  selector:
    matchLabels:
      app: quick-expose
  template:
    metadata:
      labels:
        app: quick-expose
    spec:
      containers:
      - name: web
        image: nginx:1.25
        ports:
        - containerPort: 80
EOF
  echo "Deployment 'quick-expose' ready in cka-q30."
}
show_q30() { cat <<'EOF'
  TASK — Expose Deployment as ClusterIP (named 'quick-svc')
  ──────────────────────────────────────────────────────────────
  Expose deployment 'quick-expose' in namespace 'cka-q30':
    Service Name: quick-svc
    Port: 80 → TargetPort: 80
    Type: ClusterIP

  Verify endpoints exist:
    kubectl get endpoints quick-svc -n cka-q30

  ── 한국어 ─────────────────────────────────────────────
  cka-q30 의 Deployment 'quick-expose' 를 ClusterIP Service 'quick-svc' 로 노출하세요.
    포트: 80 / 엔드포인트가 생성되었는지 확인하세요.
EOF
}
validate_q30() {
  kubectl get svc quick-svc -n cka-q30 &>/dev/null || { echo -e "  ${RED}✗ Service 'quick-svc' not found${NC}"; return 1; }
  local sel; sel=$(kubectl get svc quick-svc -n cka-q30 -o jsonpath='{.spec.selector.app}')
  [[ "$sel" != "quick-expose" ]] && { echo -e "  ${RED}✗ selector.app=$sel (want quick-expose)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Service 'quick-svc' exposes deployment 'quick-expose'.${NC}"
}
hint_q30() { cat <<'EOF'
  kubectl expose deployment quick-expose --name=quick-svc \
    --port=80 --target-port=80 -n cka-q30
EOF
}

# ─── Q31 ─────────────────────────────────────────────────────────────────────
setup_q31() {
  _ns cka-q31; kubectl delete svc sticky-svc -n cka-q31 2>/dev/null
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: apps/v1
kind: Deployment
metadata:
  name: sticky-app
  namespace: cka-q31
spec:
  replicas: 3
  selector:
    matchLabels:
      app: sticky-app
  template:
    metadata:
      labels:
        app: sticky-app
    spec:
      containers:
      - name: web
        image: nginx:1.25
        ports:
        - containerPort: 80
EOF
  echo "Deployment 'sticky-app' ready in cka-q31."
}
show_q31() { cat <<'EOF'
  TASK — Service with SessionAffinity=ClientIP
  ──────────────────────────────────────────────────────────────
  Deployment 'sticky-app' in namespace 'cka-q31'.

  Create a ClusterIP Service 'sticky-svc':
    Port: 80, Selector: app=sticky-app
    sessionAffinity: ClientIP
    (This ensures the same client always routes to the same pod)

  ── 한국어 ─────────────────────────────────────────────
  cka-q31 에 ClusterIP Service 'sticky-svc' 를 생성하세요.
    sessionAffinity: ClientIP (같은 클라이언트는 항상 같은 파드로 라우팅)
    포트: 80 / 셀렉터: app=sticky-app
EOF
}
validate_q31() {
  kubectl get svc sticky-svc -n cka-q31 &>/dev/null || { echo -e "  ${RED}✗ Service not found${NC}"; return 1; }
  local sa; sa=$(kubectl get svc sticky-svc -n cka-q31 -o jsonpath='{.spec.sessionAffinity}')
  [[ "$sa" != "ClientIP" ]] && { echo -e "  ${RED}✗ sessionAffinity=$sa (want ClientIP)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Service has sessionAffinity=ClientIP.${NC}"
}
hint_q31() { cat <<'EOF'
  kubectl expose deployment sticky-app --name=sticky-svc \
    --port=80 -n cka-q31
  kubectl patch svc sticky-svc -n cka-q31 \
    -p '{"spec":{"sessionAffinity":"ClientIP"}}'
EOF
}

# ─── Q32 ─────────────────────────────────────────────────────────────────────
setup_q32() { _ns cka-q32; kubectl delete networkpolicy deny-all-egress -n cka-q32 2>/dev/null; echo "Namespace cka-q32 ready."; }
show_q32() { cat <<'EOF'
  TASK — NetworkPolicy: Deny All Egress
  ──────────────────────────────────────────────────────────────
  Create NetworkPolicy 'deny-all-egress' in namespace 'cka-q32':
    - Applies to ALL pods (empty podSelector)
    - Blocks ALL outgoing (egress) traffic
    - policyTypes: [Egress]
    - No egress rules (empty list)

  ── 한국어 ─────────────────────────────────────────────
  cka-q32 의 모든 파드에서 나가는 트래픽을 전부 차단하는
  NetworkPolicy 'deny-all-egress' 를 생성하세요.
    podSelector: {} / policyTypes: [Egress] / egress 규칙: 없음
EOF
}
validate_q32() {
  kubectl get netpol deny-all-egress -n cka-q32 &>/dev/null || { echo -e "  ${RED}✗ NetworkPolicy not found${NC}"; return 1; }
  local pt; pt=$(kubectl get netpol deny-all-egress -n cka-q32 -o jsonpath='{.spec.policyTypes[0]}')
  [[ "$pt" != "Egress" ]] && { echo -e "  ${RED}✗ policyTypes[0]=$pt (want Egress)${NC}"; return 1; }
  local eg; eg=$(kubectl get netpol deny-all-egress -n cka-q32 -o jsonpath='{.spec.egress}')
  [[ -n "$eg" && "$eg" != "[]" ]] && { echo -e "  ${RED}✗ egress rules exist (should be empty to deny all)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ NetworkPolicy denies all egress from all pods.${NC}"
}
hint_q32() { cat <<'EOF'
  apiVersion: networking.k8s.io/v1
  kind: NetworkPolicy
  metadata:
    name: deny-all-egress
    namespace: cka-q32
  spec:
    podSelector: {}
    policyTypes:
    - Egress
EOF
}

# ─── Q33 ─────────────────────────────────────────────────────────────────────
setup_q33() { _ns cka-q33; kubectl delete svc external-db -n cka-q33 2>/dev/null; echo "Namespace cka-q33 ready."; }
show_q33() { cat <<'EOF'
  TASK — Create an ExternalName Service
  ──────────────────────────────────────────────────────────────
  Create an ExternalName Service in namespace 'cka-q33':
    Name:         external-db
    Type:         ExternalName
    externalName: db.example.com
    Port:         5432

  ExternalName services create a DNS CNAME alias for an external hostname.

  ── 한국어 ─────────────────────────────────────────────
  cka-q33 에 ExternalName Service 'external-db' 를 생성하세요.
    externalName: db.example.com / 포트: 5432
  ExternalName 서비스는 외부 호스트명에 대한 DNS CNAME 별칭을 만듭니다.
EOF
}
validate_q33() {
  kubectl get svc external-db -n cka-q33 &>/dev/null || { echo -e "  ${RED}✗ Service 'external-db' not found${NC}"; return 1; }
  local t en
  t=$(kubectl get svc external-db -n cka-q33 -o jsonpath='{.spec.type}')
  en=$(kubectl get svc external-db -n cka-q33 -o jsonpath='{.spec.externalName}')
  local ok=true
  [[ "$t" != "ExternalName"   ]] && { echo -e "  ${RED}✗ type=$t (want ExternalName)${NC}"; ok=false; }
  [[ "$en" != "db.example.com" ]] && { echo -e "  ${RED}✗ externalName=$en (want db.example.com)${NC}"; ok=false; }
  [[ "$ok" == "true" ]] && echo -e "  ${GREEN}✓ ExternalName service pointing to db.example.com.${NC}"
  [[ "$ok" == "true" ]]
}
hint_q33() { cat <<'EOF'
  apiVersion: v1
  kind: Service
  metadata:
    name: external-db
    namespace: cka-q33
  spec:
    type: ExternalName
    externalName: db.example.com
    ports:
    - port: 5432
EOF
}

# ─── Q34 ─────────────────────────────────────────────────────────────────────
setup_q34() {
  _ns cka-q34; kubectl delete networkpolicy allow-from-frontend -n cka-q34 2>/dev/null
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: v1
kind: Pod
metadata:
  name: api-server
  namespace: cka-q34
  labels:
    role: api
spec:
  containers:
  - name: api
    image: nginx:1.25
    ports:
    - containerPort: 8080
EOF
  echo "Pod 'api-server' (role=api) in cka-q34."
}
show_q34() { cat <<'EOF'
  TASK — NetworkPolicy: Allow from Specific Pod + Port
  ──────────────────────────────────────────────────────────────
  Pod 'api-server' (label: role=api) runs in namespace 'cka-q34'.

  Create NetworkPolicy 'allow-from-frontend':
    - Applies to pods with: role=api
    - Allows Ingress ONLY from pods with label: role=frontend
    - On port 8080

  ── 한국어 ─────────────────────────────────────────────
  cka-q34 에 NetworkPolicy 'allow-from-frontend' 를 생성하세요.
    적용 대상: role=api 파드
    허용: role=frontend 파드에서 포트 8080 인바운드만 허용
EOF
}
validate_q34() {
  kubectl get netpol allow-from-frontend -n cka-q34 &>/dev/null || { echo -e "  ${RED}✗ NetworkPolicy not found${NC}"; return 1; }
  local ps from port
  ps=$(kubectl get netpol allow-from-frontend -n cka-q34 -o jsonpath='{.spec.podSelector.matchLabels.role}')
  from=$(kubectl get netpol allow-from-frontend -n cka-q34 -o jsonpath='{.spec.ingress[0].from[0].podSelector.matchLabels.role}')
  port=$(kubectl get netpol allow-from-frontend -n cka-q34 -o jsonpath='{.spec.ingress[0].ports[0].port}')
  local ok=true
  [[ "$ps" != "api"      ]] && { echo -e "  ${RED}✗ podSelector.role=$ps (want api)${NC}"; ok=false; }
  [[ "$from" != "frontend" ]] && { echo -e "  ${RED}✗ from.role=$from (want frontend)${NC}"; ok=false; }
  [[ "$port" != "8080"   ]] && { echo -e "  ${RED}✗ port=$port (want 8080)${NC}"; ok=false; }
  [[ "$ok" == "true" ]] && echo -e "  ${GREEN}✓ NetworkPolicy allows role=frontend → role=api on port 8080.${NC}"
  [[ "$ok" == "true" ]]
}
hint_q34() { cat <<'EOF'
  spec:
    podSelector:
      matchLabels:
        role: api
    policyTypes:
    - Ingress
    ingress:
    - from:
      - podSelector:
          matchLabels:
            role: frontend
      ports:
      - port: 8080
EOF
}

# ─── Q35 ─────────────────────────────────────────────────────────────────────
setup_q35() {
  _ns cka-q35
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: v1
kind: Service
metadata:
  name: wrong-port-svc
  namespace: cka-q35
spec:
  selector:
    app: myapp
  ports:
  - port: 9090
    targetPort: 80
EOF
  echo "Service 'wrong-port-svc' with port 9090 (should be 80) in cka-q35."
}
show_q35() { cat <<'EOF'
  TASK — Fix Service with Wrong Port
  ──────────────────────────────────────────────────────────────
  Service 'wrong-port-svc' in namespace 'cka-q35' exposes port 9090
  but should expose port 80.

  Fix the service port from 9090 to 80.

    kubectl describe svc wrong-port-svc -n cka-q35

  ── 한국어 ─────────────────────────────────────────────
  cka-q35 의 Service 'wrong-port-svc' 가 포트 9090 을 노출하고 있습니다.
  포트를 80 으로 수정하세요.
EOF
}
validate_q35() {
  local p; p=$(kubectl get svc wrong-port-svc -n cka-q35 -o jsonpath='{.spec.ports[0].port}')
  [[ "$p" != "80" ]] && { echo -e "  ${RED}✗ port=$p (want 80)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Service port fixed to 80.${NC}"
}
hint_q35() { cat <<'EOF'
  kubectl patch svc wrong-port-svc -n cka-q35 \
    -p '{"spec":{"ports":[{"port":80,"targetPort":80}]}}'
EOF
}

# ─── Q36 ─────────────────────────────────────────────────────────────────────
setup_q36() {
  _ns cka-q36; kubectl delete svc app-nodeport -n cka-q36 2>/dev/null
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: apps/v1
kind: Deployment
metadata:
  name: app36
  namespace: cka-q36
spec:
  replicas: 1
  selector:
    matchLabels:
      app: app36
  template:
    metadata:
      labels:
        app: app36
    spec:
      containers:
      - name: web
        image: nginx:1.25
        ports:
        - containerPort: 80
EOF
  echo "Deployment 'app36' ready in cka-q36."
}
show_q36() { cat <<'EOF'
  TASK — NodePort Service on Port 30095
  ──────────────────────────────────────────────────────────────
  Deployment 'app36' exists in namespace 'cka-q36'.

  Create a NodePort Service 'app-nodeport':
    Namespace:  cka-q36
    Port:       80
    TargetPort: 80
    NodePort:   30095
    Selector:   app=app36

  ── 한국어 ─────────────────────────────────────────────
  cka-q36 에 NodePort Service 'app-nodeport' 를 생성하세요.
    포트: 80 / NodePort: 30095 / 셀렉터: app=app36
EOF
}
validate_q36() {
  kubectl get svc app-nodeport -n cka-q36 &>/dev/null || { echo -e "  ${RED}✗ Service not found${NC}"; return 1; }
  local np; np=$(kubectl get svc app-nodeport -n cka-q36 -o jsonpath='{.spec.ports[0].nodePort}')
  [[ "$np" != "30095" ]] && { echo -e "  ${RED}✗ nodePort=$np (want 30095)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ NodePort service on port 30095.${NC}"
}
hint_q36() { cat <<'EOF'
  kubectl expose deployment app36 --name=app-nodeport \
    --port=80 --type=NodePort -n cka-q36
  kubectl patch svc app-nodeport -n cka-q36 \
    -p '{"spec":{"ports":[{"port":80,"targetPort":80,"nodePort":30095}]}}'
EOF
}

# ─── Q37 ─────────────────────────────────────────────────────────────────────
setup_q37() { _ns cka-q37; kubectl delete networkpolicy allow-https-egress -n cka-q37 2>/dev/null; echo "Namespace cka-q37 ready."; }
show_q37() { cat <<'EOF'
  TASK — NetworkPolicy: Allow Egress to Port 443 Only
  ──────────────────────────────────────────────────────────────
  Create NetworkPolicy 'allow-https-egress' in namespace 'cka-q37':
    - Applies to ALL pods
    - policyTypes: [Egress]
    - Allows Egress ONLY to port 443 (HTTPS)
    - Denies all other egress

  ── 한국어 ─────────────────────────────────────────────
  cka-q37 에 NetworkPolicy 'allow-https-egress' 를 생성하세요.
    모든 파드에 적용 / 포트 443(HTTPS) 아웃바운드만 허용, 나머지 차단
EOF
}
validate_q37() {
  kubectl get netpol allow-https-egress -n cka-q37 &>/dev/null || { echo -e "  ${RED}✗ NetworkPolicy not found${NC}"; return 1; }
  local pt port
  pt=$(kubectl get netpol allow-https-egress -n cka-q37 -o jsonpath='{.spec.policyTypes[0]}')
  port=$(kubectl get netpol allow-https-egress -n cka-q37 -o jsonpath='{.spec.egress[0].ports[0].port}')
  [[ "$pt" != "Egress" ]]  && { echo -e "  ${RED}✗ policyTypes[0]=$pt (want Egress)${NC}"; return 1; }
  [[ "$port" != "443"  ]]  && { echo -e "  ${RED}✗ egress port=$port (want 443)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ NetworkPolicy allows egress only to port 443.${NC}"
}
hint_q37() { cat <<'EOF'
  spec:
    podSelector: {}
    policyTypes:
    - Egress
    egress:
    - ports:
      - protocol: TCP
        port: 443
EOF
}

# ─── Q38 ─────────────────────────────────────────────────────────────────────
setup_q38() { _ns cka-q38; kubectl delete networkpolicy allow-from-cidr -n cka-q38 2>/dev/null; echo "Namespace cka-q38 ready."; }
show_q38() { cat <<'EOF'
  TASK — NetworkPolicy: Allow Ingress from CIDR
  ──────────────────────────────────────────────────────────────
  Create NetworkPolicy 'allow-from-cidr' in namespace 'cka-q38':
    - Applies to ALL pods
    - Allows Ingress from CIDR block: 10.0.0.0/8
    - On port 80

  ── 한국어 ─────────────────────────────────────────────
  cka-q38 에 NetworkPolicy 'allow-from-cidr' 를 생성하세요.
    모든 파드에 적용 / CIDR 10.0.0.0/8 에서 포트 80 인바운드 허용
EOF
}
validate_q38() {
  kubectl get netpol allow-from-cidr -n cka-q38 &>/dev/null || { echo -e "  ${RED}✗ NetworkPolicy not found${NC}"; return 1; }
  local cidr; cidr=$(kubectl get netpol allow-from-cidr -n cka-q38 \
    -o jsonpath='{.spec.ingress[0].from[0].ipBlock.cidr}')
  [[ "$cidr" != "10.0.0.0/8" ]] && { echo -e "  ${RED}✗ cidr=$cidr (want 10.0.0.0/8)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ NetworkPolicy allows ingress from CIDR 10.0.0.0/8 on port 80.${NC}"
}
hint_q38() { cat <<'EOF'
  spec:
    podSelector: {}
    policyTypes:
    - Ingress
    ingress:
    - from:
      - ipBlock:
          cidr: 10.0.0.0/8
      ports:
      - port: 80
EOF
}

# ─── Q39 ─────────────────────────────────────────────────────────────────────
setup_q39() {
  _ns cka-q39; kubectl delete svc named-port-svc -n cka-q39 2>/dev/null
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: apps/v1
kind: Deployment
metadata:
  name: webapp39
  namespace: cka-q39
spec:
  replicas: 1
  selector:
    matchLabels:
      app: webapp39
  template:
    metadata:
      labels:
        app: webapp39
    spec:
      containers:
      - name: web
        image: nginx:1.25
        ports:
        - name: http
          containerPort: 80
EOF
  echo "Deployment 'webapp39' with named port 'http' ready in cka-q39."
}
show_q39() { cat <<'EOF'
  TASK — Service with Named Port
  ──────────────────────────────────────────────────────────────
  Deployment 'webapp39' in namespace 'cka-q39' exposes a named port:
    name: http, containerPort: 80

  Create ClusterIP Service 'named-port-svc':
    Namespace:  cka-q39
    ports:
      - name: http
        port: 80
        targetPort: http     ← reference by name, not number
    Selector: app=webapp39

  ── 한국어 ─────────────────────────────────────────────
  cka-q39 에 ClusterIP Service 'named-port-svc' 를 생성하세요.
    포트 이름: http / 포트: 80 / targetPort: http (숫자 대신 이름으로 참조)
    셀렉터: app=webapp39
EOF
}
validate_q39() {
  kubectl get svc named-port-svc -n cka-q39 &>/dev/null || { echo -e "  ${RED}✗ Service not found${NC}"; return 1; }
  local pname; pname=$(kubectl get svc named-port-svc -n cka-q39 -o jsonpath='{.spec.ports[0].name}')
  [[ "$pname" != "http" ]] && { echo -e "  ${RED}✗ port name=$pname (want http)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Service uses named port 'http'.${NC}"
}
hint_q39() { cat <<'EOF'
  apiVersion: v1
  kind: Service
  metadata:
    name: named-port-svc
    namespace: cka-q39
  spec:
    selector:
      app: webapp39
    ports:
    - name: http
      port: 80
      targetPort: http
EOF
}

# ─── Q40 ─────────────────────────────────────────────────────────────────────
setup_q40() {
  _ns cka-q40
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: apps/v1
kind: Deployment
metadata:
  name: combo-app
  namespace: cka-q40
spec:
  replicas: 2
  selector:
    matchLabels:
      app: combo-app
  template:
    metadata:
      labels:
        app: combo-app
    spec:
      containers:
      - name: web
        image: nginx:1.25
        ports:
        - containerPort: 80
---
apiVersion: v1
kind: Service
metadata:
  name: combo-svc
  namespace: cka-q40
spec:
  selector:
    app: wrong-app
  ports:
  - port: 9999
    targetPort: 8080
EOF
  echo "Service 'combo-svc' with BOTH wrong selector AND wrong ports in cka-q40."
}
show_q40() { cat <<'EOF'
  TASK — Fix Service with Wrong Selector AND Port
  ──────────────────────────────────────────────────────────────
  Service 'combo-svc' in namespace 'cka-q40' has TWO problems:
    1. Selector is  app=wrong-app  (should be app=combo-app)
    2. Port is 9999 → targetPort 8080  (should be port=80, targetPort=80)

  Fix both issues. Verify endpoints are populated.

    kubectl describe svc combo-svc -n cka-q40
    kubectl get pods -n cka-q40 --show-labels

  ── 한국어 ─────────────────────────────────────────────
  cka-q40 의 Service 'combo-svc' 에 두 가지 문제가 있습니다:
    1. 셀렉터: app=wrong-app → app=combo-app 으로 수정
    2. 포트: 9999→8080 → 80→80 으로 수정
  두 가지 모두 수정 후 엔드포인트가 생성되는지 확인하세요.
EOF
}
validate_q40() {
  local sel p tp
  sel=$(kubectl get svc combo-svc -n cka-q40 -o jsonpath='{.spec.selector.app}')
  p=$(kubectl get svc combo-svc -n cka-q40 -o jsonpath='{.spec.ports[0].port}')
  tp=$(kubectl get svc combo-svc -n cka-q40 -o jsonpath='{.spec.ports[0].targetPort}')
  local ok=true
  [[ "$sel" != "combo-app" ]] && { echo -e "  ${RED}✗ selector.app=$sel (want combo-app)${NC}"; ok=false; }
  [[ "$p" != "80"          ]] && { echo -e "  ${RED}✗ port=$p (want 80)${NC}"; ok=false; }
  [[ "$tp" != "80"         ]] && { echo -e "  ${RED}✗ targetPort=$tp (want 80)${NC}"; ok=false; }
  [[ "$ok" == "true" ]] && echo -e "  ${GREEN}✓ Both selector and port fixed. Service now routes to combo-app pods.${NC}"
  [[ "$ok" == "true" ]]
}
hint_q40() { cat <<'EOF'
  kubectl patch svc combo-svc -n cka-q40 -p \
    '{"spec":{"selector":{"app":"combo-app"},"ports":[{"port":80,"targetPort":80}]}}'
EOF
}
