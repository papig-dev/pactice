#!/usr/bin/env bash
# Batch 7: Ingress, Gateway API, Helm & Kustomize (Q121–Q140) — sourced by run.sh

BATCH_TITLE="Batch 7 — Ingress, Gateway API, Helm & Kustomize (Q121–Q140)"
Q_TITLES=(""
  "Create Ingress (host-based routing)"
  "Create Ingress (path-based routing)"
  "Fix Ingress: Wrong Backend Service"
  "Ingress with TLS Secret"
  "Ingress: Multiple Hosts"
  "Gateway API: Create Gateway + HTTPRoute"
  "Gateway API: HTTPRoute Path Matching"
  "Gateway API: HTTPRoute Header Matching"
  "Helm: Install a Chart"
  "Helm: Upgrade a Release"
  "Helm: Rollback a Release"
  "Helm: Install with Custom Values"
  "Helm: List + Uninstall"
  "Kustomize: Apply base"
  "Kustomize: Overlay with namePrefix"
  "Kustomize: Overlay with replicas patch"
  "Kustomize: ConfigMap Generator"
  "NetworkPolicy: Allow Ingress from Namespace"
  "NetworkPolicy: Deny All + Allow Specific Port"
  "NetworkPolicy: Egress to External CIDR"
)

_ns() { kubectl create namespace "$1" --dry-run=client -o yaml | kubectl apply -f - 2>/dev/null; }

_ensure_kustomize_base() {
  [[ -d /tmp/kustomize-base ]] && return
  mkdir -p /tmp/kustomize-base
  cat > /tmp/kustomize-base/deployment.yaml <<'YAML'
apiVersion: apps/v1
kind: Deployment
metadata:
  name: myapp
spec:
  replicas: 1
  selector:
    matchLabels:
      app: myapp
  template:
    metadata:
      labels:
        app: myapp
    spec:
      containers:
      - name: app
        image: nginx:1.27
YAML
  cat > /tmp/kustomize-base/kustomization.yaml <<'YAML'
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization
resources:
- deployment.yaml
namespace: cka-kustomize
YAML
  _ns cka-kustomize
  echo "Created /tmp/kustomize-base (Q134 prerequisite)."
}

# ─── Q121 ─────────────────────────────────────────────────────────────────────
setup_q121() {
  _ns cka-q121
  kubectl delete ingress host-ingress -n cka-q121 2>/dev/null
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: apps/v1
kind: Deployment
metadata:
  name: web
  namespace: cka-q121
spec:
  replicas: 1
  selector:
    matchLabels:
      app: web
  template:
    metadata:
      labels:
        app: web
    spec:
      containers:
      - name: web
        image: nginx:1.27
        ports:
        - containerPort: 80
---
apiVersion: v1
kind: Service
metadata:
  name: web-svc
  namespace: cka-q121
spec:
  selector:
    app: web
  ports:
  - port: 80
    targetPort: 80
EOF
  echo "Deployment + Service 'web-svc' ready in cka-q121."
}
show_q121() { cat <<'EOF'
  TASK — Create Ingress (host-based routing)
  ──────────────────────────────────────────────────────────────
  Service 'web-svc' exists in namespace 'cka-q121' on port 80.

  Create Ingress 'host-ingress' in namespace 'cka-q121':
    ingressClassName: nginx
    rules:
    - host: web.example.com
      http:
        paths:
        - path: /
          pathType: Prefix
          backend:
            service:
              name: web-svc
              port:
                number: 80

  ── 한국어 ─────────────────────────────────────────────
  'cka-q121' 에 Ingress 'host-ingress' 를 생성하세요:
    ingressClassName: nginx
    host: web.example.com → web-svc:80 (path: /, pathType: Prefix)
EOF
}
validate_q121() {
  kubectl get ingress host-ingress -n cka-q121 &>/dev/null || { echo -e "  ${RED}✗ Ingress 'host-ingress' not found${NC}"; return 1; }
  local host; host=$(kubectl get ingress host-ingress -n cka-q121 \
    -o jsonpath='{.spec.rules[0].host}')
  local svc; svc=$(kubectl get ingress host-ingress -n cka-q121 \
    -o jsonpath='{.spec.rules[0].http.paths[0].backend.service.name}')
  local ok=true
  [[ "$host" != "web.example.com" ]] && { echo -e "  ${RED}✗ host=$host (want web.example.com)${NC}"; ok=false; }
  [[ "$svc"  != "web-svc"         ]] && { echo -e "  ${RED}✗ backend.service.name=$svc (want web-svc)${NC}"; ok=false; }
  [[ "$ok" == "true" ]] && echo -e "  ${GREEN}✓ Ingress 'host-ingress' routes web.example.com → web-svc.${NC}"
  [[ "$ok" == "true" ]]
}
hint_q121() { cat <<'EOF'
  apiVersion: networking.k8s.io/v1
  kind: Ingress
  metadata:
    name: host-ingress
    namespace: cka-q121
  spec:
    ingressClassName: nginx
    rules:
    - host: web.example.com
      http:
        paths:
        - path: /
          pathType: Prefix
          backend:
            service:
              name: web-svc
              port:
                number: 80
EOF
}

# ─── Q122 ─────────────────────────────────────────────────────────────────────
setup_q122() {
  _ns cka-q122
  kubectl delete ingress path-ingress -n cka-q122 2>/dev/null
  for svc in api-svc web-svc; do
    cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: v1
kind: Service
metadata:
  name: $svc
  namespace: cka-q122
spec:
  selector:
    app: $svc
  ports:
  - port: 80
EOF
  done
  echo "Services 'api-svc' and 'web-svc' ready in cka-q122."
}
show_q122() { cat <<'EOF'
  TASK — Create Ingress (path-based routing)
  ──────────────────────────────────────────────────────────────
  Services 'web-svc' and 'api-svc' exist in namespace 'cka-q122'.

  Create Ingress 'path-ingress' in namespace 'cka-q122':
    host: app.example.com
    paths:
      /     → web-svc:80  (pathType: Prefix)
      /api  → api-svc:80  (pathType: Prefix)

  ── 한국어 ─────────────────────────────────────────────
  'cka-q122' 에 Ingress 'path-ingress' 를 생성하세요:
    host: app.example.com
    / → web-svc:80, /api → api-svc:80 (경로 기반 라우팅)
EOF
}
validate_q122() {
  kubectl get ingress path-ingress -n cka-q122 &>/dev/null || { echo -e "  ${RED}✗ Ingress not found${NC}"; return 1; }
  local paths; paths=$(kubectl get ingress path-ingress -n cka-q122 \
    -o jsonpath='{.spec.rules[0].http.paths[*].path}')
  local svcs; svcs=$(kubectl get ingress path-ingress -n cka-q122 \
    -o jsonpath='{.spec.rules[0].http.paths[*].backend.service.name}')
  local ok=true
  [[ "$paths" != *"/"*    ]] && { echo -e "  ${RED}✗ Missing path /  ${NC}"; ok=false; }
  [[ "$paths" != *"/api"* ]] && { echo -e "  ${RED}✗ Missing path /api${NC}"; ok=false; }
  [[ "$svcs"  != *"web-svc"* ]] && { echo -e "  ${RED}✗ Missing web-svc backend${NC}"; ok=false; }
  [[ "$svcs"  != *"api-svc"* ]] && { echo -e "  ${RED}✗ Missing api-svc backend${NC}"; ok=false; }
  [[ "$ok" == "true" ]] && echo -e "  ${GREEN}✓ Ingress routes / → web-svc and /api → api-svc.${NC}"
  [[ "$ok" == "true" ]]
}
hint_q122() { cat <<'EOF'
  spec:
    rules:
    - host: app.example.com
      http:
        paths:
        - path: /
          pathType: Prefix
          backend:
            service:
              name: web-svc
              port:
                number: 80
        - path: /api
          pathType: Prefix
          backend:
            service:
              name: api-svc
              port:
                number: 80
EOF
}

# ─── Q123 ─────────────────────────────────────────────────────────────────────
setup_q123() {
  _ns cka-q123
  kubectl delete ingress broken-ingress -n cka-q123 2>/dev/null
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: v1
kind: Service
metadata:
  name: correct-svc
  namespace: cka-q123
spec:
  selector:
    app: correct
  ports:
  - port: 80
---
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: broken-ingress
  namespace: cka-q123
spec:
  rules:
  - host: fix.example.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: wrong-svc
            port:
              number: 80
EOF
  echo "Ingress 'broken-ingress' with wrong backend (wrong-svc) created in cka-q123."
}
show_q123() { cat <<'EOF'
  TASK — Fix Ingress: Wrong Backend Service
  ──────────────────────────────────────────────────────────────
  Ingress 'broken-ingress' in namespace 'cka-q123' routes to 'wrong-svc'
  which does NOT exist. The correct service is 'correct-svc'.

  Fix the ingress backend to point to 'correct-svc'.

    kubectl describe ingress broken-ingress -n cka-q123
    kubectl get services -n cka-q123

  ── 한국어 ─────────────────────────────────────────────
  'cka-q123' 의 Ingress 'broken-ingress' 가 존재하지 않는
  'wrong-svc' 를 백엔드로 가리킵니다.
  올바른 서비스 'correct-svc' 로 변경하세요.
EOF
}
validate_q123() {
  local svc; svc=$(kubectl get ingress broken-ingress -n cka-q123 \
    -o jsonpath='{.spec.rules[0].http.paths[0].backend.service.name}')
  [[ "$svc" != "correct-svc" ]] && { echo -e "  ${RED}✗ backend.service.name=$svc (want correct-svc)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Ingress backend fixed to correct-svc.${NC}"
}
hint_q123() { cat <<'EOF'
  kubectl patch ingress broken-ingress -n cka-q123 --type=json \
    -p='[{"op":"replace","path":"/spec/rules/0/http/paths/0/backend/service/name","value":"correct-svc"}]'
  # OR: kubectl edit ingress broken-ingress -n cka-q123
EOF
}

# ─── Q124 ─────────────────────────────────────────────────────────────────────
setup_q124() {
  _ns cka-q124
  kubectl delete ingress tls-ingress -n cka-q124 2>/dev/null
  kubectl delete secret tls-secret -n cka-q124 2>/dev/null
  kubectl create secret tls tls-secret \
    --cert=/dev/null --key=/dev/null -n cka-q124 2>/dev/null || \
  kubectl create secret generic tls-secret \
    --from-literal=tls.crt=fakecrt \
    --from-literal=tls.key=fakekey \
    -n cka-q124 2>/dev/null
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: v1
kind: Service
metadata:
  name: secure-svc
  namespace: cka-q124
spec:
  selector:
    app: secure
  ports:
  - port: 443
EOF
  echo "Secret 'tls-secret' and Service 'secure-svc' ready in cka-q124."
}
show_q124() { cat <<'EOF'
  TASK — Ingress with TLS
  ──────────────────────────────────────────────────────────────
  Secret 'tls-secret' and Service 'secure-svc:443' exist in namespace 'cka-q124'.

  Create Ingress 'tls-ingress':
    host: secure.example.com
    tls:
      hosts: [secure.example.com]
      secretName: tls-secret
    backend: secure-svc:443

  ── 한국어 ─────────────────────────────────────────────
  'cka-q124' 에 TLS 키 Ingress 'tls-ingress' 를 생성하세요:
    host: secure.example.com
    tls.secretName: tls-secret
    backend: secure-svc:443
EOF
}
validate_q124() {
  kubectl get ingress tls-ingress -n cka-q124 &>/dev/null || { echo -e "  ${RED}✗ Ingress 'tls-ingress' not found${NC}"; return 1; }
  local tlssecret; tlssecret=$(kubectl get ingress tls-ingress -n cka-q124 \
    -o jsonpath='{.spec.tls[0].secretName}')
  [[ "$tlssecret" != "tls-secret" ]] && { echo -e "  ${RED}✗ tls.secretName=$tlssecret (want tls-secret)${NC}"; return 1; }
  local host; host=$(kubectl get ingress tls-ingress -n cka-q124 \
    -o jsonpath='{.spec.tls[0].hosts[0]}')
  [[ "$host" != "secure.example.com" ]] && { echo -e "  ${RED}✗ tls.host=$host (want secure.example.com)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Ingress 'tls-ingress' has TLS configured correctly.${NC}"
}
hint_q124() { cat <<'EOF'
  spec:
    tls:
    - hosts:
      - secure.example.com
      secretName: tls-secret
    rules:
    - host: secure.example.com
      http:
        paths:
        - path: /
          pathType: Prefix
          backend:
            service:
              name: secure-svc
              port:
                number: 443
EOF
}

# ─── Q125 ─────────────────────────────────────────────────────────────────────
setup_q125() {
  _ns cka-q125
  kubectl delete ingress multi-host-ingress -n cka-q125 2>/dev/null
  for svc in site1-svc site2-svc; do
    cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: v1
kind: Service
metadata:
  name: $svc
  namespace: cka-q125
spec:
  selector:
    app: $svc
  ports:
  - port: 80
EOF
  done
  echo "Services 'site1-svc' and 'site2-svc' ready in cka-q125."
}
show_q125() { cat <<'EOF'
  TASK — Ingress: Multiple Hosts
  ──────────────────────────────────────────────────────────────
  Services 'site1-svc' and 'site2-svc' exist in namespace 'cka-q125'.

  Create Ingress 'multi-host-ingress':
    Rule 1: host=site1.example.com → site1-svc:80
    Rule 2: host=site2.example.com → site2-svc:80

  ── 한국어 ─────────────────────────────────────────────
  'cka-q125' 에 다중 호스트 Ingress 'multi-host-ingress' 를 생성하세요:
    site1.example.com → site1-svc:80
    site2.example.com → site2-svc:80
EOF
}
validate_q125() {
  kubectl get ingress multi-host-ingress -n cka-q125 &>/dev/null || { echo -e "  ${RED}✗ Ingress not found${NC}"; return 1; }
  local hosts; hosts=$(kubectl get ingress multi-host-ingress -n cka-q125 \
    -o jsonpath='{.spec.rules[*].host}')
  local ok=true
  [[ "$hosts" != *"site1.example.com"* ]] && { echo -e "  ${RED}✗ Missing host site1.example.com${NC}"; ok=false; }
  [[ "$hosts" != *"site2.example.com"* ]] && { echo -e "  ${RED}✗ Missing host site2.example.com${NC}"; ok=false; }
  [[ "$ok" == "true" ]] && echo -e "  ${GREEN}✓ Ingress routes site1 and site2.${NC}"
  [[ "$ok" == "true" ]]
}
hint_q125() { cat <<'EOF'
  spec:
    rules:
    - host: site1.example.com
      http:
        paths:
        - path: /
          pathType: Prefix
          backend:
            service:
              name: site1-svc
              port:
                number: 80
    - host: site2.example.com
      http:
        paths:
        - path: /
          pathType: Prefix
          backend:
            service:
              name: site2-svc
              port:
                number: 80
EOF
}

# ─── Q126 ─────────────────────────────────────────────────────────────────────
setup_q126() {
  _ns cka-q126
  kubectl delete gateway my-gateway -n cka-q126 2>/dev/null
  kubectl delete httproute my-route -n cka-q126 2>/dev/null
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: v1
kind: Service
metadata:
  name: backend-svc
  namespace: cka-q126
spec:
  selector:
    app: backend
  ports:
  - port: 80
EOF
  echo "Service 'backend-svc' ready in cka-q126."
}
show_q126() { cat <<'EOF'
  TASK — Gateway API: Create Gateway + HTTPRoute
  ──────────────────────────────────────────────────────────────
  Service 'backend-svc' exists in namespace 'cka-q126'.

  Step 1: Create Gateway 'my-gateway':
    namespace:     cka-q126
    gatewayClassName: nginx (or standard)
    listeners:
    - name: http
      port: 80
      protocol: HTTP

  Step 2: Create HTTPRoute 'my-route':
    namespace:     cka-q126
    parentRefs:    my-gateway
    hostnames:     ["gateway.example.com"]
    rules:
    - backendRefs:
      - name: backend-svc
        port: 80

  NOTE: Gateway CRDs may not be installed. Write the YAML to
  /tmp/gateway-setup.yaml instead if Gateway API is unavailable.

  ── 한국어 ─────────────────────────────────────────────
  'cka-q126' 에 Gateway API 리소스를 생성하세요:
    Gateway 'my-gateway': listener HTTP:80
    HTTPRoute 'my-route': hostname gateway.example.com → backend-svc:80
  CRD 미설치 시 /tmp/gateway-setup.yaml 에 YAML 작성
EOF
}
validate_q126() {
  if kubectl get gateway my-gateway -n cka-q126 &>/dev/null; then
    local gw; gw=$(kubectl get gateway my-gateway -n cka-q126 \
      -o jsonpath='{.spec.listeners[0].port}')
    [[ "$gw" != "80" ]] && { echo -e "  ${RED}✗ Gateway listener port=$gw (want 80)${NC}"; return 1; }
    echo -e "  ${GREEN}✓ Gateway 'my-gateway' with HTTP:80 listener.${NC}"
    return 0
  fi
  if [[ -f /tmp/gateway-setup.yaml ]]; then
    local content; content=$(cat /tmp/gateway-setup.yaml)
    local ok=true
    [[ "$content" != *"kind: Gateway"* ]]   && { echo -e "  ${RED}✗ Gateway resource missing in YAML${NC}"; ok=false; }
    [[ "$content" != *"kind: HTTPRoute"* ]] && { echo -e "  ${RED}✗ HTTPRoute resource missing in YAML${NC}"; ok=false; }
    [[ "$content" != *"backend-svc"* ]]     && { echo -e "  ${RED}✗ backend-svc not referenced${NC}"; ok=false; }
    [[ "$ok" == "true" ]] && echo -e "  ${GREEN}✓ Gateway + HTTPRoute YAML written correctly.${NC}"
    [[ "$ok" == "true" ]]; return
  fi
  echo -e "  ${RED}✗ Neither Gateway resource nor /tmp/gateway-setup.yaml found${NC}"; return 1
}
hint_q126() { cat <<'EOF'
  # Check if Gateway API CRDs are installed:
  kubectl get crd gateways.gateway.networking.k8s.io 2>/dev/null || echo "CRDs not installed"

  # If not installed, write YAML to /tmp/gateway-setup.yaml:
  cat > /tmp/gateway-setup.yaml << 'YAML'
  apiVersion: gateway.networking.k8s.io/v1
  kind: Gateway
  metadata:
    name: my-gateway
    namespace: cka-q126
  spec:
    gatewayClassName: nginx
    listeners:
    - name: http
      port: 80
      protocol: HTTP
  ---
  apiVersion: gateway.networking.k8s.io/v1
  kind: HTTPRoute
  metadata:
    name: my-route
    namespace: cka-q126
  spec:
    parentRefs:
    - name: my-gateway
    hostnames:
    - gateway.example.com
    rules:
    - backendRefs:
      - name: backend-svc
        port: 80
  YAML
EOF
}

# ─── Q127 ─────────────────────────────────────────────────────────────────────
setup_q127() {
  rm -f /tmp/httproute-path.yaml 2>/dev/null
  echo "Write HTTPRoute with path matching to /tmp/httproute-path.yaml"
}
show_q127() { cat <<'EOF'
  TASK — Gateway API: HTTPRoute Path Matching
  ──────────────────────────────────────────────────────────────
  Write HTTPRoute YAML to /tmp/httproute-path.yaml:

  HTTPRoute 'path-route' in namespace 'cka-q127':
    parentRefs: [my-gateway]
    rules:
    - matches:
      - path:
          type: PathPrefix
          value: /api
      backendRefs:
      - name: api-svc
        port: 80
    - matches:
      - path:
          type: PathPrefix
          value: /
      backendRefs:
      - name: web-svc
        port: 80

  ── 한국어 ─────────────────────────────────────────────
  HTTPRoute YAML 를 /tmp/httproute-path.yaml 에 작성하세요:
    path /api → api-svc:80, path / → web-svc:80 (PathPrefix 사용)
EOF
}
validate_q127() {
  [[ -f /tmp/httproute-path.yaml ]] || { echo -e "  ${RED}✗ /tmp/httproute-path.yaml not found${NC}"; return 1; }
  local content; content=$(cat /tmp/httproute-path.yaml)
  local ok=true
  [[ "$content" != *"kind: HTTPRoute"* ]]  && { echo -e "  ${RED}✗ kind: HTTPRoute missing${NC}"; ok=false; }
  [[ "$content" != *"PathPrefix"* ]]       && { echo -e "  ${RED}✗ PathPrefix match missing${NC}"; ok=false; }
  [[ "$content" != *"/api"* ]]             && { echo -e "  ${RED}✗ /api path missing${NC}"; ok=false; }
  [[ "$content" != *"api-svc"* ]]          && { echo -e "  ${RED}✗ api-svc backend missing${NC}"; ok=false; }
  [[ "$content" != *"web-svc"* ]]          && { echo -e "  ${RED}✗ web-svc backend missing${NC}"; ok=false; }
  [[ "$ok" == "true" ]] && echo -e "  ${GREEN}✓ HTTPRoute path matching YAML is correct.${NC}"
  [[ "$ok" == "true" ]]
}
hint_q127() { cat <<'EOF'
  cat > /tmp/httproute-path.yaml << 'YAML'
  apiVersion: gateway.networking.k8s.io/v1
  kind: HTTPRoute
  metadata:
    name: path-route
    namespace: cka-q127
  spec:
    parentRefs:
    - name: my-gateway
    rules:
    - matches:
      - path:
          type: PathPrefix
          value: /api
      backendRefs:
      - name: api-svc
        port: 80
    - matches:
      - path:
          type: PathPrefix
          value: /
      backendRefs:
      - name: web-svc
        port: 80
  YAML
EOF
}

# ─── Q128 ─────────────────────────────────────────────────────────────────────
setup_q128() {
  rm -f /tmp/httproute-header.yaml 2>/dev/null
  echo "Write HTTPRoute with header matching to /tmp/httproute-header.yaml"
}
show_q128() { cat <<'EOF'
  TASK — Gateway API: HTTPRoute Header Matching
  ──────────────────────────────────────────────────────────────
  Write HTTPRoute YAML to /tmp/httproute-header.yaml:

  HTTPRoute 'header-route':
    rules:
    - matches:
      - headers:
        - name: X-Environment
          value: canary
      backendRefs:
      - name: canary-svc
        port: 80
    - backendRefs:
      - name: stable-svc
        port: 80

  ── 한국어 ─────────────────────────────────────────────
  HTTPRoute YAML 를 /tmp/httproute-header.yaml 에 작성하세요:
    헤더 X-Environment: canary → canary-svc:80
    기본(default) → stable-svc:80
EOF
}
validate_q128() {
  [[ -f /tmp/httproute-header.yaml ]] || { echo -e "  ${RED}✗ /tmp/httproute-header.yaml not found${NC}"; return 1; }
  local content; content=$(cat /tmp/httproute-header.yaml)
  local ok=true
  [[ "$content" != *"headers"* ]]        && { echo -e "  ${RED}✗ header match missing${NC}"; ok=false; }
  [[ "$content" != *"X-Environment"* ]]  && { echo -e "  ${RED}✗ X-Environment header missing${NC}"; ok=false; }
  [[ "$content" != *"canary"* ]]         && { echo -e "  ${RED}✗ canary value/backend missing${NC}"; ok=false; }
  [[ "$content" != *"stable-svc"* ]]     && { echo -e "  ${RED}✗ stable-svc backend missing${NC}"; ok=false; }
  [[ "$ok" == "true" ]] && echo -e "  ${GREEN}✓ HTTPRoute header matching YAML is correct.${NC}"
  [[ "$ok" == "true" ]]
}
hint_q128() { cat <<'EOF'
  cat > /tmp/httproute-header.yaml << 'YAML'
  apiVersion: gateway.networking.k8s.io/v1
  kind: HTTPRoute
  metadata:
    name: header-route
  spec:
    rules:
    - matches:
      - headers:
        - name: X-Environment
          value: canary
      backendRefs:
      - name: canary-svc
        port: 80
    - backendRefs:
      - name: stable-svc
        port: 80
  YAML
EOF
}

# ─── Q129 ─────────────────────────────────────────────────────────────────────
setup_q129() {
  helm uninstall nginx-test -n default --wait 2>/dev/null || true
  helm uninstall custom-nginx -n default --wait 2>/dev/null || true
  echo "Ready. Install ingress-nginx chart with Helm."
}
show_q129() { cat <<'EOF'
  TASK — Helm: Install a Chart
  ──────────────────────────────────────────────────────────────
  Install the ingress-nginx chart from the ingress-nginx repository:

    1. Add ingress-nginx repo:
       helm repo add ingress-nginx https://kubernetes.github.io/ingress-nginx
       helm repo update

    2. Install chart:
       Release name:  nginx-test
       Chart:         ingress-nginx/ingress-nginx
       Namespace:     default

  Verify:
    helm list
    helm status nginx-test

  ── 한국어 ─────────────────────────────────────────────
  ingress-nginx 레포지토리를 추가하고 차트를 설치하세요:
    helm repo add ingress-nginx https://kubernetes.github.io/ingress-nginx
    helm install nginx-test ingress-nginx/ingress-nginx
EOF
}
validate_q129() {
  local status; status=$(helm list --all-namespaces --filter nginx-test \
    -o json 2>/dev/null | grep -o '"status":"[^"]*"' | head -1)
  if [[ "$status" != *"deployed"* ]]; then
    echo -e "  ${RED}✗ Release 'nginx-test' not found or not deployed${NC}"; return 1
  fi
  echo -e "  ${GREEN}✓ Helm release 'nginx-test' is deployed.${NC}"
}
hint_q129() { cat <<'EOF'
  helm repo add ingress-nginx https://kubernetes.github.io/ingress-nginx
  helm repo update
  helm install nginx-test ingress-nginx/ingress-nginx
  helm list
EOF
}

# ─── Q130 ─────────────────────────────────────────────────────────────────────
setup_q130() {
  helm uninstall custom-nginx -n default --wait 2>/dev/null || true
  if ! helm list -n default --filter '^nginx-test$' -q 2>/dev/null | grep -q nginx-test; then
    helm repo add ingress-nginx https://kubernetes.github.io/ingress-nginx 2>/dev/null || true
    helm repo update 2>/dev/null
    helm install nginx-test ingress-nginx/ingress-nginx -n default 2>/dev/null
    echo "Installed nginx-test (Q129 prerequisite)."
  fi
  echo "Ready. Upgrade nginx-test with controller.replicaCount=2."
}
show_q130() { cat <<'EOF'
  TASK — Helm: Upgrade a Release
  ──────────────────────────────────────────────────────────────
  Release 'nginx-test' is installed.

  Upgrade it with the following custom value:
    controller.replicaCount=2

  Command:
    helm upgrade nginx-test ingress-nginx/ingress-nginx \
      --set controller.replicaCount=2

  Verify:
    helm history nginx-test
    # Should show revision 2

  ── 한국어 ─────────────────────────────────────────────
  'nginx-test' 릴리스를 controller.replicaCount=2 로 업그레이드하세요:
    helm upgrade nginx-test ingress-nginx/ingress-nginx \
      --set controller.replicaCount=2
  revision 2 이상이 되는지 확인하세요.
EOF
}
validate_q130() {
  local rev; rev=$(helm history nginx-test --max 10 -o json 2>/dev/null | \
    python3 -c "import sys,json; h=json.load(sys.stdin); print(max(r['revision'] for r in h))" 2>/dev/null)
  [[ "${rev:-0}" -lt 2 ]] && { echo -e "  ${RED}✗ revision=$rev (want >= 2, need to upgrade)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ nginx-test upgraded to revision $rev.${NC}"
}
hint_q130() { cat <<'EOF'
  helm upgrade nginx-test ingress-nginx/ingress-nginx \
    --set controller.replicaCount=2
  helm history nginx-test
EOF
}

# ─── Q131 ─────────────────────────────────────────────────────────────────────
setup_q131() {
  helm uninstall custom-nginx -n default --wait 2>/dev/null || true
  helm repo add ingress-nginx https://kubernetes.github.io/ingress-nginx 2>/dev/null || true
  if ! helm list -n default --filter '^nginx-test$' -q 2>/dev/null | grep -q nginx-test; then
    helm repo update 2>/dev/null
    helm install nginx-test ingress-nginx/ingress-nginx -n default 2>/dev/null
    echo "Installed nginx-test (Q129 prerequisite)."
  fi
  local rev
  rev=$(helm history nginx-test -n default --max 10 -o json 2>/dev/null | \
    python3 -c "import sys,json; h=json.load(sys.stdin); print(max(r['revision'] for r in h))" 2>/dev/null || echo 0)
  if [[ "${rev:-0}" -lt 2 ]]; then
    helm upgrade nginx-test ingress-nginx/ingress-nginx -n default \
      --set controller.replicaCount=2 2>/dev/null
    echo "Upgraded nginx-test to revision 2 (Q130 prerequisite)."
  fi
  echo "Ready. Rollback nginx-test to revision 1."
}
show_q131() { cat <<'EOF'
  TASK — Helm: Rollback a Release
  ──────────────────────────────────────────────────────────────
  Release 'nginx-test' has multiple revisions.

  Rollback to revision 1:
    helm rollback nginx-test 1

  Verify:
    helm history nginx-test
    # Latest entry should show: rolled back

  ── 한국어 ─────────────────────────────────────────────
  'nginx-test' 를 revision 1 로 롤백하세요:
    helm rollback nginx-test 1
  역사에서 최신 엔트리가 rolled back 로 표시되는지 확인하세요.
EOF
}
validate_q131() {
  local latest_desc; latest_desc=$(helm history nginx-test --max 10 -o json 2>/dev/null | \
    python3 -c "import sys,json; h=json.load(sys.stdin); h.sort(key=lambda x:x['revision']); print(h[-1]['description'])" 2>/dev/null)
  if [[ "$latest_desc" != *"Rollback"* && "$latest_desc" != *"rollback"* ]]; then
    echo -e "  ${RED}✗ Latest revision not a rollback. description='$latest_desc'${NC}"; return 1
  fi
  echo -e "  ${GREEN}✓ nginx-test rolled back.${NC}"
}
hint_q131() { cat <<'EOF'
  helm history nginx-test
  helm rollback nginx-test 1
  helm history nginx-test
EOF
}

# ─── Q132 ─────────────────────────────────────────────────────────────────────
setup_q132() {
  helm uninstall custom-nginx -n default --wait 2>/dev/null || true
  helm uninstall nginx-test -n default --wait 2>/dev/null || true
  echo "Ready. Install chart with custom values."
}
show_q132() { cat <<'EOF'
  TASK — Helm: Install with Custom Values
  ──────────────────────────────────────────────────────────────
  Install ingress-nginx/ingress-nginx as 'custom-nginx' with:
    controller.replicaCount:  3
    controller.service.type:  ClusterIP

  Command:
    helm install custom-nginx ingress-nginx/ingress-nginx \
      --set controller.replicaCount=3 \
      --set controller.service.type=ClusterIP

  Verify:
    helm get values custom-nginx

  ── 한국어 ─────────────────────────────────────────────
  ingress-nginx/ingress-nginx 를 'custom-nginx' 로 설치하세요:
    controller.replicaCount=3 / controller.service.type=ClusterIP
EOF
}
validate_q132() {
  local status; status=$(helm list --filter custom-nginx -o json 2>/dev/null | \
    grep -o '"status":"[^"]*"' | head -1)
  [[ "$status" != *"deployed"* ]] && { echo -e "  ${RED}✗ Release 'custom-nginx' not deployed${NC}"; return 1; }
  local vals; vals=$(helm get values custom-nginx 2>/dev/null)
  local ok=true
  [[ "$vals" != *"replicaCount: 3"* && "$vals" != *"replicaCount:3"* ]] \
    && { echo -e "  ${RED}✗ controller.replicaCount=3 not set${NC}"; ok=false; }
  [[ "$ok" == "true" ]] && echo -e "  ${GREEN}✓ custom-nginx installed with controller.replicaCount=3.${NC}"
  [[ "$ok" == "true" ]]
}
hint_q132() { cat <<'EOF'
  helm install custom-nginx ingress-nginx/ingress-nginx \
    --set controller.replicaCount=3 \
    --set controller.service.type=ClusterIP
  helm get values custom-nginx
EOF
}

# ─── Q133 ─────────────────────────────────────────────────────────────────────
setup_q133() {
  helm uninstall nginx-test -n default --wait 2>/dev/null || true
  helm repo add ingress-nginx https://kubernetes.github.io/ingress-nginx 2>/dev/null || true
  if ! helm list -n default --filter '^custom-nginx$' -q 2>/dev/null | grep -q custom-nginx; then
    helm repo update 2>/dev/null
    helm install custom-nginx ingress-nginx/ingress-nginx -n default \
      --set controller.replicaCount=3 \
      --set controller.service.type=ClusterIP 2>/dev/null
    echo "Installed custom-nginx (Q132 prerequisite)."
  fi
  echo "Ready. List Helm releases and uninstall custom-nginx."
}
show_q133() { cat <<'EOF'
  TASK — Helm: List + Uninstall
  ──────────────────────────────────────────────────────────────
  Step 1: List all Helm releases across all namespaces:
    helm list --all-namespaces
    Save output to /tmp/helm-list.txt

  Step 2: Uninstall release 'custom-nginx':
    helm uninstall custom-nginx

  Verify:
    helm list | grep custom-nginx
    # Should show nothing

  ── 한국어 ─────────────────────────────────────────────
  1단계: 전체 네임스페이스의 릴리스 목록 저장:
    helm list --all-namespaces > /tmp/helm-list.txt
  2단계: 'custom-nginx' 릴리스 제거:
    helm uninstall custom-nginx
EOF
}
validate_q133() {
  [[ -f /tmp/helm-list.txt ]] || { echo -e "  ${RED}✗ /tmp/helm-list.txt not found${NC}"; return 1; }
  local still_exists; still_exists=$(helm list --filter custom-nginx 2>/dev/null)
  [[ -n "$still_exists" ]] && { echo -e "  ${RED}✗ Release 'custom-nginx' still exists${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Helm list saved and custom-nginx uninstalled.${NC}"
}
hint_q133() { cat <<'EOF'
  helm list --all-namespaces > /tmp/helm-list.txt
  cat /tmp/helm-list.txt
  helm uninstall custom-nginx
  helm list
EOF
}

# ─── Q134 ─────────────────────────────────────────────────────────────────────
setup_q134() {
  rm -rf /tmp/kustomize-base 2>/dev/null
  mkdir -p /tmp/kustomize-base
  cat > /tmp/kustomize-base/deployment.yaml <<'EOF'
apiVersion: apps/v1
kind: Deployment
metadata:
  name: myapp
spec:
  replicas: 1
  selector:
    matchLabels:
      app: myapp
  template:
    metadata:
      labels:
        app: myapp
    spec:
      containers:
      - name: app
        image: nginx:1.27
EOF
  cat > /tmp/kustomize-base/kustomization.yaml <<'EOF'
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization
resources:
- deployment.yaml
namespace: cka-kustomize
EOF
  _ns cka-kustomize
  echo "Kustomize base created at /tmp/kustomize-base"
}
show_q134() { cat <<'EOF'
  TASK — Kustomize: Apply base
  ──────────────────────────────────────────────────────────────
  A kustomize base directory exists at /tmp/kustomize-base.
  It contains a Deployment 'myapp' for namespace 'cka-kustomize'.

  Apply it to the cluster:
    kubectl apply -k /tmp/kustomize-base

  Verify:
    kubectl get deployment myapp -n cka-kustomize

  ── 한국어 ─────────────────────────────────────────────
  /tmp/kustomize-base 디렉토리를 클러스터에 적용하세요:
    kubectl apply -k /tmp/kustomize-base
  cka-kustomize 네임스페이스에 Deployment 'myapp' 이 생성되는지 확인
EOF
}
validate_q134() {
  kubectl get deployment myapp -n cka-kustomize &>/dev/null || \
    { echo -e "  ${RED}✗ Deployment 'myapp' not found in cka-kustomize${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Kustomize base applied. Deployment 'myapp' exists.${NC}"
}
hint_q134() { cat <<'EOF'
  kubectl apply -k /tmp/kustomize-base
  kubectl get deployment myapp -n cka-kustomize
EOF
}

# ─── Q135 ─────────────────────────────────────────────────────────────────────
setup_q135() {
  _ensure_kustomize_base
  rm -rf /tmp/kustomize-overlay 2>/dev/null
  mkdir -p /tmp/kustomize-overlay
  cat > /tmp/kustomize-overlay/kustomization.yaml <<'EOF'
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization
resources:
- ../kustomize-base
EOF
  _ns cka-overlay
  echo "Overlay directory at /tmp/kustomize-overlay (extends /tmp/kustomize-base)"
}
show_q135() { cat <<'EOF'
  TASK — Kustomize: Overlay with namePrefix
  ──────────────────────────────────────────────────────────────
  Base dir:    /tmp/kustomize-base
  Overlay dir: /tmp/kustomize-overlay

  Edit /tmp/kustomize-overlay/kustomization.yaml to:
    1. Add namePrefix: prod-
    2. Change namespace to: cka-overlay

  Then apply:
    kubectl apply -k /tmp/kustomize-overlay

  Expected result: Deployment named 'prod-myapp' in namespace 'cka-overlay'

  ── 한국어 ─────────────────────────────────────────────
  /tmp/kustomize-overlay/kustomization.yaml 에 추가하세요:
    namePrefix: prod-
    namespace: cka-overlay
  적용 후 'prod-myapp' 라는 Deployment 가 cka-overlay 에 생성됩니다.
EOF
}
validate_q135() {
  kubectl get deployment prod-myapp -n cka-overlay &>/dev/null || \
    { echo -e "  ${RED}✗ Deployment 'prod-myapp' not found in cka-overlay${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Kustomize overlay applied. Deployment 'prod-myapp' in cka-overlay.${NC}"
}
hint_q135() { cat <<'EOF'
  # Edit /tmp/kustomize-overlay/kustomization.yaml:
  apiVersion: kustomize.config.k8s.io/v1beta1
  kind: Kustomization
  resources:
  - ../kustomize-base
  namePrefix: prod-
  namespace: cka-overlay

  kubectl apply -k /tmp/kustomize-overlay
EOF
}

# ─── Q136 ─────────────────────────────────────────────────────────────────────
setup_q136() {
  _ensure_kustomize_base
  rm -rf /tmp/kustomize-patch 2>/dev/null
  mkdir -p /tmp/kustomize-patch
  cat > /tmp/kustomize-patch/kustomization.yaml <<'EOF'
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization
resources:
- ../kustomize-base
namespace: cka-kustomize
EOF
  echo "Patch overlay at /tmp/kustomize-patch"
}
show_q136() { cat <<'EOF'
  TASK — Kustomize: Overlay with replicas patch
  ──────────────────────────────────────────────────────────────
  Overlay dir: /tmp/kustomize-patch

  Add a patch to set replicas=3 for Deployment 'myapp'.

  Edit /tmp/kustomize-patch/kustomization.yaml to add:
    replicas:
    - name: myapp
      count: 3

  Then apply and verify:
    kubectl apply -k /tmp/kustomize-patch
    kubectl get deployment myapp -n cka-kustomize
    # DESIRED should show 3

  ── 한국어 ─────────────────────────────────────────────
  /tmp/kustomize-patch/kustomization.yaml 에 replicas 패치를 추가하세요:
    replicas:
    - name: myapp
      count: 3
  적용 후 Deployment 'myapp' 의 replicas가 3이 되는지 확인
EOF
}
validate_q136() {
  local rep; rep=$(kubectl get deployment myapp -n cka-kustomize \
    -o jsonpath='{.spec.replicas}' 2>/dev/null)
  [[ "$rep" != "3" ]] && { echo -e "  ${RED}✗ replicas=$rep (want 3)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Deployment 'myapp' scaled to 3 replicas via Kustomize patch.${NC}"
}
hint_q136() { cat <<'EOF'
  # /tmp/kustomize-patch/kustomization.yaml:
  apiVersion: kustomize.config.k8s.io/v1beta1
  kind: Kustomization
  resources:
  - ../kustomize-base
  namespace: cka-kustomize
  replicas:
  - name: myapp
    count: 3

  kubectl apply -k /tmp/kustomize-patch
EOF
}

# ─── Q137 ─────────────────────────────────────────────────────────────────────
setup_q137() {
  rm -rf /tmp/kustomize-cm 2>/dev/null
  mkdir -p /tmp/kustomize-cm
  echo "DATABASE_URL=postgres://localhost/mydb" > /tmp/kustomize-cm/db.env
  cat > /tmp/kustomize-cm/kustomization.yaml <<'EOF'
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization
namespace: cka-kustomize
EOF
  echo "Kustomize dir with db.env at /tmp/kustomize-cm"
}
show_q137() { cat <<'EOF'
  TASK — Kustomize: ConfigMap Generator
  ──────────────────────────────────────────────────────────────
  Directory /tmp/kustomize-cm contains db.env.

  Edit /tmp/kustomize-cm/kustomization.yaml to add a ConfigMap generator:
    configMapGenerator:
    - name: db-config
      envs:
      - db.env

  Then apply:
    kubectl apply -k /tmp/kustomize-cm

  Verify:
    kubectl get configmap -n cka-kustomize | grep db-config

  ── 한국어 ─────────────────────────────────────────────
  /tmp/kustomize-cm/kustomization.yaml 에 configMapGenerator 를 추가하세요:
    configMapGenerator:
    - name: db-config
      envs: [db.env]
  적용 후 cka-kustomize 에 'db-config' ConfigMap 이 생성되는지 확인
EOF
}
validate_q137() {
  local cm; cm=$(kubectl get configmap -n cka-kustomize --no-headers 2>/dev/null | grep "db-config")
  [[ -z "$cm" ]] && { echo -e "  ${RED}✗ ConfigMap 'db-config' not found in cka-kustomize${NC}"; return 1; }
  echo -e "  ${GREEN}✓ ConfigMap 'db-config' generated by Kustomize.${NC}"
}
hint_q137() { cat <<'EOF'
  # /tmp/kustomize-cm/kustomization.yaml:
  apiVersion: kustomize.config.k8s.io/v1beta1
  kind: Kustomization
  namespace: cka-kustomize
  configMapGenerator:
  - name: db-config
    envs:
    - db.env

  kubectl apply -k /tmp/kustomize-cm
EOF
}

# ─── Q138 ─────────────────────────────────────────────────────────────────────
setup_q138() {
  _ns cka-q138
  kubectl delete networkpolicy allow-from-ns -n cka-q138 2>/dev/null
  kubectl delete namespace monitor-ns 2>/dev/null
  kubectl create namespace monitor-ns 2>/dev/null
  kubectl label namespace monitor-ns role=monitoring --overwrite 2>/dev/null
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: apps/v1
kind: Deployment
metadata:
  name: target-app
  namespace: cka-q138
spec:
  replicas: 1
  selector:
    matchLabels:
      app: target
  template:
    metadata:
      labels:
        app: target
    spec:
      containers:
      - name: app
        image: nginx:1.27
        ports:
        - containerPort: 80
EOF
  echo "Namespace 'monitor-ns' (role=monitoring) and deployment 'target-app' ready."
}
show_q138() { cat <<'EOF'
  TASK — NetworkPolicy: Allow Ingress from Namespace
  ──────────────────────────────────────────────────────────────
  Namespace 'monitor-ns' has label role=monitoring.
  Deployment 'target-app' (app=target) runs in 'cka-q138'.

  Create NetworkPolicy 'allow-from-ns' in 'cka-q138':
    podSelector: app=target
    policyTypes: [Ingress]
    ingress:
      from namespaces with label: role=monitoring
      port: 80

  This allows only pods in 'monitor-ns' to reach target-app:80.

  ── 한국어 ─────────────────────────────────────────────
  'cka-q138' 에 NetworkPolicy 'allow-from-ns' 를 생성하세요:
    podSelector: app=target
    policyTypes: [Ingress]
    ingress: role=monitoring 라벨을 가진 네임스페이스에서만 허용, port: 80
EOF
}
validate_q138() {
  kubectl get networkpolicy allow-from-ns -n cka-q138 &>/dev/null || \
    { echo -e "  ${RED}✗ NetworkPolicy 'allow-from-ns' not found${NC}"; return 1; }
  local ns_sel; ns_sel=$(kubectl get networkpolicy allow-from-ns -n cka-q138 \
    -o jsonpath='{.spec.ingress[0].from[0].namespaceSelector}')
  [[ "$ns_sel" != *"monitoring"* ]] && { echo -e "  ${RED}✗ namespaceSelector not targeting role=monitoring${NC}"; return 1; }
  echo -e "  ${GREEN}✓ NetworkPolicy allows ingress from namespace role=monitoring.${NC}"
}
hint_q138() { cat <<'EOF'
  apiVersion: networking.k8s.io/v1
  kind: NetworkPolicy
  metadata:
    name: allow-from-ns
    namespace: cka-q138
  spec:
    podSelector:
      matchLabels:
        app: target
    policyTypes:
    - Ingress
    ingress:
    - from:
      - namespaceSelector:
          matchLabels:
            role: monitoring
      ports:
      - port: 80
        protocol: TCP
EOF
}

# ─── Q139 ─────────────────────────────────────────────────────────────────────
setup_q139() {
  _ns cka-q139
  kubectl delete networkpolicy deny-all allow-port -n cka-q139 2>/dev/null
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: apps/v1
kind: Deployment
metadata:
  name: secure-app
  namespace: cka-q139
spec:
  replicas: 1
  selector:
    matchLabels:
      app: secure
  template:
    metadata:
      labels:
        app: secure
    spec:
      containers:
      - name: app
        image: nginx:1.27
        ports:
        - containerPort: 8080
EOF
  echo "Deployment 'secure-app' running in cka-q139."
}
show_q139() { cat <<'EOF'
  TASK — NetworkPolicy: Deny All + Allow Specific Port
  ──────────────────────────────────────────────────────────────
  Deployment 'secure-app' (app=secure) runs in 'cka-q139' on port 8080.

  Step 1: Create NetworkPolicy 'deny-all' — deny all ingress to all pods:
    podSelector: {}   (all pods)
    policyTypes: [Ingress]
    ingress: []       (empty = deny all)

  Step 2: Create NetworkPolicy 'allow-port':
    podSelector: app=secure
    policyTypes: [Ingress]
    ingress:
      ports: [8080]
      (allow from any pod)

  ── 한국어 ─────────────────────────────────────────────
  'cka-q139' 에 두 개의 NetworkPolicy 를 생성하세요:
    1) 'deny-all': 모든 파드에 대한 Ingress 전체 차단 (podSelector: {}, ingress: [])
    2) 'allow-port': app=secure 파드에 대해 포트 8080 허용
EOF
}
validate_q139() {
  kubectl get networkpolicy deny-all -n cka-q139 &>/dev/null || \
    { echo -e "  ${RED}✗ NetworkPolicy 'deny-all' not found${NC}"; return 1; }
  kubectl get networkpolicy allow-port -n cka-q139 &>/dev/null || \
    { echo -e "  ${RED}✗ NetworkPolicy 'allow-port' not found${NC}"; return 1; }
  local port; port=$(kubectl get networkpolicy allow-port -n cka-q139 \
    -o jsonpath='{.spec.ingress[0].ports[0].port}')
  [[ "$port" != "8080" ]] && { echo -e "  ${RED}✗ allow-port targets port=$port (want 8080)${NC}"; return 1; }
  echo -e "  ${GREEN}✓ deny-all + allow-port:8080 NetworkPolicies configured.${NC}"
}
hint_q139() { cat <<'EOF'
  # deny-all:
  apiVersion: networking.k8s.io/v1
  kind: NetworkPolicy
  metadata:
    name: deny-all
    namespace: cka-q139
  spec:
    podSelector: {}
    policyTypes:
    - Ingress
  ---
  # allow-port:
  apiVersion: networking.k8s.io/v1
  kind: NetworkPolicy
  metadata:
    name: allow-port
    namespace: cka-q139
  spec:
    podSelector:
      matchLabels:
        app: secure
    policyTypes:
    - Ingress
    ingress:
    - ports:
      - port: 8080
        protocol: TCP
EOF
}

# ─── Q140 ─────────────────────────────────────────────────────────────────────
setup_q140() {
  _ns cka-q140
  kubectl delete networkpolicy egress-cidr -n cka-q140 2>/dev/null
  cat <<EOF | kubectl apply -f - 2>/dev/null
apiVersion: apps/v1
kind: Deployment
metadata:
  name: egress-app
  namespace: cka-q140
spec:
  replicas: 1
  selector:
    matchLabels:
      app: egress
  template:
    metadata:
      labels:
        app: egress
    spec:
      containers:
      - name: app
        image: nginx:1.27
EOF
  echo "Deployment 'egress-app' ready in cka-q140."
}
show_q140() { cat <<'EOF'
  TASK — NetworkPolicy: Egress to External CIDR
  ──────────────────────────────────────────────────────────────
  Deployment 'egress-app' (app=egress) runs in 'cka-q140'.

  Create NetworkPolicy 'egress-cidr':
    podSelector: app=egress
    policyTypes: [Egress]
    egress:
    - to:
      - ipBlock:
          cidr: 10.0.0.0/8
      ports: [443]
    - to:
      - ipBlock:
          cidr: 0.0.0.0/0
          except: [10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16]
      ports: [53]   (allow DNS)

  This allows only HTTPS to 10.0.0.0/8 and DNS to external IPs.

  ── 한국어 ─────────────────────────────────────────────
  'cka-q140' 의 'egress-app' 를 대상으로 NetworkPolicy 'egress-cidr' 를 생성하세요:
    policyTypes: [Egress]
    egress 1: 10.0.0.0/8 으로 HTTPS(443) 허용
    egress 2: 외부 IP (private 대역 제외) 로 DNS(53) 허용
EOF
}
validate_q140() {
  kubectl get networkpolicy egress-cidr -n cka-q140 &>/dev/null || \
    { echo -e "  ${RED}✗ NetworkPolicy 'egress-cidr' not found${NC}"; return 1; }
  local policy; policy=$(kubectl get networkpolicy egress-cidr -n cka-q140 -o json)
  [[ "$policy" != *"Egress"* ]]    && { echo -e "  ${RED}✗ policyTypes missing Egress${NC}"; return 1; }
  [[ "$policy" != *"10.0.0.0/8"* ]] && { echo -e "  ${RED}✗ CIDR 10.0.0.0/8 not found${NC}"; return 1; }
  [[ "$policy" != *"443"* ]]       && { echo -e "  ${RED}✗ port 443 not found${NC}"; return 1; }
  echo -e "  ${GREEN}✓ Egress NetworkPolicy to 10.0.0.0/8:443 configured correctly.${NC}"
}
hint_q140() { cat <<'EOF'
  apiVersion: networking.k8s.io/v1
  kind: NetworkPolicy
  metadata:
    name: egress-cidr
    namespace: cka-q140
  spec:
    podSelector:
      matchLabels:
        app: egress
    policyTypes:
    - Egress
    egress:
    - to:
      - ipBlock:
          cidr: 10.0.0.0/8
      ports:
      - port: 443
        protocol: TCP
    - to:
      - ipBlock:
          cidr: 0.0.0.0/0
          except:
          - 10.0.0.0/8
          - 172.16.0.0/12
          - 192.168.0.0/16
      ports:
      - port: 53
        protocol: UDP
EOF
}
