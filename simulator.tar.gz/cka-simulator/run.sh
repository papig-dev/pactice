#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
#  CKA Exam Simulator — 140 Questions, 7 Batches
#  Usage:  chmod +x run.sh && ./run.sh
#  Requires: kubectl, bash 4+, kind cluster (kind-cka)
# ─────────────────────────────────────────────────────────────────────────────

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

SESSION_SCORE=0
SESSION_TOTAL=0
declare -A Q_RESULTS
CHOICE=""

banner() {
  clear
  echo -e "${CYAN}${BOLD}"
  echo "  ╔══════════════════════════════════════════════════════════════╗"
  echo "  ║         CKA EXAM SIMULATOR  —  k8s v1.33  (→ v1.34)          ║"
  echo "  ║         140 Questions  │  7 Batches × 20  │  kind cluster    ║"
  echo "  ╚══════════════════════════════════════════════════════════════╝"
  echo -e "${NC}"
}

batch_menu() {
  banner
  echo -e "${BOLD}  Choose a Question Batch:${NC}\n"
  echo "  [1]  Batch 1 — Pods & Deployments               (Q1   – Q20)"
  echo "  [2]  Batch 2 — Services & Networking            (Q21  – Q40)"
  echo "  [3]  Batch 3 — ConfigMaps, Secrets & Storage    (Q41  – Q60)"
  echo "  [4]  Batch 4 — RBAC, Security & Scheduling      (Q61  – Q80)"
  echo "  [5]  Batch 5 — Troubleshooting & Cluster Mgmt   (Q81  – Q100)"
  echo "  [6]  Batch 6 — etcd, Upgrade, PSA & HPA         (Q101 – Q120)"
  echo "  [7]  Batch 7 — Ingress, Gateway API, Helm & Kustomize (Q121 – Q140)"
  echo ""
  echo "  [s]  View Session Score    [q]  Quit"
  echo ""
  read -rp "  ▶ Choice: " CHOICE
}

question_menu() {
  local start=$1
  banner
  echo -e "${BOLD}  $BATCH_TITLE${NC}\n"
  for i in $(seq 1 20); do
    local qn=$((start + i - 1))
    local mark="   "
    [[ "${Q_RESULTS[q$qn]}" == "pass" ]] && mark="${GREEN}[✓]${NC}"
    [[ "${Q_RESULTS[q$qn]}" == "fail" ]] && mark="${RED}[✗]${NC}"
    echo -e "  [$(printf '%2d' $i)]$mark  ${Q_TITLES[$i]}"
  done
  echo ""
  echo "  [a]  Run all in sequence    [b]  Back    [q]  Quit"
  echo ""
  read -rp "  ▶ Choice (1-20): " CHOICE
}

run_q() {
  local qn=$1
  clear
  echo -e "${YELLOW}${BOLD}\n  ⚙  Setting up Q${qn} environment...${NC}\n"
  "setup_q${qn}" 2>&1 | sed 's/^/  /'
  sleep 1

  while true; do
    clear
    echo -e "${BLUE}${BOLD}"
    echo "  ┌────────────────────────────────────────────────────────────┐"
    printf  "  │  Question %3d / 140                                        │\n" "$qn"
    echo "  └────────────────────────────────────────────────────────────┘"
    echo -e "${NC}"
    "show_q${qn}"
    echo -e "  ${YELLOW}Keys: [Enter] Validate  [h] Hint  [r] Reset env  [s] Skip${NC}\n"
    read -r -s -n 1 key

    case "$key" in
      "")
        echo ""
        echo -e "  ${BOLD}── Validating Q${qn} ──────────────────────────────────────────${NC}\n"
        if "validate_q${qn}"; then
          Q_RESULTS[q$qn]="pass"
          SESSION_SCORE=$((SESSION_SCORE + 1))
          SESSION_TOTAL=$((SESSION_TOTAL + 1))
          echo -e "\n  ${GREEN}${BOLD}✓  PASSED!${NC}\n"
          read -p "  Press Enter to continue..." _
          return 0
        else
          echo -e "\n  ${RED}${BOLD}✗  Not correct yet.${NC}  [Enter] retry  [h] hint  [s] skip"
          read -r -s -n 1 r2
          case "$r2" in
            s) Q_RESULTS[q$qn]="fail"; SESSION_TOTAL=$((SESSION_TOTAL + 1)); return 1 ;;
            h) echo ""; "hint_q${qn}" 2>/dev/null; echo ""; sleep 3 ;;
          esac
        fi
        ;;
      h) echo ""; "hint_q${qn}" 2>/dev/null || echo "  No hint."; echo ""; read -p "  Press Enter..." _ ;;
      r) echo ""; echo -e "  ${YELLOW}Resetting...${NC}"; "setup_q${qn}" 2>&1 | sed 's/^/  /'; sleep 1 ;;
      s) Q_RESULTS[q$qn]="fail"; SESSION_TOTAL=$((SESSION_TOTAL + 1)); return 1 ;;
    esac
  done
}

show_score() {
  banner
  local pct=0
  [[ $SESSION_TOTAL -gt 0 ]] && pct=$((SESSION_SCORE * 100 / SESSION_TOTAL))
  echo -e "  ${BOLD}Session Score:${NC}\n"
  echo -e "  ${GREEN}${BOLD}${SESSION_SCORE}${NC} / ${SESSION_TOTAL} attempted  →  ${BOLD}${pct}%${NC}\n"
  if [[ ${#Q_RESULTS[@]} -gt 0 ]]; then
    echo "  ─────────────────────────────"
    for key in $(echo "${!Q_RESULTS[@]}" | tr ' ' '\n' | sort -t q -k 2 -n); do
      local qnum="${key#q}"
      [[ "${Q_RESULTS[$key]}" == "pass" ]] \
        && echo -e "    Q${qnum}:  ${GREEN}✓  Pass${NC}" \
        || echo -e "    Q${qnum}:  ${RED}✗  Fail / Skipped${NC}"
    done
  fi
  echo ""
}

main() {
  if ! command -v kubectl &>/dev/null; then
    echo -e "${RED}Error: kubectl not found.${NC}"; exit 1
  fi
  if ! kubectl cluster-info &>/dev/null; then
    echo -e "${RED}Error: No cluster reachable. Run: kind create cluster --name cka${NC}"; exit 1
  fi

  while true; do
    batch_menu
    local start=0
    case "$CHOICE" in
      1) source "$SCRIPT_DIR/batch1.sh"; start=1   ;;
      2) source "$SCRIPT_DIR/batch2.sh"; start=21  ;;
      3) source "$SCRIPT_DIR/batch3.sh"; start=41  ;;
      4) source "$SCRIPT_DIR/batch4.sh"; start=61  ;;
      5) source "$SCRIPT_DIR/batch5.sh"; start=81  ;;
      6) source "$SCRIPT_DIR/batch6.sh"; start=101 ;;
      7) source "$SCRIPT_DIR/batch7.sh"; start=121 ;;
      s|S) show_score; read -p "  Press Enter..." _; continue ;;
      q|Q) echo -e "\n  Good luck on your CKA!\n"; exit 0 ;;
      *) continue ;;
    esac

    while true; do
      question_menu "$start"
      if [[ "$CHOICE" =~ ^[0-9]+$ ]] && (( CHOICE >= 1 && CHOICE <= 20 )); then
        run_q $((start + CHOICE - 1))
      else
        case "$CHOICE" in
          a|A)
            for i in $(seq 1 20); do run_q $((start + i - 1)); done
            show_score; read -p "  Press Enter..." _
            ;;
          b|B) break ;;
          q|Q) echo -e "\n  Goodbye.\n"; exit 0 ;;
        esac
      fi
    done
  done
}

main
