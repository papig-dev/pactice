#!/usr/bin/env bash
# CKA Simulator — Cluster Setup
# kind 클러스터 생성 후 이 스크립트 한 번 실행하면 됨
# Usage: ./setup-cluster.sh

set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'

ok()   { echo -e "  ${GREEN}✓${NC} $1"; }
warn() { echo -e "  ${YELLOW}!${NC} $1"; }
fail() { echo -e "  ${RED}✗${NC} $1"; }

echo ""
echo "  ══════════════════════════════════════════════"
echo "   CKA Simulator — Cluster Component Setup"
echo "  ══════════════════════════════════════════════"
echo ""

# ── 0. 클러스터 접속 확인 ────────────────────────────────────────────────────
if ! kubectl cluster-info &>/dev/null; then
  fail "클러스터에 접속할 수 없어. kind 클러스터를 먼저 만들어:"
  echo ""
  echo "    kind create cluster --config kind-config.yaml"
  echo ""
  exit 1
fi
ok "클러스터 접속 확인: $(kubectl config current-context)"
echo ""

# ── 1. metrics-server ────────────────────────────────────────────────────────
echo "  [1/4] metrics-server 설치 중..."
kubectl apply -f https://github.com/kubernetes-sigs/metrics-server/releases/download/v0.7.2/components.yaml &>/dev/null
kubectl patch deployment metrics-server -n kube-system --type='json' \
  -p='[{"op":"add","path":"/spec/template/spec/containers/0/args/-","value":"--kubelet-insecure-tls"}]' &>/dev/null
ok "metrics-server 설치 완료 (HPA Q109-111)"

# ── 2. ingress-nginx ─────────────────────────────────────────────────────────
echo "  [2/4] ingress-nginx 설치 중..."
kubectl apply -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/main/deploy/static/provider/kind/deploy.yaml &>/dev/null
ok "ingress-nginx 설치 완료 (Ingress Q121-125)"

# ── 3. Gateway API CRDs ──────────────────────────────────────────────────────
echo "  [3/4] Gateway API CRDs 설치 중..."
kubectl apply -f https://github.com/kubernetes-sigs/gateway-api/releases/download/v1.2.1/standard-install.yaml &>/dev/null
ok "Gateway API CRDs 설치 완료 (Q126-128)"

# ── 4. Helm + ingress-nginx repo ─────────────────────────────────────────────
echo "  [4/4] Helm ingress-nginx repo 등록 중..."
if ! command -v helm &>/dev/null; then
  fail "helm 이 없어. 먼저 설치: brew install helm"
  exit 1
fi
helm repo add ingress-nginx https://kubernetes.github.io/ingress-nginx &>/dev/null || true
helm repo update &>/dev/null
ok "Helm ingress-nginx repo 등록 완료 (Q129-133)"

# ── 완료 ─────────────────────────────────────────────────────────────────────
echo ""
echo "  ══════════════════════════════════════════════"
ok "모든 컴포넌트 설치 완료!"
echo ""
warn "ingress-nginx 파드가 Ready 되는데 30초~1분 걸릴 수 있어."
echo "    kubectl get pods -n ingress-nginx -w  로 확인"
echo ""
echo "  이제 시뮬레이터 시작:"
echo "    ./run.sh"
echo "  ══════════════════════════════════════════════"
echo ""
